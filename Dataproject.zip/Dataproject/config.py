import os
from datetime import timedelta
from dotenv import load_dotenv

# Load variables from .env file if present
load_dotenv()

class Config:
    """Application configuration from environment variables."""
    # Flask settings
    SECRET_KEY = os.environ.get('SECRET_KEY', 'default-dev-mca-analytics-token-2025-key')
    DEBUG = os.environ.get('FLASK_DEBUG', '1') == '1'
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Direct MySQL Connection settings (mysql-connector-python)
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_PORT = int(os.environ.get('DB_PORT', 3306))
    DB_USER = os.environ.get('DB_USER', 'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
    DB_NAME = os.environ.get('DB_NAME', 'student_analytics_db')
