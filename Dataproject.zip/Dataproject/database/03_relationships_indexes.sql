-- ==============================================================================
-- PROJECT: Student Performance Analytics System
-- SCRIPT 03: Foreign Key Relationships and Performance Indexes
-- DBMS: MySQL 8.0+
-- ==============================================================================

USE `student_analytics_db`;

-- ==============================================================================
-- 1. FOREIGN KEY CONSTRAINTS
-- ==============================================================================

-- Marks relationships
ALTER TABLE `marks`
    ADD CONSTRAINT `fk_marks_student`
        FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    ADD CONSTRAINT `fk_marks_subject`
        FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    ADD CONSTRAINT `fk_marks_session`
        FOREIGN KEY (`session_id`) REFERENCES `academic_sessions` (`session_id`)
        ON DELETE RESTRICT ON UPDATE CASCADE;

-- Attendance relationships
ALTER TABLE `attendance`
    ADD CONSTRAINT `fk_attendance_student`
        FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    ADD CONSTRAINT `fk_attendance_subject`
        FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`)
        ON DELETE CASCADE ON UPDATE CASCADE;

-- Activity Logs relationships
ALTER TABLE `activity_logs`
    ADD CONSTRAINT `fk_activity_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
        ON DELETE SET NULL ON UPDATE CASCADE;

-- ==============================================================================
-- 2. PERFORMANCE INDEXES
-- ==============================================================================

-- Students: Speed up search by roll number, name, course, and semester
CREATE INDEX `idx_students_roll_number` ON `students` (`roll_number`);
CREATE INDEX `idx_students_full_name` ON `students` (`full_name`);
CREATE INDEX `idx_students_course_sem` ON `students` (`course`, `semester`);
CREATE INDEX `idx_students_status` ON `students` (`status`);

-- Subjects: Speed up search by code, course, and semester
CREATE INDEX `idx_subjects_code` ON `subjects` (`subject_code`);
CREATE INDEX `idx_subjects_course_sem` ON `subjects` (`course`, `semester`);

-- Marks: Speed up student results retrieval, subject averages, and grade distributions
CREATE INDEX `idx_marks_student_id` ON `marks` (`student_id`);
CREATE INDEX `idx_marks_subject_id` ON `marks` (`subject_id`);
CREATE INDEX `idx_marks_session_id` ON `marks` (`session_id`);
CREATE INDEX `idx_marks_exam_type` ON `marks` (`exam_type`);
CREATE INDEX `idx_marks_grade` ON `marks` (`grade`);
CREATE INDEX `idx_marks_status` ON `marks` (`status`);
CREATE INDEX `idx_marks_composite_analytics` ON `marks` (`subject_id`, `session_id`, `status`);

-- Attendance: Speed up date filtering, student attendance records, and percentage calculation
CREATE INDEX `idx_attendance_student_id` ON `attendance` (`student_id`);
CREATE INDEX `idx_attendance_subject_id` ON `attendance` (`subject_id`);
CREATE INDEX `idx_attendance_date` ON `attendance` (`attendance_date`);
CREATE INDEX `idx_attendance_status` ON `attendance` (`status`);
CREATE INDEX `idx_attendance_composite` ON `attendance` (`student_id`, `subject_id`, `status`);

-- Activity logs: Speed up user action audit queries
CREATE INDEX `idx_activity_user_id` ON `activity_logs` (`user_id`);
CREATE INDEX `idx_activity_created_at` ON `activity_logs` (`created_at`);
