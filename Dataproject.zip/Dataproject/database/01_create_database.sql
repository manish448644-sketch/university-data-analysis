-- ==============================================================================
-- PROJECT: Student Performance Analytics System
-- SCRIPT 01: Database Creation and Initialization
-- DBMS: MySQL 8.0+
-- ==============================================================================

-- Drop existing database if it exists to ensure a clean setup
DROP DATABASE IF EXISTS `student_analytics_db`;

-- Create database with UTF-8 Unicode character set support
CREATE DATABASE `student_analytics_db`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- Switch to the newly created database
USE `student_analytics_db`;

-- Verify database creation
SELECT 
    SCHEMA_NAME AS 'Database Name',
    DEFAULT_CHARACTER_SET_NAME AS 'Character Set',
    DEFAULT_COLLATION_NAME AS 'Collation'
FROM information_schema.SCHEMATA
WHERE SCHEMA_NAME = 'student_analytics_db';
