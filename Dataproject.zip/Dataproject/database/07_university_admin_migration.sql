-- ==============================================================================
-- PROJECT: Student Performance Analytics & University Administration System
-- SCRIPT 07: Complete University Administration Migration & Academic Structure
-- DBMS: MySQL 8.0+
-- Description: Adds departments, courses, classes/sections, teacher assignments,
--              assignments & submissions, admin notifications, and enhances
--              existing tables with zero breaking changes to Teacher Portal.
-- ==============================================================================

USE `student_analytics_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- ==============================================================================
-- 1. DEPARTMENTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS `departments` (
    `department_id` INT AUTO_INCREMENT PRIMARY KEY,
    `department_code` VARCHAR(20) NOT NULL UNIQUE,
    `department_name` VARCHAR(100) NOT NULL,
    `description` TEXT NULL,
    `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 2. COURSES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS `courses` (
    `course_id` INT AUTO_INCREMENT PRIMARY KEY,
    `course_code` VARCHAR(20) NOT NULL UNIQUE,
    `course_name` VARCHAR(100) NOT NULL,
    `department_id` INT NULL,
    `duration_years` DECIMAL(3,1) NOT NULL DEFAULT 2.0,
    `number_of_semesters` INT NOT NULL DEFAULT 4,
    `description` TEXT NULL,
    `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_course_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 3. CLASSES AND SECTIONS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS `classes_sections` (
    `section_id` INT AUTO_INCREMENT PRIMARY KEY,
    `section_name` VARCHAR(50) NOT NULL,
    `course_code` VARCHAR(20) NOT NULL,
    `semester` INT NOT NULL,
    `session_id` INT NULL,
    `capacity` INT NOT NULL DEFAULT 60,
    `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `uq_course_sem_sec_sess` UNIQUE (`course_code`, `semester`, `section_name`, `session_id`),
    CONSTRAINT `fk_section_session` FOREIGN KEY (`session_id`) REFERENCES `academic_sessions` (`session_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 4. TEACHER SUBJECT & SECTION ASSIGNMENTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS `teacher_assignments` (
    `assignment_id` INT AUTO_INCREMENT PRIMARY KEY,
    `teacher_id` INT NOT NULL,
    `subject_id` INT NOT NULL,
    `section_id` INT NULL,
    `session_id` INT NULL,
    `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    `assigned_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `uq_teacher_subject_section_session` UNIQUE (`teacher_id`, `subject_id`, `section_id`, `session_id`),
    CONSTRAINT `fk_ta_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_ta_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_ta_section` FOREIGN KEY (`section_id`) REFERENCES `classes_sections` (`section_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_ta_session` FOREIGN KEY (`session_id`) REFERENCES `academic_sessions` (`session_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 5. ACADEMIC ASSIGNMENTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS `assignments` (
    `assignment_id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(150) NOT NULL,
    `description` TEXT NULL,
    `subject_id` INT NOT NULL,
    `section_id` INT NULL,
    `teacher_id` INT NOT NULL,
    `session_id` INT NULL,
    `due_date` DATETIME NOT NULL,
    `max_marks` DECIMAL(5,2) NOT NULL DEFAULT 100.00,
    `status` ENUM('Active', 'Closed', 'Draft') NOT NULL DEFAULT 'Active',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_asgn_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_asgn_section` FOREIGN KEY (`section_id`) REFERENCES `classes_sections` (`section_id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_asgn_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_asgn_session` FOREIGN KEY (`session_id`) REFERENCES `academic_sessions` (`session_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 6. ASSIGNMENT SUBMISSIONS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS `assignment_submissions` (
    `submission_id` INT AUTO_INCREMENT PRIMARY KEY,
    `assignment_id` INT NOT NULL,
    `student_id` INT NOT NULL,
    `submission_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `obtained_marks` DECIMAL(5,2) NULL,
    `status` ENUM('Submitted', 'Graded', 'Late', 'Pending') NOT NULL DEFAULT 'Submitted',
    `remarks` VARCHAR(255) NULL,
    CONSTRAINT `uq_assignment_student` UNIQUE (`assignment_id`, `student_id`),
    CONSTRAINT `fk_sub_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`assignment_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_sub_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 7. ADMIN NOTIFICATIONS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS `admin_notifications` (
    `notification_id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(150) NOT NULL,
    `message` TEXT NOT NULL,
    `category` ENUM('Attendance', 'Marks', 'Assignment', 'Student', 'Course', 'System') NOT NULL DEFAULT 'System',
    `link_url` VARCHAR(255) NULL,
    `is_read` BOOLEAN NOT NULL DEFAULT FALSE,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- 8. ENHANCE EXISTING TABLES WITH BACKWARD-COMPATIBLE NULLABLE COLUMNS
-- ==============================================================================

-- 8.1 Users table: Add Department, Employee ID, Designation
ALTER TABLE `users`
    ADD COLUMN `department_id` INT NULL AFTER `role`,
    ADD COLUMN `employee_id` VARCHAR(50) NULL AFTER `department_id`,
    ADD COLUMN `designation` VARCHAR(100) NULL AFTER `employee_id`,
    ADD CONSTRAINT `fk_user_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- 8.2 Students table: Add Section and Academic Session
ALTER TABLE `students`
    ADD COLUMN `section_id` INT NULL AFTER `semester`,
    ADD COLUMN `session_id` INT NULL AFTER `section_id`,
    ADD CONSTRAINT `fk_student_section` FOREIGN KEY (`section_id`) REFERENCES `classes_sections` (`section_id`) ON DELETE SET NULL ON UPDATE CASCADE,
    ADD CONSTRAINT `fk_student_session` FOREIGN KEY (`session_id`) REFERENCES `academic_sessions` (`session_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- 8.3 Attendance table: Add Section and Teacher (who marked it)
ALTER TABLE `attendance`
    ADD COLUMN `section_id` INT NULL AFTER `subject_id`,
    ADD COLUMN `teacher_id` INT NULL AFTER `section_id`,
    ADD CONSTRAINT `fk_attendance_section` FOREIGN KEY (`section_id`) REFERENCES `classes_sections` (`section_id`) ON DELETE SET NULL ON UPDATE CASCADE,
    ADD CONSTRAINT `fk_attendance_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- 8.4 Marks table: Add Section and Teacher (who entered it)
ALTER TABLE `marks`
    ADD COLUMN `section_id` INT NULL AFTER `session_id`,
    ADD COLUMN `teacher_id` INT NULL AFTER `section_id`,
    ADD CONSTRAINT `fk_marks_section` FOREIGN KEY (`section_id`) REFERENCES `classes_sections` (`section_id`) ON DELETE SET NULL ON UPDATE CASCADE,
    ADD CONSTRAINT `fk_marks_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- 8.5 Subjects table: Add Department, Subject Type, and Status
ALTER TABLE `subjects`
    ADD COLUMN `department_id` INT NULL AFTER `semester`,
    ADD COLUMN `subject_type` ENUM('Core', 'Elective', 'Lab', 'Seminar') NOT NULL DEFAULT 'Core' AFTER `credits`,
    ADD COLUMN `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active' AFTER `subject_type`,
    ADD CONSTRAINT `fk_subject_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- 8.6 Academic Sessions table: Add Status
ALTER TABLE `academic_sessions`
    ADD COLUMN `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active' AFTER `is_current`;

-- 8.7 Activity Logs table: Add Academic Context Columns
ALTER TABLE `activity_logs`
    ADD COLUMN `course` VARCHAR(50) NULL AFTER `entity_id`,
    ADD COLUMN `semester` INT NULL AFTER `course`,
    ADD COLUMN `section_name` VARCHAR(50) NULL AFTER `semester`,
    ADD COLUMN `subject_name` VARCHAR(100) NULL AFTER `section_name`;

-- ==============================================================================
-- 9. POPULATE UNIVERSITY DATA
-- ==============================================================================

-- 9.1 Populate Departments
INSERT INTO `departments` (`department_id`, `department_code`, `department_name`, `description`, `status`) VALUES
(1, 'CSIT', 'Department of Computer Applications & IT', 'Undergraduate and Postgraduate computer applications and informatics programs.', 'Active'),
(2, 'CSE', 'Department of Computer Science & Engineering', 'Undergraduate engineering programs specializing in AI, systems, and hardware-software integration.', 'Active'),
(3, 'MGMT', 'School of Management Studies', 'Undergraduate and postgraduate business administration and management research.', 'Active'),
(4, 'MATH', 'Department of Computational Mathematics', 'Applied mathematics, statistical inference, and computational intelligence programs.', 'Active');

-- 9.2 Populate Courses
INSERT INTO `courses` (`course_id`, `course_code`, `course_name`, `department_id`, `duration_years`, `number_of_semesters`, `description`, `status`) VALUES
(1, 'MCA', 'Master of Computer Applications', 1, 2.0, 4, 'Premier postgraduate program focusing on advanced software development, cloud systems, and data analytics.', 'Active'),
(2, 'BCA', 'Bachelor of Computer Applications', 1, 3.0, 6, 'Foundational undergraduate degree in computing, programming paradigms, and web development.', 'Active'),
(3, 'B.Tech', 'Bachelor of Technology (Computer Science)', 2, 4.0, 8, 'Accredited undergraduate engineering program covering computer algorithms, systems architecture, and engineering principles.', 'Active'),
(4, 'MBA', 'Master of Business Administration', 3, 2.0, 4, 'Executive business analytics, project management, and enterprise administration program.', 'Active'),
(5, 'BBA', 'Bachelor of Business Administration', 3, 3.0, 6, 'Core foundation in corporate operations, organizational management, and finance.', 'Active'),
(6, 'B.Sc', 'Bachelor of Science (Computer Science)', 4, 3.0, 6, 'Theoretical computation, mathematical modeling, and scientific data computing.', 'Active');

-- 9.3 Populate Classes and Sections
INSERT INTO `classes_sections` (`section_id`, `section_name`, `course_code`, `semester`, `session_id`, `capacity`, `status`) VALUES
(1, 'MCA-A', 'MCA', 1, 2, 60, 'Active'),
(2, 'MCA-B', 'MCA', 1, 2, 60, 'Active'),
(3, 'MCA-2A', 'MCA', 2, 2, 60, 'Active'),
(4, 'MCA-2B', 'MCA', 2, 2, 60, 'Active'),
(5, 'MCA-3A', 'MCA', 3, 2, 60, 'Active'),
(6, 'MCA-4A', 'MCA', 4, 2, 60, 'Active'),
(7, 'BCA-1A', 'BCA', 1, 2, 60, 'Active'),
(8, 'BCA-1B', 'BCA', 1, 2, 60, 'Active'),
(9, 'BCA-2A', 'BCA', 2, 2, 60, 'Active'),
(10, 'BTECH-1A', 'B.Tech', 1, 2, 60, 'Active'),
(11, 'BTECH-2A', 'B.Tech', 2, 2, 60, 'Active'),
(12, 'BTECH-3A', 'B.Tech', 3, 2, 60, 'Active');

-- 9.4 Update existing User #2 and Add More Faculty Members
UPDATE `users` SET 
    `department_id` = 1,
    `employee_id` = 'EMP-CS-101',
    `designation` = 'Associate Professor'
WHERE `user_id` = 2;

INSERT INTO `users` (`user_id`, `full_name`, `email`, `phone`, `password_hash`, `role`, `department_id`, `employee_id`, `designation`, `status`) VALUES
(3, 'Dr. Sunita Verma', 'sunita.verma@analytics.com', '9876543212', 'scrypt:32768:8:1$X6RSgrVBRYGZ38bh$0501526bf9f1398ffb90b21b83ce485679b7bf3f7bc844bc439a3aa55708a591f95176642923ef208382ef60c81ee591a42e6a2368ed50747ac0bc22dababcc7', 'user', 1, 'EMP-CS-102', 'Professor', 'active'),
(4, 'Prof. Amit Patel', 'amit.patel@analytics.com', '9876543213', 'scrypt:32768:8:1$X6RSgrVBRYGZ38bh$0501526bf9f1398ffb90b21b83ce485679b7bf3f7bc844bc439a3aa55708a591f95176642923ef208382ef60c81ee591a42e6a2368ed50747ac0bc22dababcc7', 'user', 2, 'EMP-ENG-201', 'Assistant Professor', 'active'),
(5, 'Dr. Vikram Rao', 'vikram.rao@analytics.com', '9876543214', 'scrypt:32768:8:1$X6RSgrVBRYGZ38bh$0501526bf9f1398ffb90b21b83ce485679b7bf3f7bc844bc439a3aa55708a591f95176642923ef208382ef60c81ee591a42e6a2368ed50747ac0bc22dababcc7', 'user', 3, 'EMP-MG-305', 'Professor', 'active'),
(6, 'Dr. Ananya Mukherjee', 'ananya.m@analytics.com', '9876543215', 'scrypt:32768:8:1$X6RSgrVBRYGZ38bh$0501526bf9f1398ffb90b21b83ce485679b7bf3f7bc844bc439a3aa55708a591f95176642923ef208382ef60c81ee591a42e6a2368ed50747ac0bc22dababcc7', 'user', 1, 'EMP-CS-103', 'Assistant Professor', 'active');

-- 9.5 Assign Subjects to Departments
UPDATE `subjects` SET `department_id` = 1 WHERE `subject_id` IN (1, 2, 4, 5, 7);
UPDATE `subjects` SET `department_id` = 2 WHERE `subject_id` IN (3, 6, 8);

-- 9.6 Assign Teachers to Subjects and Sections
INSERT INTO `teacher_assignments` (`teacher_id`, `subject_id`, `section_id`, `session_id`, `status`) VALUES
(2, 2, 1, 2, 'Active'), -- Prof. Rajesh Sharma -> CS202 (Data Structures) -> MCA-A
(2, 2, 2, 2, 'Active'), -- Prof. Rajesh Sharma -> CS202 -> MCA-B
(2, 4, 1, 2, 'Active'), -- Prof. Rajesh Sharma -> CS204 (Python) -> MCA-A
(3, 1, 3, 2, 'Active'), -- Dr. Sunita Verma -> CS201 (Databases) -> MCA-2A
(3, 5, 3, 2, 'Active'), -- Dr. Sunita Verma -> CS205 (Full Stack) -> MCA-2A
(4, 3, 5, 2, 'Active'), -- Prof. Amit Patel -> CS203 (Machine Learning) -> MCA-3A
(4, 6, 5, 2, 'Active'), -- Prof. Amit Patel -> CS206 (Cloud Computing) -> MCA-3A
(6, 8, 1, 2, 'Active'), -- Dr. Ananya Mukherjee -> CS208 (Networks) -> MCA-A
(6, 7, 3, 2, 'Active'); -- Dr. Ananya Mukherjee -> CS207 (Software Eng) -> MCA-2A

-- 9.7 Link existing 500 Students to Sections and Academic Session 2
UPDATE `students` SET `session_id` = 2 WHERE `session_id` IS NULL;
UPDATE `students` SET `section_id` = 1 WHERE `course` = 'MCA' AND `semester` = 1 AND `student_id` % 2 = 1;
UPDATE `students` SET `section_id` = 2 WHERE `course` = 'MCA' AND `semester` = 1 AND `student_id` % 2 = 0;
UPDATE `students` SET `section_id` = 3 WHERE `course` = 'MCA' AND `semester` = 2 AND `student_id` % 2 = 1;
UPDATE `students` SET `section_id` = 4 WHERE `course` = 'MCA' AND `semester` = 2 AND `student_id` % 2 = 0;
UPDATE `students` SET `section_id` = 5 WHERE `course` = 'MCA' AND `semester` = 3;
UPDATE `students` SET `section_id` = 6 WHERE `course` = 'MCA' AND `semester` = 4;
UPDATE `students` SET `section_id` = 7 WHERE `course` = 'BCA' AND `semester` = 1 AND `student_id` % 2 = 1;
UPDATE `students` SET `section_id` = 8 WHERE `course` = 'BCA' AND `semester` = 1 AND `student_id` % 2 = 0;
UPDATE `students` SET `section_id` = 9 WHERE `course` = 'BCA' AND `semester` >= 2;
UPDATE `students` SET `section_id` = 10 WHERE `course` = 'B.Tech' AND `semester` = 1;
UPDATE `students` SET `section_id` = 11 WHERE `course` = 'B.Tech' AND `semester` = 2;
UPDATE `students` SET `section_id` = 12 WHERE `course` = 'B.Tech' AND `semester` >= 3;

-- 9.8 Update existing attendance and marks with section_id and teacher_id
UPDATE `attendance` a
INNER JOIN `students` s ON a.student_id = s.student_id
SET a.section_id = s.section_id, a.teacher_id = 2
WHERE a.section_id IS NULL;

UPDATE `marks` m
INNER JOIN `students` s ON m.student_id = s.student_id
SET m.section_id = s.section_id, m.teacher_id = 2
WHERE m.section_id IS NULL;

-- 9.9 Populate Assignments
INSERT INTO `assignments` (`assignment_id`, `title`, `description`, `subject_id`, `section_id`, `teacher_id`, `session_id`, `due_date`, `max_marks`, `status`) VALUES
(1, 'ER Modeling & Relational Algebra Case Study', 'Design an enterprise normalized schema (BCNF) with relational algebra proofs.', 1, 3, 3, 2, '2024-11-15 23:59:00', 100.00, 'Active'),
(2, 'Binary Search Tree & Balanced AVL Implementation', 'Implement dynamic AVL tree balancing in C++ or Python with benchmark tests.', 2, 1, 2, 2, '2024-11-20 23:59:00', 100.00, 'Active'),
(3, 'Supervised Machine Learning Classification', 'Develop a multi-class predictive classifier using scikit-learn on student performance data.', 3, 5, 4, 2, '2024-11-28 23:59:00', 100.00, 'Active'),
(4, 'RESTful API Development with Flask & MySQL', 'Build secured endpoints with JWT authentication and parameterized SQL queries.', 5, 3, 3, 2, '2024-11-10 23:59:00', 100.00, 'Closed'),
(5, 'Dockerization & CI/CD Pipeline Automation', 'Create Dockerfiles and GitHub Actions workflow for automated test execution.', 6, 5, 4, 2, '2024-12-05 23:59:00', 100.00, 'Active'),
(6, 'Network Packet Analyzer & Security Protocol Audit', 'Implement a packet sniffer and inspect SSL/TLS handshakes using Wireshark and Python scapy.', 8, 1, 6, 2, '2024-11-25 23:59:00', 100.00, 'Active');

-- 9.10 Populate Assignment Submissions
INSERT INTO `assignment_submissions` (`assignment_id`, `student_id`, `submission_date`, `obtained_marks`, `status`, `remarks`) VALUES
(1, 2, '2024-11-12 14:20:00', 92.50, 'Graded', 'Exceptional normalization proofs and ER diagram.'),
(1, 4, '2024-11-14 18:45:00', 58.00, 'Graded', 'Partial relational schema submitted.'),
(2, 1, '2024-11-18 10:15:00', 88.00, 'Graded', 'Efficient rotation routines and clean unit tests.'),
(2, 5, '2024-11-19 22:30:00', 74.00, 'Graded', 'Well documented code.'),
(3, 3, '2024-11-26 16:00:00', 85.00, 'Graded', 'Comprehensive confusion matrix analysis.'),
(3, 7, '2024-11-27 19:10:00', 90.00, 'Graded', 'Outstanding hyperparameter tuning.'),
(4, 2, '2024-11-09 11:30:00', 95.00, 'Graded', 'Perfect RESTful design with proper status codes.'),
(5, 3, '2024-12-01 14:00:00', NULL, 'Submitted', 'Pending faculty evaluation.'),
(6, 1, '2024-11-23 09:45:00', NULL, 'Submitted', 'Pending faculty evaluation.');

-- 9.11 Populate Admin Notifications
INSERT INTO `admin_notifications` (`notification_id`, `title`, `message`, `category`, `link_url`, `is_read`, `created_at`) VALUES
(1, 'Attendance Submission Alert', 'Prof. Rajesh Sharma submitted bi-weekly attendance for MCA-A in Data Structures (CS202).', 'Attendance', '/admin/monitoring/attendance', 0, '2024-10-21 11:30:00'),
(2, 'Marks Finalized Alert', 'Dr. Sunita Verma recorded Midterm assessment marks for 30 students in Advanced Database Systems (CS201).', 'Marks', '/admin/monitoring/marks', 0, '2024-10-18 16:45:00'),
(3, 'New Assignment Created', 'Prof. Amit Patel uploaded Assignment #3: Supervised Machine Learning for MCA-3A.', 'Assignment', '/admin/monitoring/assignments', 0, '2024-10-20 14:00:00'),
(4, 'Student Enrollment Milestone', '500 students actively registered and assigned to institutional academic sections for Session 2024-2025.', 'Student', '/admin/students', 1, '2024-09-30 18:00:00'),
(5, 'Academic Calendar Published', 'Session 2024-2025 marked as active current session. All semester sections initialized.', 'System', '/admin/sessions', 1, '2024-08-01 09:00:00');

-- 9.12 Add Activity Logs for Teacher Actions
INSERT INTO `activity_logs` (`user_id`, `action`, `entity_type`, `entity_id`, `course`, `semester`, `section_name`, `subject_name`, `details`, `ip_address`, `created_at`) VALUES
(2, 'Mark Attendance', 'Attendance', '2', 'MCA', 1, 'MCA-A', 'Data Structures & Algorithms', 'Marked lecture attendance for Section MCA-A', '127.0.0.1', '2024-10-21 10:45:00'),
(3, 'Add Marks', 'Marks', '1', 'MCA', 2, 'MCA-2A', 'Advanced Database Systems', 'Submitted Midterm marks for Section MCA-2A', '127.0.0.1', '2024-10-18 15:30:00'),
(4, 'Create Assignment', 'Assignment', '3', 'MCA', 3, 'MCA-3A', 'Machine Learning & AI', 'Published ML classification assignment with due date 2024-11-28', '127.0.0.1', '2024-10-20 12:15:00'),
(2, 'Update Profile', 'Users', '2', NULL, NULL, NULL, NULL, 'Updated academic office contact details', '127.0.0.1', '2024-10-15 09:20:00'),
(6, 'Mark Attendance', 'Attendance', '8', 'MCA', 1, 'MCA-A', 'Computer Networks & Security', 'Marked bi-weekly network security class attendance', '127.0.0.1', '2024-10-14 11:10:00');

SET FOREIGN_KEY_CHECKS = 1;
