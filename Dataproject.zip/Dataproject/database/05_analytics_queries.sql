-- ==============================================================================
-- PROJECT: Student Performance Analytics System
-- SCRIPT 05: Academic Analytics and MySQL Syllabus Queries
-- DBMS: MySQL 8.0+
-- Course / Level: Master of Computer Applications (MCA) Data Analytics
-- ==============================================================================

USE `student_analytics_db`;

-- ==============================================================================
-- SECTION 1: BASIC SELECT, WHERE, ORDER BY, AND COLUMN ALIASES
-- ==============================================================================

-- 1.1 Retrieve active MCA students ordered by Roll Number
SELECT 
    student_id AS 'Student ID',
    roll_number AS 'Roll Number',
    full_name AS 'Student Name',
    email AS 'Email Address',
    course AS 'Course',
    semester AS 'Current Semester',
    enrollment_date AS 'Enrollment Date'
FROM students
WHERE status = 'Active' AND course = 'MCA'
ORDER BY roll_number ASC;

-- 1.2 Retrieve top marks obtained in Final Examinations
SELECT 
    m.mark_id,
    s.roll_number,
    s.full_name,
    sub.subject_code,
    sub.subject_name,
    m.obtained_marks,
    m.percentage,
    m.grade
FROM marks m
INNER JOIN students s ON m.student_id = s.student_id
INNER JOIN subjects sub ON m.subject_id = sub.subject_id
WHERE m.exam_type = 'Final' AND m.percentage >= 80.00
ORDER BY m.percentage DESC, s.full_name ASC
LIMIT 15;


-- ==============================================================================
-- SECTION 2: SINGLE-ROW STRING AND NUMERIC FUNCTIONS
-- Demonstrating UPPER(), LOWER(), CONCAT(), ROUND(), LENGTH()
-- ==============================================================================

SELECT 
    student_id,
    UPPER(full_name) AS full_name_upper,
    LOWER(email) AS email_lower,
    CONCAT(roll_number, ' - ', full_name, ' (', course, ')') AS student_display_label,
    LENGTH(full_name) AS name_char_count,
    ROUND(AVG(obtained_marks), 2) AS rounded_avg_marks,
    ROUND(AVG(obtained_marks), 0) AS integer_approx_marks
FROM students s
LEFT JOIN marks m ON s.student_id = m.student_id
GROUP BY s.student_id, s.roll_number, s.full_name, s.email, s.course
LIMIT 10;


-- ==============================================================================
-- SECTION 3: CONVERSION AND DATE FORMATTING FUNCTIONS
-- Demonstrating CAST(), CONVERT(), DATE_FORMAT()
-- ==============================================================================

SELECT 
    m.mark_id,
    s.full_name,
    m.obtained_marks,
    CAST(m.obtained_marks AS CHAR(10)) AS marks_as_string,
    CONVERT(m.obtained_marks, SIGNED) AS marks_as_integer,
    m.exam_date,
    DATE_FORMAT(m.exam_date, '%W, %M %d, %Y') AS formatted_exam_date,
    DATE_FORMAT(m.exam_date, '%d-%b-%Y') AS standard_indian_format
FROM marks m
INNER JOIN students s ON m.student_id = s.student_id
WHERE m.exam_date IS NOT NULL
LIMIT 10;


-- ==============================================================================
-- SECTION 4: CONDITIONAL EXPRESSIONS
-- Demonstrating CASE WHEN ... THEN ... ELSE ... END, IF()
-- ==============================================================================

-- 4.1 Categorize performance tiers using CASE WHEN
SELECT 
    s.roll_number,
    s.full_name,
    ROUND(AVG(m.percentage), 2) AS overall_percentage,
    CASE 
        WHEN AVG(m.percentage) >= 85 THEN 'Tier 1: High Distinction'
        WHEN AVG(m.percentage) >= 70 THEN 'Tier 2: First Class'
        WHEN AVG(m.percentage) >= 50 THEN 'Tier 3: Pass Class'
        ELSE 'Tier 4: Needs Academic Intervention'
    END AS academic_classification,
    IF(AVG(m.percentage) >= 50, 'Promoted', 'Repeat Exam') AS promotion_status
FROM students s
INNER JOIN marks m ON s.student_id = m.student_id
GROUP BY s.student_id, s.roll_number, s.full_name
ORDER BY overall_percentage DESC
LIMIT 15;


-- ==============================================================================
-- SECTION 5: AGGREGATE FUNCTIONS & GROUP BY / HAVING
-- Demonstrating COUNT(), SUM(), AVG(), MIN(), MAX(), HAVING clause
-- ==============================================================================

-- 5.1 Subject-wise aggregate metrics with HAVING filter
SELECT 
    sub.subject_code,
    sub.subject_name,
    COUNT(m.mark_id) AS total_assessments,
    ROUND(AVG(m.obtained_marks), 2) AS avg_score,
    MIN(m.obtained_marks) AS lowest_score,
    MAX(m.obtained_marks) AS highest_score,
    SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) AS passed_count,
    ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / COUNT(m.mark_id)) * 100, 2) AS pass_percentage
FROM subjects sub
LEFT JOIN marks m ON sub.subject_id = m.subject_id
GROUP BY sub.subject_id, sub.subject_code, sub.subject_name
HAVING avg_score >= 60.00
ORDER BY avg_score DESC;

-- 5.2 Course and Semester Level Performance Summary
SELECT 
    course,
    semester,
    COUNT(DISTINCT s.student_id) AS total_enrolled,
    ROUND(AVG(m.percentage), 2) AS average_semester_percentage,
    COUNT(m.mark_id) AS total_grades_awarded
FROM students s
LEFT JOIN marks m ON s.student_id = m.student_id
GROUP BY course, semester
ORDER BY course, semester;


-- ==============================================================================
-- SECTION 6: JOINS (INNER, LEFT, MULTI-TABLE JOINS)
-- ==============================================================================

-- 6.1 Multi-table join combining Students, Academic Sessions, Subjects, Marks, and Attendance
SELECT 
    s.roll_number,
    s.full_name,
    sess.session_name,
    sub.subject_name,
    m.exam_type,
    m.obtained_marks,
    m.grade,
    m.status AS exam_result,
    att_stats.total_classes,
    att_stats.present_classes,
    att_stats.attendance_percentage
FROM students s
INNER JOIN marks m ON s.student_id = m.student_id
INNER JOIN subjects sub ON m.subject_id = sub.subject_id
INNER JOIN academic_sessions sess ON m.session_id = sess.session_id
LEFT JOIN (
    SELECT 
        student_id,
        subject_id,
        COUNT(*) AS total_classes,
        SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS present_classes,
        ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS attendance_percentage
    FROM attendance
    GROUP BY student_id, subject_id
) att_stats ON s.student_id = att_stats.student_id AND sub.subject_id = att_stats.subject_id
WHERE sess.is_current = 1
ORDER BY s.roll_number, sub.subject_code
LIMIT 20;


-- ==============================================================================
-- SECTION 7: SUBQUERIES (Scalar, Correlated, and IN/NOT IN)
-- ==============================================================================

-- 7.1 Students scoring above the overall institutional average
SELECT 
    s.roll_number,
    s.full_name,
    s.course,
    ROUND(AVG(m.obtained_marks), 2) AS student_avg_marks
FROM students s
INNER JOIN marks m ON s.student_id = m.student_id
GROUP BY s.student_id, s.roll_number, s.full_name, s.course
HAVING student_avg_marks > (
    SELECT AVG(obtained_marks) FROM marks
)
ORDER BY student_avg_marks DESC;

-- 7.2 Highest scoring student for each subject (Correlated subquery)
SELECT 
    sub.subject_code,
    sub.subject_name,
    s.roll_number,
    s.full_name,
    m1.obtained_marks AS top_score
FROM marks m1
INNER JOIN students s ON m1.student_id = s.student_id
INNER JOIN subjects sub ON m1.subject_id = sub.subject_id
WHERE m1.obtained_marks = (
    SELECT MAX(m2.obtained_marks)
    FROM marks m2
    WHERE m2.subject_id = m1.subject_id AND m2.exam_type = 'Final'
)
AND m1.exam_type = 'Final';

-- 7.3 Students with below-average institutional attendance (At Risk)
SELECT 
    s.roll_number,
    s.full_name,
    s.course,
    s.semester,
    att.student_attendance_pct
FROM students s
INNER JOIN (
    SELECT 
        student_id,
        ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS student_attendance_pct
    FROM attendance
    GROUP BY student_id
) att ON s.student_id = att.student_id
WHERE att.student_attendance_pct < 75.00
ORDER BY att.student_attendance_pct ASC;


-- ==============================================================================
-- SECTION 8: SET OPERATORS (UNION, UNION ALL, INTERSECT, EXCEPT)
-- ==============================================================================

-- 8.1 UNION ALL & UNION: Consolidating High Performers in Academics and Attendance
SELECT s.roll_number, s.full_name, 'Academic Star (>85% marks)' AS category
FROM students s
INNER JOIN marks m ON s.student_id = m.student_id
GROUP BY s.student_id, s.roll_number, s.full_name
HAVING AVG(m.percentage) >= 85.00

UNION

SELECT s.roll_number, s.full_name, 'Perfect Attendance (>90%)' AS category
FROM students s
INNER JOIN attendance a ON s.student_id = a.student_id
GROUP BY s.student_id, s.roll_number, s.full_name
HAVING (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100 >= 90.00;

-- 8.2 INTERSECT (Students who are BOTH Academic Stars AND have >85% attendance)
-- MySQL 8.0.31+ supports native INTERSECT. For backwards compatibility, INNER JOIN equivalent is provided:
SELECT academic_stars.roll_number, academic_stars.full_name
FROM (
    SELECT s.student_id, s.roll_number, s.full_name
    FROM students s
    INNER JOIN marks m ON s.student_id = m.student_id
    GROUP BY s.student_id, s.roll_number, s.full_name
    HAVING AVG(m.percentage) >= 80.00
) academic_stars
INNER JOIN (
    SELECT a.student_id
    FROM attendance a
    GROUP BY a.student_id
    HAVING (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100 >= 80.00
) high_attendance ON academic_stars.student_id = high_attendance.student_id;


-- ==============================================================================
-- SECTION 9: DATA DICTIONARY INSPECTION (INFORMATION_SCHEMA)
-- ==============================================================================

-- 9.1 Inspect all tables and row counts in our schema
SELECT 
    TABLE_NAME AS 'Table',
    TABLE_ROWS AS 'Estimated Rows',
    DATA_LENGTH / 1024 AS 'Data Size (KB)',
    INDEX_LENGTH / 1024 AS 'Index Size (KB)'
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'student_analytics_db';

-- 9.2 Inspect column definitions and data types
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT,
    COLUMN_KEY,
    EXTRA
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = 'student_analytics_db' AND TABLE_NAME = 'marks'
ORDER BY ORDINAL_POSITION;

-- 9.3 Inspect foreign key constraints
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = 'student_analytics_db' AND REFERENCED_TABLE_NAME IS NOT NULL;


-- ==============================================================================
-- SECTION 10: USER ACCESS CONTROL DEMONSTRATION (DBA ADMINISTRATION)
-- ==============================================================================

-- Optional script commands for user management
-- CREATE USER IF NOT EXISTS 'analytics_faculty'@'localhost' IDENTIFIED BY 'Faculty@Secure2025';
-- GRANT SELECT, INSERT, UPDATE ON student_analytics_db.marks TO 'analytics_faculty'@'localhost';
-- GRANT SELECT, INSERT, UPDATE ON student_analytics_db.attendance TO 'analytics_faculty'@'localhost';
-- GRANT SELECT ON student_analytics_db.students TO 'analytics_faculty'@'localhost';
-- GRANT SELECT ON student_analytics_db.subjects TO 'analytics_faculty'@'localhost';
-- FLUSH PRIVILEGES;
-- REVOKE INSERT, UPDATE ON student_analytics_db.attendance FROM 'analytics_faculty'@'localhost';
