-- ==============================================================================
-- PROJECT: Student Performance Analytics System
-- SCRIPT 06: Views, Stored Procedures, and Triggers
-- DBMS: MySQL 8.0+
-- ==============================================================================

USE `student_analytics_db`;

-- ==============================================================================
-- 1. VIEWS
-- ==============================================================================

-- 1.1 Overall Student Performance and Attendance Summary
DROP VIEW IF EXISTS `vw_student_overall_summary`;
CREATE VIEW `vw_student_overall_summary` AS
SELECT 
    s.student_id,
    s.roll_number,
    s.full_name,
    s.course,
    s.semester,
    s.status AS student_status,
    COUNT(DISTINCT m.mark_id) AS total_assessments,
    COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS average_marks,
    COALESCE(ROUND(AVG(m.percentage), 2), 0.00) AS overall_percentage,
    CASE 
        WHEN AVG(m.percentage) >= 90 THEN 'A+'
        WHEN AVG(m.percentage) >= 80 THEN 'A'
        WHEN AVG(m.percentage) >= 70 THEN 'B'
        WHEN AVG(m.percentage) >= 60 THEN 'C'
        WHEN AVG(m.percentage) >= 50 THEN 'D'
        ELSE 'F'
    END AS overall_grade,
    COALESCE(att_summary.total_classes, 0) AS total_classes,
    COALESCE(att_summary.attended_classes, 0) AS attended_classes,
    COALESCE(att_summary.attendance_pct, 0.00) AS attendance_percentage,
    CASE 
        WHEN COALESCE(att_summary.attendance_pct, 0.00) < 75.00 OR COALESCE(AVG(m.percentage), 0.00) < 50.00 THEN 'At Risk'
        ELSE 'Good Standing'
    END AS academic_standing
FROM students s
LEFT JOIN marks m ON s.student_id = m.student_id
LEFT JOIN (
    SELECT 
        student_id,
        COUNT(*) AS total_classes,
        SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_classes,
        ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS attendance_pct
    FROM attendance
    GROUP BY student_id
) att_summary ON s.student_id = att_summary.student_id
GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester, s.status, att_summary.total_classes, att_summary.attended_classes, att_summary.attendance_pct;


-- 1.2 Subject-wise Performance View
DROP VIEW IF EXISTS `vw_subject_performance`;
CREATE VIEW `vw_subject_performance` AS
SELECT 
    sub.subject_id,
    sub.subject_code,
    sub.subject_name,
    sub.course,
    sub.semester,
    sub.max_marks,
    sub.passing_marks,
    COUNT(m.mark_id) AS total_students_assessed,
    COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS average_score,
    COALESCE(MIN(m.obtained_marks), 0.00) AS minimum_score,
    COALESCE(MAX(m.obtained_marks), 0.00) AS maximum_score,
    SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) AS passed_count,
    SUM(CASE WHEN m.status = 'Fail' THEN 1 ELSE 0 END) AS failed_count,
    COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_percentage
FROM subjects sub
LEFT JOIN marks m ON sub.subject_id = m.subject_id
GROUP BY sub.subject_id, sub.subject_code, sub.subject_name, sub.course, sub.semester, sub.max_marks, sub.passing_marks;


-- 1.3 Students At Risk (Low Attendance or Low Marks)
DROP VIEW IF EXISTS `vw_at_risk_students`;
CREATE VIEW `vw_at_risk_students` AS
SELECT 
    v.student_id,
    v.roll_number,
    v.full_name,
    v.course,
    v.semester,
    v.overall_percentage,
    v.attendance_percentage,
    CASE 
        WHEN v.attendance_percentage < 75.00 AND v.overall_percentage < 50.00 THEN 'Critical (Attendance & Marks)'
        WHEN v.attendance_percentage < 75.00 THEN 'Low Attendance (<75%)'
        WHEN v.overall_percentage < 50.00 THEN 'Failing Academics (<50%)'
        ELSE 'Normal'
    END AS risk_factor
FROM vw_student_overall_summary v
WHERE v.academic_standing = 'At Risk';


-- ==============================================================================
-- 2. STORED PROCEDURES
-- ==============================================================================

DELIMITER $$

-- 2.1 Stored procedure to retrieve individual student marksheet
DROP PROCEDURE IF EXISTS `sp_get_student_marksheet`$$
CREATE PROCEDURE `sp_get_student_marksheet`(
    IN p_student_id INT,
    IN p_session_id INT
)
BEGIN
    SELECT 
        s.student_id,
        s.roll_number,
        s.full_name,
        s.course,
        s.semester,
        sub.subject_code,
        sub.subject_name,
        sub.max_marks,
        sub.passing_marks,
        m.exam_type,
        m.obtained_marks,
        m.percentage,
        m.grade,
        m.status,
        m.remarks,
        m.exam_date
    FROM marks m
    INNER JOIN students s ON m.student_id = s.student_id
    INNER JOIN subjects sub ON m.subject_id = sub.subject_id
    WHERE m.student_id = p_student_id
      AND (p_session_id IS NULL OR p_session_id = 0 OR m.session_id = p_session_id)
    ORDER BY sub.subject_code, m.exam_type;
END$$

-- 2.2 Stored procedure to calculate institutional dashboard KPIs
DROP PROCEDURE IF EXISTS `sp_calculate_dashboard_kpis`$$
CREATE PROCEDURE `sp_calculate_dashboard_kpis`()
BEGIN
    DECLARE v_total_students INT DEFAULT 0;
    DECLARE v_total_subjects INT DEFAULT 0;
    DECLARE v_avg_marks DECIMAL(5,2) DEFAULT 0.00;
    DECLARE v_pass_pct DECIMAL(5,2) DEFAULT 0.00;
    DECLARE v_avg_attendance DECIMAL(5,2) DEFAULT 0.00;
    DECLARE v_students_at_risk INT DEFAULT 0;

    -- Total Students
    SELECT COUNT(*) INTO v_total_students FROM students WHERE status = 'Active';

    -- Total Subjects
    SELECT COUNT(*) INTO v_total_subjects FROM subjects;

    -- Average Marks across all assessments
    SELECT COALESCE(ROUND(AVG(obtained_marks), 2), 0.00) INTO v_avg_marks FROM marks;

    -- Pass Percentage
    SELECT COALESCE(ROUND((SUM(CASE WHEN status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00)
    INTO v_pass_pct FROM marks;

    -- Average Attendance across institutional classes
    SELECT COALESCE(ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00)
    INTO v_avg_attendance FROM attendance;

    -- Students at Risk (using view)
    SELECT COUNT(*) INTO v_students_at_risk FROM vw_at_risk_students;

    -- Return as single row result set
    SELECT 
        v_total_students AS total_students,
        v_total_subjects AS total_subjects,
        v_avg_marks AS average_marks,
        v_pass_pct AS pass_percentage,
        v_avg_attendance AS average_attendance,
        v_students_at_risk AS students_at_risk;
END$$

DELIMITER ;


-- ==============================================================================
-- 3. TRIGGERS
-- ==============================================================================

DELIMITER $$

-- 3.1 Trigger after inserting marks
DROP TRIGGER IF EXISTS `trg_after_marks_insert`$$
CREATE TRIGGER `trg_after_marks_insert`
AFTER INSERT ON `marks`
FOR EACH ROW
BEGIN
    INSERT INTO `activity_logs` (`user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`)
    VALUES (
        NULL,
        'Marks Added',
        'Marks',
        CAST(NEW.mark_id AS CHAR(50)),
        CONCAT('Added ', NEW.exam_type, ' marks: ', NEW.obtained_marks, ' (', NEW.grade, ') for Student ID: ', NEW.student_id),
        'System Trigger'
    );
END$$

-- 3.2 Trigger after inserting student
DROP TRIGGER IF EXISTS `trg_after_student_insert`$$
CREATE TRIGGER `trg_after_student_insert`
AFTER INSERT ON `students`
FOR EACH ROW
BEGIN
    INSERT INTO `activity_logs` (`user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`)
    VALUES (
        NULL,
        'Student Enrolled',
        'Students',
        CAST(NEW.student_id AS CHAR(50)),
        CONCAT('Enrolled student: ', NEW.full_name, ' (Roll: ', NEW.roll_number, ', Course: ', NEW.course, ')'),
        'System Trigger'
    );
END$$

DELIMITER ;
