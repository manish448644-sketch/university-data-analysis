import os
import logging
from flask import Flask, render_template, request, session, redirect, url_for
from config import Config
from db import check_db_status

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger('StudentAnalyticsApp')

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Register Blueprints
    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.students import students_bp
    from routes.subjects import subjects_bp
    from routes.marks import marks_bp
    from routes.attendance import attendance_bp
    from routes.analytics import analytics_bp
    from routes.reports import reports_bp
    from routes.profile import profile_bp
    from routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(students_bp)
    app.register_blueprint(subjects_bp)
    app.register_blueprint(marks_bp)
    app.register_blueprint(attendance_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(profile_bp)
    app.register_blueprint(admin_bp)

    # Register Jinja global helper functions (max, min for pagination)
    app.jinja_env.globals.update(max=max, min=min)

    # Context processors for global template variables
    @app.context_processor
    def inject_global_data():
        return {
            'app_name': 'Student Performance Analytics',
            'current_user': {
                'id': session.get('user_id'),
                'name': session.get('full_name', 'Guest'),
                'email': session.get('email', ''),
                'role': session.get('role', 'user')
            },
            'is_logged_in': 'user_id' in session,
            'max': max,
            'min': min
        }

    # Error Handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('error.html', error_code=404, error_message="The requested resource was not found on this analytics server."), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('error.html', error_code=500, error_message="An internal server error occurred while processing the request."), 500

    @app.errorhandler(Exception)
    def handle_exception(e):
        logger.error(f"Unhandled exception: {e}", exc_info=True)
        # Check if database failure
        if 'mysql' in str(e).lower() or 'connection' in str(e).lower() or 'access denied' in str(e).lower():
            return render_template(
                'error.html',
                error_code='Database Connection Alert',
                error_message=f"Could not connect to MySQL Database '{Config.DB_NAME}'. Please verify your MySQL server is running and credentials in .env are correct.",
                error_details=str(e)
            ), 500
        return render_template('error.html', error_code=500, error_message=str(e)), 500

    return app

app = create_app()

if __name__ == '__main__':
    # Initial status check
    is_ok, msg = check_db_status()
    if is_ok:
        logger.info("Successfully established connection to MySQL Database.")
    else:
        logger.warning(f"MySQL connection check notification: {msg}")
        logger.info("Ensure MySQL 8 server is running and SQL scripts 01 through 06 have been executed.")

    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=Config.DEBUG)
