from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from db import execute_query, log_activity

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        if session.get('role') == 'admin':
            return redirect(url_for('admin.dashboard'))
        return redirect(url_for('dashboard.index'))
        
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        remember = request.form.get('remember') == 'on'
        
        if not email or not password:
            flash('Please enter both email and password.', 'danger')
            return render_template('login.html', email=email)
            
        try:
            query = "SELECT user_id, full_name, email, password_hash, role, status FROM users WHERE email = %s"
            user = execute_query(query, (email,), fetch='one')
            
            if user and check_password_hash(user['password_hash'], password):
                if user['status'] != 'active':
                    flash('Your account is currently inactive. Please contact the administrator.', 'warning')
                    return render_template('login.html', email=email)
                    
                # Update last login
                update_query = "UPDATE users SET last_login = NOW() WHERE user_id = %s"
                execute_query(update_query, (user['user_id'],), commit=True)
                
                # Setup session
                session.clear()
                session.permanent = remember
                session['user_id'] = user['user_id']
                session['full_name'] = user['full_name']
                session['email'] = user['email']
                session['role'] = user['role']
                
                log_activity(user['user_id'], 'User Login', 'Auth', user['user_id'], f"User {user['email']} logged in", request.remote_addr)
                
                flash(f"Welcome back, {user['full_name']}!", 'success')
                next_url = request.args.get('next')
                if next_url:
                    return redirect(next_url)
                if user['role'] == 'admin':
                    return redirect(url_for('admin.dashboard'))
                return redirect(url_for('dashboard.index'))
            else:
                flash('Invalid email address or password.', 'danger')
        except Exception as e:
            flash(f'Database error: Could not complete login. Please check MySQL server status. Details: {e}', 'danger')
            
    return render_template('login.html')

@auth_bp.route('/signup', methods=['GET', 'POST'])
def signup():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))
        
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip().lower()
        phone = request.form.get('phone', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        # Validations
        if not full_name or not email or not password:
            flash('Please fill in all required fields.', 'danger')
            return render_template('signup.html', full_name=full_name, email=email, phone=phone)
            
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('signup.html', full_name=full_name, email=email, phone=phone)
            
        if password != confirm_password:
            flash('Passwords do not match. Please re-enter.', 'danger')
            return render_template('signup.html', full_name=full_name, email=email, phone=phone)
            
        try:
            # Check existing user
            existing = execute_query("SELECT user_id FROM users WHERE email = %s", (email,), fetch='one')
            if existing:
                flash('An account with this email address already exists.', 'warning')
                return render_template('signup.html', full_name=full_name, phone=phone)
                
            # Create user
            pw_hash = generate_password_hash(password)
            insert_query = """
                INSERT INTO users (full_name, email, phone, password_hash, role, status)
                VALUES (%s, %s, %s, %s, 'user', 'active')
            """
            res = execute_query(insert_query, (full_name, email, phone, pw_hash), commit=True)
            new_id = res['last_insert_id']
            
            log_activity(new_id, 'User Registered', 'Users', new_id, f"Registered new account for {email}", request.remote_addr)
            flash('Registration successful! You may now sign in with your credentials.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            flash(f'Failed to register account: {e}', 'danger')
            
    return render_template('signup.html')

@auth_bp.route('/logout')
def logout():
    user_id = session.get('user_id')
    user_email = session.get('email')
    if user_id:
        log_activity(user_id, 'User Logout', 'Auth', user_id, f"User {user_email} logged out", request.remote_addr)
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        new_password = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        if not email:
            flash('Please enter your registered email address.', 'danger')
            return render_template('login.html', show_forgot=True)
            
        if new_password:
            if new_password != confirm_password:
                flash('New passwords do not match.', 'danger')
                return render_template('login.html', show_forgot=True, reset_email=email)
            if len(new_password) < 6:
                flash('Password must be at least 6 characters long.', 'danger')
                return render_template('login.html', show_forgot=True, reset_email=email)
                
            try:
                user = execute_query("SELECT user_id FROM users WHERE email = %s", (email,), fetch='one')
                if not user:
                    flash('No account found with this email address.', 'danger')
                    return render_template('login.html', show_forgot=True)
                    
                pw_hash = generate_password_hash(new_password)
                execute_query("UPDATE users SET password_hash = %s WHERE user_id = %s", (pw_hash, user['user_id']), commit=True)
                log_activity(user['user_id'], 'Password Reset', 'Users', user['user_id'], "User password updated via forgot password", request.remote_addr)
                flash('Your password has been successfully reset. Please log in with your new password.', 'success')
                return redirect(url_for('auth.login'))
            except Exception as e:
                flash(f'Error resetting password: {e}', 'danger')
        else:
            # Stage 1: Verify email exists
            user = execute_query("SELECT user_id, full_name FROM users WHERE email = %s", (email,), fetch='one')
            if user:
                flash(f"Account found for {user['full_name']}. Please enter your new password below.", 'info')
                return render_template('login.html', show_forgot=True, reset_email=email, email_verified=True)
            else:
                flash('No account registered with this email address.', 'danger')
                return render_template('login.html', show_forgot=True)
                
    return render_template('login.html', show_forgot=True)
