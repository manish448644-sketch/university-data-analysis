import math
import csv
import io
from datetime import datetime, date
from flask import (
    Blueprint, render_template, request, redirect, url_for,
    flash, jsonify, session, Response, make_response
)
from werkzeug.security import generate_password_hash
from routes import admin_required
from db import execute_query, check_db_status, log_activity, add_notification

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# -----------------------------------------------------------------------------
# CONTEXT PROCESSOR & NOTIFICATIONS HELPER
# -----------------------------------------------------------------------------
@admin_bp.context_processor
def inject_admin_context():
    """Provides unread notifications and university meta to all admin templates."""
    unread_count = 0
    recent_notifications = []
    try:
        count_res = execute_query(
            "SELECT COUNT(*) AS cnt FROM admin_notifications WHERE is_read = FALSE",
            fetch='one'
        )
        unread_count = count_res['cnt'] if count_res else 0
        recent_notifications = execute_query(
            "SELECT * FROM admin_notifications ORDER BY created_at DESC LIMIT 5"
        )
    except Exception:
        pass

    return {
        'admin_unread_notifications_count': unread_count,
        'admin_recent_notifications': recent_notifications,
        'current_admin_user': {
            'id': session.get('user_id'),
            'name': session.get('full_name', 'Administrator'),
            'email': session.get('email', 'admin@analytics.com'),
            'role': session.get('role', 'admin')
        }
    }

# =============================================================================
# 1. UNIVERSITY ADMIN DASHBOARD
# =============================================================================
@admin_bp.route('')
@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    db_ok, db_msg = check_db_status()
    
    # Defaults
    kpis = {
        'total_students': 0,
        'total_teachers': 0,
        'total_courses': 0,
        'total_subjects': 0,
        'total_sections': 0,
        'total_assignments': 0,
        'total_attendance': 0,
        'avg_performance': 0.00,
        'total_departments': 0,
        'active_sessions': 0,
        'pass_percentage': 0.00,
        'avg_attendance_pct': 0.00,
        'at_risk_students_count': 0
    }
    
    recent_students = []
    recent_courses = []
    recent_subjects = []
    recent_attendance = []
    recent_marks = []
    recent_assignments = []
    teacher_stats = []
    latest_teacher_activities = []
    at_risk_preview = []
    course_performance = []

    if db_ok:
        try:
            # 1. Total Students
            r = execute_query("SELECT COUNT(*) AS cnt FROM students WHERE status = 'Active'", fetch='one')
            kpis['total_students'] = r['cnt'] if r else 0

            # 2. Total Teachers (users with role='user')
            r = execute_query("SELECT COUNT(*) AS cnt FROM users WHERE role = 'user' AND status = 'active'", fetch='one')
            kpis['total_teachers'] = r['cnt'] if r else 0

            # 3. Total Courses
            r = execute_query("SELECT COUNT(*) AS cnt FROM courses WHERE status = 'Active'", fetch='one')
            kpis['total_courses'] = r['cnt'] if r else 0

            # 4. Total Subjects
            r = execute_query("SELECT COUNT(*) AS cnt FROM subjects WHERE status = 'Active'", fetch='one')
            kpis['total_subjects'] = r['cnt'] if r else 0

            # 5. Total Classes / Sections
            r = execute_query("SELECT COUNT(*) AS cnt FROM classes_sections WHERE status = 'Active'", fetch='one')
            kpis['total_sections'] = r['cnt'] if r else 0

            # 6. Total Assignments
            r = execute_query("SELECT COUNT(*) AS cnt FROM assignments", fetch='one')
            kpis['total_assignments'] = r['cnt'] if r else 0

            # 7. Total Attendance Records
            r = execute_query("SELECT COUNT(*) AS cnt FROM attendance", fetch='one')
            kpis['total_attendance'] = r['cnt'] if r else 0

            # 8. Average Student Performance
            r = execute_query("""
                SELECT 
                    COALESCE(ROUND(AVG(obtained_marks), 2), 0.00) AS avg_marks,
                    COALESCE(ROUND((SUM(CASE WHEN status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00) AS pass_pct
                FROM marks
            """, fetch='one')
            if r:
                kpis['avg_performance'] = float(r['avg_marks'])
                kpis['pass_percentage'] = float(r['pass_pct'])

            # 9. Departments and Sessions
            r_dept = execute_query("SELECT COUNT(*) AS cnt FROM departments WHERE status = 'Active'", fetch='one')
            kpis['total_departments'] = r_dept['cnt'] if r_dept else 0

            r_sess = execute_query("SELECT COUNT(*) AS cnt FROM academic_sessions WHERE status = 'Active' OR is_current = 1", fetch='one')
            kpis['active_sessions'] = r_sess['cnt'] if r_sess else 0

            # 10. Overall Attendance %
            r_att = execute_query("""
                SELECT COALESCE(ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00) AS att_pct
                FROM attendance
            """, fetch='one')
            kpis['avg_attendance_pct'] = float(r_att['att_pct']) if r_att else 0.00

            # 11. Students at risk count (<75% attendance or <50% average marks)
            r_risk = execute_query("SELECT COUNT(*) AS cnt FROM vw_at_risk_students", fetch='one')
            kpis['at_risk_students_count'] = r_risk['cnt'] if r_risk else 0

            # SECTION B: Academic Activity Overview
            recent_students = execute_query("""
                SELECT student_id, roll_number, full_name, course, semester, enrollment_date, status
                FROM students ORDER BY student_id DESC LIMIT 5
            """)
            
            recent_courses = execute_query("""
                SELECT c.*, d.department_name,
                       (SELECT COUNT(*) FROM students s WHERE s.course = c.course_code) AS student_count
                FROM courses c
                LEFT JOIN departments d ON c.department_id = d.department_id
                ORDER BY c.course_id DESC LIMIT 5
            """)
            
            recent_subjects = execute_query("""
                SELECT sub.*, d.department_name
                FROM subjects sub
                LEFT JOIN departments d ON sub.department_id = d.department_id
                ORDER BY sub.subject_id DESC LIMIT 5
            """)
            
            recent_attendance = execute_query("""
                SELECT a.*, s.roll_number, s.full_name AS student_name, sub.subject_code, sub.subject_name,
                       COALESCE(u.full_name, 'Faculty Member') AS teacher_name,
                       cs.section_name
                FROM attendance a
                INNER JOIN students s ON a.student_id = s.student_id
                INNER JOIN subjects sub ON a.subject_id = sub.subject_id
                LEFT JOIN users u ON a.teacher_id = u.user_id
                LEFT JOIN classes_sections cs ON a.section_id = cs.section_id
                ORDER BY a.attendance_date DESC, a.attendance_id DESC LIMIT 6
            """)

            recent_marks = execute_query("""
                SELECT m.*, s.roll_number, s.full_name AS student_name, sub.subject_code, sub.subject_name,
                       COALESCE(u.full_name, 'Faculty Member') AS teacher_name,
                       cs.section_name
                FROM marks m
                INNER JOIN students s ON m.student_id = s.student_id
                INNER JOIN subjects sub ON m.subject_id = sub.subject_id
                LEFT JOIN users u ON m.teacher_id = u.user_id
                LEFT JOIN classes_sections cs ON m.section_id = cs.section_id
                ORDER BY m.mark_id DESC LIMIT 6
            """)

            recent_assignments = execute_query("""
                SELECT asgn.*, sub.subject_code, sub.subject_name, u.full_name AS teacher_name,
                       cs.section_name,
                       (SELECT COUNT(*) FROM assignment_submissions sub_s WHERE sub_s.assignment_id = asgn.assignment_id) AS submissions_count
                FROM assignments asgn
                INNER JOIN subjects sub ON asgn.subject_id = sub.subject_id
                INNER JOIN users u ON asgn.teacher_id = u.user_id
                LEFT JOIN classes_sections cs ON asgn.section_id = cs.section_id
                ORDER BY asgn.assignment_id DESC LIMIT 5
            """)

            # SECTION C: Teacher Activity Overview
            teacher_stats = execute_query("""
                SELECT u.user_id, u.full_name, u.email, u.designation, d.department_code,
                       (SELECT COUNT(*) FROM attendance a WHERE a.teacher_id = u.user_id) AS attendance_marked_count,
                       (SELECT COUNT(*) FROM marks m WHERE m.teacher_id = u.user_id) AS marks_entered_count,
                       (SELECT COUNT(*) FROM assignments asgn WHERE asgn.teacher_id = u.user_id) AS assignments_created_count,
                       (SELECT COUNT(*) FROM teacher_assignments ta WHERE ta.teacher_id = u.user_id AND ta.status = 'Active') AS assigned_classes_count,
                       u.last_login
                FROM users u
                LEFT JOIN departments d ON u.department_id = d.department_id
                WHERE u.role = 'user' AND u.status = 'active'
                ORDER BY (attendance_marked_count + marks_entered_count + assignments_created_count) DESC
                LIMIT 6
            """)

            latest_teacher_activities = execute_query("""
                SELECT act.*, u.full_name AS teacher_name, u.role, u.email
                FROM activity_logs act
                LEFT JOIN users u ON act.user_id = u.user_id
                ORDER BY act.created_at DESC LIMIT 10
            """)

            # SECTION D: Performance Overview Preview
            at_risk_preview = execute_query("""
                SELECT * FROM vw_at_risk_students LIMIT 6
            """)

            course_performance = execute_query("""
                SELECT s.course,
                       COUNT(DISTINCT s.student_id) AS total_enrolled,
                       COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
                       COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_pct
                FROM students s
                LEFT JOIN marks m ON s.student_id = m.student_id
                GROUP BY s.course
                ORDER BY s.course
            """)
        except Exception as e:
            flash(f"Error loading dashboard metrics: {e}", "danger")

    return render_template(
        'admin/dashboard.html',
        kpis=kpis,
        recent_students=recent_students,
        recent_courses=recent_courses,
        recent_subjects=recent_subjects,
        recent_attendance=recent_attendance,
        recent_marks=recent_marks,
        recent_assignments=recent_assignments,
        teacher_stats=teacher_stats,
        latest_teacher_activities=latest_teacher_activities,
        at_risk_preview=at_risk_preview,
        course_performance=course_performance,
        db_ok=db_ok,
        db_msg=db_msg
    )

@admin_bp.route('/api/dashboard-charts')
@admin_required
def dashboard_charts_api():
    """Async endpoint providing Chart.js dataset for University Admin Dashboard."""
    try:
        # 1. Course-wise Performance
        courses_res = execute_query("""
            SELECT s.course,
                   COUNT(DISTINCT s.student_id) AS student_count,
                   COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_score,
                   COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_rate
            FROM students s
            LEFT JOIN marks m ON s.student_id = m.student_id
            GROUP BY s.course
            ORDER BY s.course
        """)

        # 2. Section-wise Performance
        sections_res = execute_query("""
            SELECT cs.section_name,
                   COUNT(DISTINCT s.student_id) AS enrolled_students,
                   COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_score
            FROM classes_sections cs
            LEFT JOIN students s ON cs.section_id = s.section_id
            LEFT JOIN marks m ON s.student_id = m.student_id
            GROUP BY cs.section_id, cs.section_name
            ORDER BY cs.section_name
            LIMIT 8
        """)

        # 3. Subject-wise Average Marks
        subjects_res = execute_query("""
            SELECT sub.subject_code, sub.subject_name,
                   COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_score,
                   COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_rate
            FROM subjects sub
            LEFT JOIN marks m ON sub.subject_id = m.subject_id
            GROUP BY sub.subject_id, sub.subject_code, sub.subject_name
            ORDER BY sub.subject_code
        """)

        # 4. Grade Distribution
        grades_res = execute_query("""
            SELECT grade, COUNT(*) AS count
            FROM marks
            WHERE grade IS NOT NULL AND grade != ''
            GROUP BY grade
            ORDER BY FIELD(grade, 'A+', 'A', 'B', 'C', 'D', 'F')
        """)

        # 5. Attendance Breakdown (Present, Absent, Late, Excused)
        attendance_res = execute_query("""
            SELECT status, COUNT(*) AS count
            FROM attendance
            GROUP BY status
        """)

        return jsonify({
            'success': True,
            'courses': courses_res or [],
            'sections': sections_res or [],
            'subjects': subjects_res or [],
            'grades': grades_res or [],
            'attendance': attendance_res or []
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# =============================================================================
# 2. COURSE MANAGEMENT
# =============================================================================
@admin_bp.route('/courses')
@admin_required
def courses():
    search = request.args.get('search', '').strip()
    dept_filter = request.args.get('department_id', '').strip()
    status_filter = request.args.get('status', '').strip()

    conditions = []
    params = []

    if search:
        conditions.append("(c.course_code LIKE %s OR c.course_name LIKE %s)")
        term = f"%{search}%"
        params.extend([term, term])
    if dept_filter:
        conditions.append("c.department_id = %s")
        params.append(int(dept_filter))
    if status_filter:
        conditions.append("c.status = %s")
        params.append(status_filter)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    query = f"""
        SELECT c.*, d.department_name, d.department_code,
               (SELECT COUNT(*) FROM students s WHERE s.course = c.course_code) AS enrolled_students_count,
               (SELECT COUNT(DISTINCT ta.teacher_id) FROM teacher_assignments ta 
                INNER JOIN subjects sub ON ta.subject_id = sub.subject_id 
                WHERE sub.course = c.course_code) AS assigned_teachers_count,
               (SELECT COUNT(*) FROM subjects sub WHERE sub.course = c.course_code) AS subjects_count,
               (SELECT COUNT(*) FROM classes_sections cs WHERE cs.course_code = c.course_code) AS sections_count
        FROM courses c
        LEFT JOIN departments d ON c.department_id = d.department_id
        {where_clause}
        ORDER BY c.course_code ASC
    """
    course_list = execute_query(query, params)
    departments_list = execute_query("SELECT department_id, department_code, department_name FROM departments WHERE status = 'Active' ORDER BY department_name")

    return render_template(
        'admin/courses.html',
        courses=course_list or [],
        departments=departments_list or [],
        search=search,
        dept_filter=dept_filter,
        status_filter=status_filter
    )

@admin_bp.route('/courses/add', methods=['POST'])
@admin_required
def course_add():
    course_code = request.form.get('course_code', '').strip().upper()
    course_name = request.form.get('course_name', '').strip()
    department_id = request.form.get('department_id') or None
    duration_years = request.form.get('duration_years', 2.0)
    number_of_semesters = request.form.get('number_of_semesters', 4)
    description = request.form.get('description', '').strip()
    status = request.form.get('status', 'Active')

    if not course_code or not course_name:
        flash("Course code and course name are required.", "danger")
        return redirect(url_for('admin.courses'))

    try:
        # Check duplicate
        existing = execute_query("SELECT course_id FROM courses WHERE course_code = %s", (course_code,), fetch='one')
        if existing:
            flash(f"A course with code '{course_code}' already exists.", "warning")
            return redirect(url_for('admin.courses'))

        insert_q = """
            INSERT INTO courses (course_code, course_name, department_id, duration_years, number_of_semesters, description, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        res = execute_query(
            insert_q,
            (course_code, course_name, department_id, float(duration_years), int(number_of_semesters), description, status),
            commit=True
        )

        log_activity(
            session.get('user_id'), 'Create Course', 'Course', res['last_insert_id'],
            f"Created university course {course_code} - {course_name}", request.remote_addr,
            course=course_code
        )
        add_notification(
            "New University Course Created",
            f"Course {course_code} ({course_name}) was successfully added and is now available university-wide.",
            category="Course",
            link_url="/admin/courses"
        )
        flash(f"Course '{course_code} - {course_name}' created successfully.", "success")
    except Exception as e:
        flash(f"Error creating course: {e}", "danger")

    return redirect(url_for('admin.courses'))

@admin_bp.route('/courses/edit/<int:course_id>', methods=['POST'])
@admin_required
def course_edit(course_id):
    course_name = request.form.get('course_name', '').strip()
    department_id = request.form.get('department_id') or None
    duration_years = request.form.get('duration_years', 2.0)
    number_of_semesters = request.form.get('number_of_semesters', 4)
    description = request.form.get('description', '').strip()
    status = request.form.get('status', 'Active')

    try:
        update_q = """
            UPDATE courses 
            SET course_name = %s, department_id = %s, duration_years = %s, number_of_semesters = %s, description = %s, status = %s
            WHERE course_id = %s
        """
        execute_query(
            update_q,
            (course_name, department_id, float(duration_years), int(number_of_semesters), description, status, course_id),
            commit=True
        )
        log_activity(session.get('user_id'), 'Update Course', 'Course', course_id, f"Updated course details for ID {course_id}", request.remote_addr)
        flash("Course updated successfully.", "success")
    except Exception as e:
        flash(f"Error updating course: {e}", "danger")

    return redirect(url_for('admin.courses'))

@admin_bp.route('/courses/delete/<int:course_id>', methods=['POST'])
@admin_required
def course_delete(course_id):
    try:
        # Check if students are actively enrolled
        c_info = execute_query("SELECT course_code, course_name FROM courses WHERE course_id = %s", (course_id,), fetch='one')
        if c_info:
            cnt = execute_query("SELECT COUNT(*) AS cnt FROM students WHERE course = %s", (c_info['course_code'],), fetch='one')
            if cnt and cnt['cnt'] > 0:
                # Deactivate instead of hard delete to preserve foreign integrity
                execute_query("UPDATE courses SET status = 'Inactive' WHERE course_id = %s", (course_id,), commit=True)
                flash(f"Course '{c_info['course_code']}' has {cnt['cnt']} enrolled students. It has been marked Inactive to preserve academic records.", "warning")
            else:
                execute_query("DELETE FROM courses WHERE course_id = %s", (course_id,), commit=True)
                flash(f"Course '{c_info['course_code']}' deleted successfully.", "success")
            log_activity(session.get('user_id'), 'Deactivate/Delete Course', 'Course', course_id, f"Processed course removal for {c_info['course_code']}", request.remote_addr)
    except Exception as e:
        flash(f"Error processing course removal: {e}", "danger")

    return redirect(url_for('admin.courses'))

# =============================================================================
# 3. DEPARTMENT MANAGEMENT
# =============================================================================
@admin_bp.route('/departments')
@admin_required
def departments():
    query = """
        SELECT d.*,
               (SELECT COUNT(*) FROM courses c WHERE c.department_id = d.department_id) AS courses_count,
               (SELECT COUNT(*) FROM users u WHERE u.department_id = d.department_id AND u.role = 'user') AS teachers_count,
               (SELECT COUNT(*) FROM subjects sub WHERE sub.department_id = d.department_id) AS subjects_count
        FROM departments d
        ORDER BY d.department_name ASC
    """
    dept_list = execute_query(query)
    return render_template('admin/departments.html', departments=dept_list or [])

@admin_bp.route('/departments/add', methods=['POST'])
@admin_required
def department_add():
    dept_code = request.form.get('department_code', '').strip().upper()
    dept_name = request.form.get('department_name', '').strip()
    description = request.form.get('description', '').strip()
    status = request.form.get('status', 'Active')

    if not dept_code or not dept_name:
        flash("Department code and name are required.", "danger")
        return redirect(url_for('admin.departments'))

    try:
        existing = execute_query("SELECT department_id FROM departments WHERE department_code = %s", (dept_code,), fetch='one')
        if existing:
            flash(f"Department code '{dept_code}' already exists.", "warning")
            return redirect(url_for('admin.departments'))

        q = "INSERT INTO departments (department_code, department_name, description, status) VALUES (%s, %s, %s, %s)"
        res = execute_query(q, (dept_code, dept_name, description, status), commit=True)
        log_activity(session.get('user_id'), 'Create Department', 'Department', res['last_insert_id'], f"Created department {dept_code} - {dept_name}", request.remote_addr)
        flash(f"Department '{dept_name}' added successfully.", "success")
    except Exception as e:
        flash(f"Error creating department: {e}", "danger")

    return redirect(url_for('admin.departments'))

@admin_bp.route('/departments/edit/<int:dept_id>', methods=['POST'])
@admin_required
def department_edit(dept_id):
    dept_name = request.form.get('department_name', '').strip()
    description = request.form.get('description', '').strip()
    status = request.form.get('status', 'Active')

    try:
        q = "UPDATE departments SET department_name = %s, description = %s, status = %s WHERE department_id = %s"
        execute_query(q, (dept_name, description, status, dept_id), commit=True)
        log_activity(session.get('user_id'), 'Update Department', 'Department', dept_id, f"Updated department ID {dept_id}", request.remote_addr)
        flash("Department details updated successfully.", "success")
    except Exception as e:
        flash(f"Error updating department: {e}", "danger")

    return redirect(url_for('admin.departments'))

@admin_bp.route('/departments/delete/<int:dept_id>', methods=['POST'])
@admin_required
def department_delete(dept_id):
    try:
        execute_query("UPDATE departments SET status = 'Inactive' WHERE department_id = %s", (dept_id,), commit=True)
        log_activity(session.get('user_id'), 'Deactivate Department', 'Department', dept_id, f"Deactivated department {dept_id}", request.remote_addr)
        flash("Department status set to Inactive.", "info")
    except Exception as e:
        flash(f"Error deactivating department: {e}", "danger")

    return redirect(url_for('admin.departments'))

# =============================================================================
# 4. SUBJECT MANAGEMENT
# =============================================================================
@admin_bp.route('/subjects')
@admin_required
def subjects():
    course_filter = request.args.get('course', '').strip()
    sem_filter = request.args.get('semester', '').strip()
    dept_filter = request.args.get('department_id', '').strip()

    conditions = []
    params = []

    if course_filter:
        conditions.append("sub.course = %s")
        params.append(course_filter)
    if sem_filter:
        conditions.append("sub.semester = %s")
        params.append(int(sem_filter))
    if dept_filter:
        conditions.append("sub.department_id = %s")
        params.append(int(dept_filter))

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    query = f"""
        SELECT sub.*, d.department_name, d.department_code,
               (SELECT COUNT(DISTINCT ta.teacher_id) FROM teacher_assignments ta WHERE ta.subject_id = sub.subject_id AND ta.status = 'Active') AS assigned_faculty_count,
               (SELECT COUNT(*) FROM marks m WHERE m.subject_id = sub.subject_id) AS marks_records_count,
               (SELECT COUNT(*) FROM attendance a WHERE a.subject_id = sub.subject_id) AS attendance_records_count
        FROM subjects sub
        LEFT JOIN departments d ON sub.department_id = d.department_id
        {where_clause}
        ORDER BY sub.course ASC, sub.semester ASC, sub.subject_code ASC
    """
    subject_list = execute_query(query, params)

    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")
    departments_list = execute_query("SELECT department_id, department_name FROM departments WHERE status = 'Active' ORDER BY department_name")

    return render_template(
        'admin/subjects.html',
        subjects=subject_list or [],
        courses=courses_list or [],
        departments=departments_list or [],
        course_filter=course_filter,
        sem_filter=sem_filter,
        dept_filter=dept_filter
    )

@admin_bp.route('/subjects/add', methods=['POST'])
@admin_required
def subject_add():
    subject_code = request.form.get('subject_code', '').strip().upper()
    subject_name = request.form.get('subject_name', '').strip()
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester')
    department_id = request.form.get('department_id') or None
    subject_type = request.form.get('subject_type', 'Core')
    max_marks = request.form.get('max_marks', 100.0)
    passing_marks = request.form.get('passing_marks', 50.0)
    credits = request.form.get('credits', 4)
    status = request.form.get('status', 'Active')

    if not subject_code or not subject_name or not course or not semester:
        flash("Subject code, name, course, and semester are mandatory.", "danger")
        return redirect(url_for('admin.subjects'))

    try:
        existing = execute_query("SELECT subject_id FROM subjects WHERE subject_code = %s", (subject_code,), fetch='one')
        if existing:
            flash(f"Subject with code '{subject_code}' already exists.", "warning")
            return redirect(url_for('admin.subjects'))

        q = """
            INSERT INTO subjects (subject_code, subject_name, course, semester, department_id, subject_type, max_marks, passing_marks, credits, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        res = execute_query(
            q,
            (subject_code, subject_name, course, int(semester), department_id, subject_type, float(max_marks), float(passing_marks), int(credits), status),
            commit=True
        )

        log_activity(
            session.get('user_id'), 'Create Subject', 'Subject', res['last_insert_id'],
            f"Added subject {subject_code} - {subject_name} ({course} Sem {semester})", request.remote_addr,
            course=course, semester=int(semester), subject_name=subject_name
        )
        add_notification(
            "New Academic Subject Added",
            f"Subject {subject_code} ({subject_name}) is now registered for {course} Semester {semester} and available to faculty.",
            category="Course",
            link_url="/admin/subjects"
        )
        flash(f"Subject '{subject_code} - {subject_name}' created and ready for faculty assignment.", "success")
    except Exception as e:
        flash(f"Error adding subject: {e}", "danger")

    return redirect(url_for('admin.subjects'))

@admin_bp.route('/subjects/edit/<int:subject_id>', methods=['POST'])
@admin_required
def subject_edit(subject_id):
    subject_name = request.form.get('subject_name', '').strip()
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester')
    department_id = request.form.get('department_id') or None
    subject_type = request.form.get('subject_type', 'Core')
    max_marks = request.form.get('max_marks', 100.0)
    passing_marks = request.form.get('passing_marks', 50.0)
    credits = request.form.get('credits', 4)
    status = request.form.get('status', 'Active')

    try:
        q = """
            UPDATE subjects
            SET subject_name = %s, course = %s, semester = %s, department_id = %s, subject_type = %s,
                max_marks = %s, passing_marks = %s, credits = %s, status = %s
            WHERE subject_id = %s
        """
        execute_query(
            q,
            (subject_name, course, int(semester), department_id, subject_type, float(max_marks), float(passing_marks), int(credits), status, subject_id),
            commit=True
        )
        log_activity(session.get('user_id'), 'Update Subject', 'Subject', subject_id, f"Updated subject ID {subject_id}", request.remote_addr)
        flash("Subject specifications updated successfully.", "success")
    except Exception as e:
        flash(f"Error updating subject: {e}", "danger")

    return redirect(url_for('admin.subjects'))

@admin_bp.route('/subjects/delete/<int:subject_id>', methods=['POST'])
@admin_required
def subject_delete(subject_id):
    try:
        # Check if marks or attendance records depend on it
        m_cnt = execute_query("SELECT COUNT(*) AS cnt FROM marks WHERE subject_id = %s", (subject_id,), fetch='one')
        a_cnt = execute_query("SELECT COUNT(*) AS cnt FROM attendance WHERE subject_id = %s", (subject_id,), fetch='one')
        total_dep = (m_cnt['cnt'] if m_cnt else 0) + (a_cnt['cnt'] if a_cnt else 0)

        if total_dep > 0:
            execute_query("UPDATE subjects SET status = 'Inactive' WHERE subject_id = %s", (subject_id,), commit=True)
            flash("Subject has associated academic assessment or attendance records. Set to Inactive to preserve student transcripts.", "warning")
        else:
            execute_query("DELETE FROM subjects WHERE subject_id = %s", (subject_id,), commit=True)
            flash("Subject removed successfully.", "success")
        log_activity(session.get('user_id'), 'Delete/Deactivate Subject', 'Subject', subject_id, "Subject status changed", request.remote_addr)
    except Exception as e:
        flash(f"Error deleting subject: {e}", "danger")

    return redirect(url_for('admin.subjects'))

# =============================================================================
# 5. ACADEMIC SESSION MANAGEMENT
# =============================================================================
@admin_bp.route('/sessions')
@admin_required
def sessions():
    sessions_list = execute_query("""
        SELECT sess.*,
               (SELECT COUNT(*) FROM students s WHERE s.session_id = sess.session_id) AS enrolled_students_count,
               (SELECT COUNT(*) FROM classes_sections cs WHERE cs.session_id = sess.session_id) AS sections_count,
               (SELECT COUNT(*) FROM marks m WHERE m.session_id = sess.session_id) AS marks_records_count
        FROM academic_sessions sess
        ORDER BY sess.start_date DESC
    """)
    return render_template('admin/sessions.html', sessions=sessions_list or [])

@admin_bp.route('/sessions/add', methods=['POST'])
@admin_required
def session_add():
    session_name = request.form.get('session_name', '').strip()
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    is_current = 1 if request.form.get('is_current') == 'on' else 0
    status = request.form.get('status', 'Active')

    if not session_name or not start_date or not end_date:
        flash("Session name, start date, and end date are required.", "danger")
        return redirect(url_for('admin.sessions'))

    try:
        existing = execute_query("SELECT session_id FROM academic_sessions WHERE session_name = %s", (session_name,), fetch='one')
        if existing:
            flash(f"Academic session '{session_name}' already exists.", "warning")
            return redirect(url_for('admin.sessions'))

        if is_current:
            execute_query("UPDATE academic_sessions SET is_current = 0", commit=True)

        q = "INSERT INTO academic_sessions (session_name, start_date, end_date, is_current, status) VALUES (%s, %s, %s, %s, %s)"
        res = execute_query(q, (session_name, start_date, end_date, is_current, status), commit=True)
        log_activity(session.get('user_id'), 'Create Academic Session', 'Session', res['last_insert_id'], f"Created academic session {session_name}", request.remote_addr)
        flash(f"Academic session '{session_name}' created successfully.", "success")
    except Exception as e:
        flash(f"Error creating session: {e}", "danger")

    return redirect(url_for('admin.sessions'))

@admin_bp.route('/sessions/edit/<int:session_id>', methods=['POST'])
@admin_required
def session_edit(session_id):
    session_name = request.form.get('session_name', '').strip()
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    status = request.form.get('status', 'Active')

    try:
        q = "UPDATE academic_sessions SET session_name = %s, start_date = %s, end_date = %s, status = %s WHERE session_id = %s"
        execute_query(q, (session_name, start_date, end_date, status, session_id), commit=True)
        log_activity(session.get('user_id'), 'Update Academic Session', 'Session', session_id, f"Updated session {session_name}", request.remote_addr)
        flash("Session specifications updated.", "success")
    except Exception as e:
        flash(f"Error updating session: {e}", "danger")

    return redirect(url_for('admin.sessions'))

@admin_bp.route('/sessions/set-current/<int:session_id>', methods=['POST'])
@admin_required
def session_set_current(session_id):
    try:
        execute_query("UPDATE academic_sessions SET is_current = 0", commit=True)
        execute_query("UPDATE academic_sessions SET is_current = 1, status = 'Active' WHERE session_id = %s", (session_id,), commit=True)
        s_info = execute_query("SELECT session_name FROM academic_sessions WHERE session_id = %s", (session_id,), fetch='one')
        name = s_info['session_name'] if s_info else str(session_id)
        log_activity(session.get('user_id'), 'Set Current Session', 'Session', session_id, f"Set {name} as current academic session", request.remote_addr)
        flash(f"Session '{name}' is now designated as the Active Current University Session.", "success")
    except Exception as e:
        flash(f"Error updating current session: {e}", "danger")

    return redirect(url_for('admin.sessions'))

# =============================================================================
# 6. CLASS AND SECTION MANAGEMENT
# =============================================================================
@admin_bp.route('/sections')
@admin_required
def sections():
    course_filter = request.args.get('course', '').strip()
    sem_filter = request.args.get('semester', '').strip()
    session_filter = request.args.get('session_id', '').strip()

    conditions = []
    params = []

    if course_filter:
        conditions.append("cs.course_code = %s")
        params.append(course_filter)
    if sem_filter:
        conditions.append("cs.semester = %s")
        params.append(int(sem_filter))
    if session_filter:
        conditions.append("cs.session_id = %s")
        params.append(int(session_filter))

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    query = f"""
        SELECT cs.*, sess.session_name,
               (SELECT COUNT(*) FROM students s WHERE s.section_id = cs.section_id) AS enrolled_students_count,
               (SELECT COUNT(DISTINCT ta.teacher_id) FROM teacher_assignments ta WHERE ta.section_id = cs.section_id AND ta.status = 'Active') AS assigned_teachers_count,
               (SELECT COUNT(DISTINCT ta.subject_id) FROM teacher_assignments ta WHERE ta.section_id = cs.section_id AND ta.status = 'Active') AS assigned_subjects_count,
               (SELECT COUNT(*) FROM attendance a WHERE a.section_id = cs.section_id) AS attendance_count,
               (SELECT COUNT(*) FROM marks m WHERE m.section_id = cs.section_id) AS marks_count
        FROM classes_sections cs
        LEFT JOIN academic_sessions sess ON cs.session_id = sess.session_id
        {where_clause}
        ORDER BY cs.course_code ASC, cs.semester ASC, cs.section_name ASC
    """
    section_list = execute_query(query, params)

    # Detailed faculty assignments per section
    faculty_assignments = execute_query("""
        SELECT ta.assignment_id, ta.section_id, ta.teacher_id, u.full_name AS teacher_name, u.email AS teacher_email,
               sub.subject_code, sub.subject_name
        FROM teacher_assignments ta
        INNER JOIN users u ON ta.teacher_id = u.user_id
        INNER JOIN subjects sub ON ta.subject_id = sub.subject_id
        WHERE ta.status = 'Active'
    """)

    # Group assignments by section_id
    sec_teachers = {}
    for fa in (faculty_assignments or []):
        sec_id = fa['section_id']
        if sec_id not in sec_teachers:
            sec_teachers[sec_id] = []
        sec_teachers[sec_id].append(fa)

    # Attach to sections
    for sec in (section_list or []):
        sec['teachers_list'] = sec_teachers.get(sec['section_id'], [])

    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")
    sessions_list = execute_query("SELECT session_id, session_name FROM academic_sessions ORDER BY start_date DESC")
    teachers_list = execute_query("SELECT user_id, full_name, email FROM users WHERE role = 'user' AND status = 'active' ORDER BY full_name")
    subjects_list = execute_query("SELECT subject_id, subject_code, subject_name, course, semester FROM subjects WHERE status = 'Active' ORDER BY subject_code")

    return render_template(
        'admin/sections.html',
        sections=section_list or [],
        courses=courses_list or [],
        sessions=sessions_list or [],
        teachers=teachers_list or [],
        subjects=subjects_list or [],
        course_filter=course_filter,
        sem_filter=sem_filter,
        session_filter=session_filter
    )

@admin_bp.route('/sections/add', methods=['POST'])
@admin_required
def section_add():
    section_name = request.form.get('section_name', '').strip()
    course_code = request.form.get('course_code', '').strip()
    semester = request.form.get('semester')
    session_id = request.form.get('session_id') or None
    capacity = request.form.get('capacity', 60)
    status = request.form.get('status', 'Active')

    if not section_name or not course_code or not semester:
        flash("Section name, course code, and semester are required.", "danger")
        return redirect(url_for('admin.sections'))

    try:
        # Check duplicate
        existing = execute_query("""
            SELECT section_id FROM classes_sections 
            WHERE section_name = %s AND course_code = %s AND semester = %s AND (session_id = %s OR (%s IS NULL AND session_id IS NULL))
        """, (section_name, course_code, int(semester), session_id, session_id), fetch='one')

        if existing:
            flash(f"Section '{section_name}' for {course_code} Semester {semester} already exists.", "warning")
            return redirect(url_for('admin.sections'))

        q = """
            INSERT INTO classes_sections (section_name, course_code, semester, session_id, capacity, status)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        res = execute_query(q, (section_name, course_code, int(semester), session_id, int(capacity), status), commit=True)
        log_activity(
            session.get('user_id'), 'Create Section', 'Section', res['last_insert_id'],
            f"Created section {section_name} for {course_code} Sem {semester}", request.remote_addr,
            course=course_code, semester=int(semester), section_name=section_name
        )
        flash(f"Section '{section_name}' ({course_code} Semester {semester}) created successfully.", "success")
    except Exception as e:
        flash(f"Error creating section: {e}", "danger")

    return redirect(url_for('admin.sections'))

@admin_bp.route('/sections/assign-teacher', methods=['POST'])
@admin_required
def section_assign_teacher():
    section_id = request.form.get('section_id')
    teacher_id = request.form.get('teacher_id')
    subject_id = request.form.get('subject_id')
    session_id = request.form.get('session_id') or None

    if not section_id or not teacher_id or not subject_id:
        flash("Section, Teacher, and Subject are all required.", "danger")
        return redirect(url_for('admin.sections'))

    try:
        # Check duplicate
        existing = execute_query("""
            SELECT assignment_id FROM teacher_assignments
            WHERE teacher_id = %s AND subject_id = %s AND section_id = %s
        """, (teacher_id, subject_id, section_id), fetch='one')

        if existing:
            flash("This faculty member is already assigned to this subject and section.", "warning")
            return redirect(url_for('admin.sections'))

        q = """
            INSERT INTO teacher_assignments (teacher_id, subject_id, section_id, session_id, status)
            VALUES (%s, %s, %s, %s, 'Active')
        """
        res = execute_query(q, (teacher_id, subject_id, section_id, session_id), commit=True)

        # Retrieve info for audit
        sec_info = execute_query("SELECT section_name, course_code, semester FROM classes_sections WHERE section_id = %s", (section_id,), fetch='one')
        u_info = execute_query("SELECT full_name FROM users WHERE user_id = %s", (teacher_id,), fetch='one')
        sub_info = execute_query("SELECT subject_code, subject_name FROM subjects WHERE subject_id = %s", (subject_id,), fetch='one')

        t_name = u_info['full_name'] if u_info else str(teacher_id)
        sec_name = sec_info['section_name'] if sec_info else str(section_id)
        sub_name = sub_info['subject_name'] if sub_info else str(subject_id)

        log_activity(
            session.get('user_id'), 'Assign Teacher', 'Section', section_id,
            f"Assigned {t_name} to teach {sub_name} for section {sec_name}", request.remote_addr,
            course=sec_info['course_code'] if sec_info else None,
            semester=sec_info['semester'] if sec_info else None,
            section_name=sec_name, subject_name=sub_name
        )
        add_notification(
            "Faculty Academic Allocation",
            f"{t_name} was assigned to teach {sub_name} for Section {sec_name}.",
            category="System",
            link_url="/admin/sections"
        )
        flash(f"Successfully assigned {t_name} to {sub_name} ({sec_name}).", "success")
    except Exception as e:
        flash(f"Error assigning faculty: {e}", "danger")

    return redirect(url_for('admin.sections'))

@admin_bp.route('/sections/remove-teacher/<int:assignment_id>', methods=['POST'])
@admin_required
def section_remove_teacher(assignment_id):
    try:
        execute_query("DELETE FROM teacher_assignments WHERE assignment_id = %s", (assignment_id,), commit=True)
        log_activity(session.get('user_id'), 'Remove Teacher Assignment', 'Section', assignment_id, f"Removed allocation ID {assignment_id}", request.remote_addr)
        flash("Faculty assignment successfully removed.", "info")
    except Exception as e:
        flash(f"Error removing faculty assignment: {e}", "danger")

    return redirect(url_for('admin.sections'))

@admin_bp.route('/sections/delete/<int:section_id>', methods=['POST'])
@admin_required
def section_delete(section_id):
    try:
        # Check student dependencies
        cnt = execute_query("SELECT COUNT(*) AS cnt FROM students WHERE section_id = %s", (section_id,), fetch='one')
        if cnt and cnt['cnt'] > 0:
            execute_query("UPDATE classes_sections SET status = 'Inactive' WHERE section_id = %s", (section_id,), commit=True)
            flash(f"Section has {cnt['cnt']} active students enrolled. It has been deactivated to preserve academic records.", "warning")
        else:
            execute_query("DELETE FROM classes_sections WHERE section_id = %s", (section_id,), commit=True)
            flash("Section deleted successfully.", "success")
        log_activity(session.get('user_id'), 'Delete/Deactivate Section', 'Section', section_id, "Section removal processed", request.remote_addr)
    except Exception as e:
        flash(f"Error deleting section: {e}", "danger")

    return redirect(url_for('admin.sections'))

# =============================================================================
# 7. STUDENT MANAGEMENT
# =============================================================================
@admin_bp.route('/students')
@admin_required
def students():
    search = request.args.get('search', '').strip()
    course_filter = request.args.get('course', '').strip()
    sem_filter = request.args.get('semester', '').strip()
    sec_filter = request.args.get('section_id', '').strip()
    sess_filter = request.args.get('session_id', '').strip()
    status_filter = request.args.get('status', '').strip()
    page = int(request.args.get('page', 1))
    per_page = 25

    conditions = []
    params = []

    if search:
        conditions.append("(s.full_name LIKE %s OR s.roll_number LIKE %s OR s.email LIKE %s)")
        term = f"%{search}%"
        params.extend([term, term, term])
    if course_filter:
        conditions.append("s.course = %s")
        params.append(course_filter)
    if sem_filter:
        conditions.append("s.semester = %s")
        params.append(int(sem_filter))
    if sec_filter:
        conditions.append("s.section_id = %s")
        params.append(int(sec_filter))
    if sess_filter:
        conditions.append("s.session_id = %s")
        params.append(int(sess_filter))
    if status_filter:
        conditions.append("s.status = %s")
        params.append(status_filter)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    count_res = execute_query(f"SELECT COUNT(*) AS total FROM students s {where_clause}", params, fetch='one')
    total_records = count_res['total'] if count_res else 0
    total_pages = max(1, math.ceil(total_records / per_page))
    page = max(1, min(page, total_pages))
    offset = (page - 1) * per_page

    query = f"""
        SELECT s.*, cs.section_name, sess.session_name,
               (SELECT COUNT(*) FROM marks m WHERE m.student_id = s.student_id) AS total_assessments,
               (SELECT COALESCE(ROUND(AVG(m.percentage), 2), 0.0) FROM marks m WHERE m.student_id = s.student_id) AS avg_percentage,
               (SELECT COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 1), 0.0) 
                FROM attendance a WHERE a.student_id = s.student_id) AS attendance_percentage
        FROM students s
        LEFT JOIN classes_sections cs ON s.section_id = cs.section_id
        LEFT JOIN academic_sessions sess ON s.session_id = sess.session_id
        {where_clause}
        ORDER BY s.student_id ASC
        LIMIT %s OFFSET %s
    """
    query_params = list(params) + [per_page, offset]
    student_list = execute_query(query, query_params)

    # Dynamic Dropdowns
    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")
    sections_list = execute_query("SELECT section_id, section_name, course_code, semester FROM classes_sections WHERE status = 'Active' ORDER BY section_name")
    sessions_list = execute_query("SELECT session_id, session_name FROM academic_sessions ORDER BY start_date DESC")

    return render_template(
        'admin/students.html',
        students=student_list or [],
        courses=courses_list or [],
        sections=sections_list or [],
        sessions=sessions_list or [],
        search=search,
        course_filter=course_filter,
        sem_filter=sem_filter,
        sec_filter=sec_filter,
        sess_filter=sess_filter,
        status_filter=status_filter,
        page=page,
        total_pages=total_pages,
        total_records=total_records
    )

@admin_bp.route('/students/add', methods=['POST'])
@admin_required
def student_add():
    roll_number = request.form.get('roll_number', '').strip().upper()
    full_name = request.form.get('full_name', '').strip()
    email = request.form.get('email', '').strip().lower()
    phone = request.form.get('phone', '').strip()
    gender = request.form.get('gender', 'Male')
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester')
    section_id = request.form.get('section_id') or None
    session_id = request.form.get('session_id') or None
    enrollment_date = request.form.get('enrollment_date') or date.today().strftime('%Y-%m-%d')
    status = request.form.get('status', 'Active')

    if not roll_number or not full_name or not email or not course or not semester:
        flash("Roll number, name, email, course, and semester are required.", "danger")
        return redirect(url_for('admin.students'))

    try:
        # Check duplicates
        existing_roll = execute_query("SELECT student_id FROM students WHERE roll_number = %s", (roll_number,), fetch='one')
        if existing_roll:
            flash(f"Student with roll number '{roll_number}' already exists.", "warning")
            return redirect(url_for('admin.students'))

        existing_email = execute_query("SELECT student_id FROM students WHERE email = %s", (email,), fetch='one')
        if existing_email:
            flash(f"Student with email '{email}' already exists.", "warning")
            return redirect(url_for('admin.students'))

        q = """
            INSERT INTO students (roll_number, full_name, email, phone, gender, course, semester, section_id, session_id, enrollment_date, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        res = execute_query(
            q,
            (roll_number, full_name, email, phone, gender, course, int(semester), section_id, session_id, enrollment_date, status),
            commit=True
        )

        log_activity(
            session.get('user_id'), 'Enroll Student', 'Student', res['last_insert_id'],
            f"Enrolled student {roll_number} - {full_name} ({course} Sem {semester})", request.remote_addr,
            course=course, semester=int(semester)
        )
        add_notification(
            "New Student Enrollment",
            f"Student {full_name} ({roll_number}) enrolled in {course} Semester {semester}.",
            category="Student",
            link_url="/admin/students"
        )
        flash(f"Student '{full_name}' ({roll_number}) successfully enrolled.", "success")
    except Exception as e:
        flash(f"Error enrolling student: {e}", "danger")

    return redirect(url_for('admin.students'))

@admin_bp.route('/students/edit/<int:student_id>', methods=['POST'])
@admin_required
def student_edit(student_id):
    full_name = request.form.get('full_name', '').strip()
    email = request.form.get('email', '').strip().lower()
    phone = request.form.get('phone', '').strip()
    gender = request.form.get('gender')
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester')
    section_id = request.form.get('section_id') or None
    session_id = request.form.get('session_id') or None
    status = request.form.get('status', 'Active')

    try:
        q = """
            UPDATE students
            SET full_name = %s, email = %s, phone = %s, gender = %s, course = %s, semester = %s,
                section_id = %s, session_id = %s, status = %s
            WHERE student_id = %s
        """
        execute_query(
            q,
            (full_name, email, phone, gender, course, int(semester), section_id, session_id, status, student_id),
            commit=True
        )
        log_activity(session.get('user_id'), 'Update Student', 'Student', student_id, f"Updated profile for student ID {student_id}", request.remote_addr)
        flash("Student details updated successfully.", "success")
    except Exception as e:
        flash(f"Error updating student: {e}", "danger")

    return redirect(url_for('admin.students'))

@admin_bp.route('/students/transfer-section', methods=['POST'])
@admin_required
def student_transfer_section():
    student_id = request.form.get('student_id')
    new_section_id = request.form.get('new_section_id')

    if not student_id or not new_section_id:
        flash("Student ID and destination Section are required.", "danger")
        return redirect(url_for('admin.students'))

    try:
        sec = execute_query("SELECT section_name, course_code, semester FROM classes_sections WHERE section_id = %s", (new_section_id,), fetch='one')
        s = execute_query("SELECT full_name, roll_number FROM students WHERE student_id = %s", (student_id,), fetch='one')

        execute_query("UPDATE students SET section_id = %s WHERE student_id = %s", (new_section_id, student_id), commit=True)
        # Update attendance and marks default section to maintain consistency
        execute_query("UPDATE attendance SET section_id = %s WHERE student_id = %s", (new_section_id, student_id), commit=True)
        execute_query("UPDATE marks SET section_id = %s WHERE student_id = %s", (new_section_id, student_id), commit=True)

        s_name = s['full_name'] if s else f"Student #{student_id}"
        sec_name = sec['section_name'] if sec else f"Section #{new_section_id}"

        log_activity(
            session.get('user_id'), 'Transfer Student Section', 'Student', student_id,
            f"Transferred {s_name} to section {sec_name}", request.remote_addr,
            course=sec['course_code'] if sec else None,
            section_name=sec_name
        )
        flash(f"Student {s_name} successfully transferred to {sec_name}.", "success")
    except Exception as e:
        flash(f"Error transferring student: {e}", "danger")

    return redirect(url_for('admin.students'))

@admin_bp.route('/students/delete/<int:student_id>', methods=['POST'])
@admin_required
def student_delete(student_id):
    try:
        execute_query("UPDATE students SET status = 'Inactive' WHERE student_id = %s", (student_id,), commit=True)
        log_activity(session.get('user_id'), 'Deactivate Student', 'Student', student_id, f"Deactivated student ID {student_id}", request.remote_addr)
        flash("Student status set to Inactive.", "info")
    except Exception as e:
        flash(f"Error deactivating student: {e}", "danger")

    return redirect(url_for('admin.students'))

@admin_bp.route('/students/profile/<int:student_id>')
@admin_required
def student_profile_json(student_id):
    """Returns complete academic profile JSON for modal view."""
    try:
        student = execute_query("""
            SELECT s.*, cs.section_name, sess.session_name
            FROM students s
            LEFT JOIN classes_sections cs ON s.section_id = cs.section_id
            LEFT JOIN academic_sessions sess ON s.session_id = sess.session_id
            WHERE s.student_id = %s
        """, (student_id,), fetch='one')

        if not student:
            return jsonify({'success': False, 'error': 'Student not found'}), 404

        marks = execute_query("""
            SELECT m.*, sub.subject_code, sub.subject_name, sub.max_marks, sub.passing_marks, sess.session_name
            FROM marks m
            INNER JOIN subjects sub ON m.subject_id = sub.subject_id
            LEFT JOIN academic_sessions sess ON m.session_id = sess.session_id
            WHERE m.student_id = %s
            ORDER BY sub.subject_code, m.exam_type
        """, (student_id,))

        attendance = execute_query("""
            SELECT 
                COUNT(*) AS total_classes,
                SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_classes,
                COALESCE(ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00) AS attendance_pct
            FROM attendance
            WHERE student_id = %s
        """, (student_id,), fetch='one')

        submissions = execute_query("""
            SELECT sub.*, asgn.title AS assignment_title, s.subject_name, asgn.due_date, asgn.max_marks
            FROM assignment_submissions sub
            INNER JOIN assignments asgn ON sub.assignment_id = asgn.assignment_id
            INNER JOIN subjects s ON asgn.subject_id = s.subject_id
            WHERE sub.student_id = %s
            ORDER BY asgn.due_date DESC
        """, (student_id,))

        return jsonify({
            'success': True,
            'student': student,
            'marks': marks or [],
            'attendance': attendance or {'total_classes': 0, 'attended_classes': 0, 'attendance_pct': 0.0},
            'submissions': submissions or []
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# =============================================================================
# 8. TEACHER MANAGEMENT
# =============================================================================
@admin_bp.route('/teachers')
@admin_required
def teachers():
    dept_filter = request.args.get('department_id', '').strip()
    status_filter = request.args.get('status', '').strip()

    conditions = ["u.role = 'user'"]
    params = []

    if dept_filter:
        conditions.append("u.department_id = %s")
        params.append(int(dept_filter))
    if status_filter:
        conditions.append("u.status = %s")
        params.append(status_filter)

    where_clause = " WHERE " + " AND ".join(conditions)

    query = f"""
        SELECT u.*, d.department_name, d.department_code,
               (SELECT COUNT(*) FROM teacher_assignments ta WHERE ta.teacher_id = u.user_id AND ta.status = 'Active') AS assigned_classes_count,
               (SELECT COUNT(DISTINCT ta.subject_id) FROM teacher_assignments ta WHERE ta.teacher_id = u.user_id AND ta.status = 'Active') AS assigned_subjects_count,
               (SELECT COUNT(*) FROM attendance a WHERE a.teacher_id = u.user_id) AS attendance_marked_count,
               (SELECT COUNT(*) FROM marks m WHERE m.teacher_id = u.user_id) AS marks_entered_count,
               (SELECT COUNT(*) FROM assignments asgn WHERE asgn.teacher_id = u.user_id) AS assignments_created_count
        FROM users u
        LEFT JOIN departments d ON u.department_id = d.department_id
        {where_clause}
        ORDER BY u.full_name ASC
    """
    teacher_list = execute_query(query, params)

    # Detailed allocations per teacher
    allocations = execute_query("""
        SELECT ta.*, sub.subject_code, sub.subject_name, cs.section_name, cs.course_code, cs.semester
        FROM teacher_assignments ta
        INNER JOIN subjects sub ON ta.subject_id = sub.subject_id
        LEFT JOIN classes_sections cs ON ta.section_id = cs.section_id
        WHERE ta.status = 'Active'
    """)
    t_allocs = {}
    for al in (allocations or []):
        tid = al['teacher_id']
        if tid not in t_allocs:
            t_allocs[tid] = []
        t_allocs[tid].append(al)

    for t in (teacher_list or []):
        t['allocations_list'] = t_allocs.get(t['user_id'], [])

    departments_list = execute_query("SELECT department_id, department_code, department_name FROM departments WHERE status = 'Active' ORDER BY department_name")
    subjects_list = execute_query("SELECT subject_id, subject_code, subject_name, course, semester FROM subjects WHERE status = 'Active' ORDER BY subject_code")
    sections_list = execute_query("SELECT section_id, section_name, course_code, semester FROM classes_sections WHERE status = 'Active' ORDER BY section_name")

    return render_template(
        'admin/teachers.html',
        teachers=teacher_list or [],
        departments=departments_list or [],
        subjects=subjects_list or [],
        sections=sections_list or [],
        dept_filter=dept_filter,
        status_filter=status_filter
    )

@admin_bp.route('/teachers/add', methods=['POST'])
@admin_required
def teacher_add():
    full_name = request.form.get('full_name', '').strip()
    email = request.form.get('email', '').strip().lower()
    phone = request.form.get('phone', '').strip()
    password = request.form.get('password', 'Teacher@1234')
    department_id = request.form.get('department_id') or None
    employee_id = request.form.get('employee_id', '').strip().upper()
    designation = request.form.get('designation', 'Assistant Professor').strip()

    if not full_name or not email:
        flash("Faculty name and institutional email are mandatory.", "danger")
        return redirect(url_for('admin.teachers'))

    try:
        existing = execute_query("SELECT user_id FROM users WHERE email = %s", (email,), fetch='one')
        if existing:
            flash(f"User with email '{email}' already registered.", "warning")
            return redirect(url_for('admin.teachers'))

        pw_hash = generate_password_hash(password)
        q = """
            INSERT INTO users (full_name, email, phone, password_hash, role, department_id, employee_id, designation, status)
            VALUES (%s, %s, %s, %s, 'user', %s, %s, %s, 'active')
        """
        res = execute_query(q, (full_name, email, phone, pw_hash, department_id, employee_id, designation), commit=True)

        log_activity(
            session.get('user_id'), 'Create Teacher Account', 'Users', res['last_insert_id'],
            f"Created faculty account {full_name} ({email}) - {designation}", request.remote_addr
        )
        add_notification(
            "New Faculty Account Registered",
            f"Faculty member {full_name} ({designation}) was added to the institutional directory.",
            category="System",
            link_url="/admin/teachers"
        )
        flash(f"Faculty account for '{full_name}' successfully created.", "success")
    except Exception as e:
        flash(f"Error adding faculty member: {e}", "danger")

    return redirect(url_for('admin.teachers'))

@admin_bp.route('/teachers/edit/<int:teacher_id>', methods=['POST'])
@admin_required
def teacher_edit(teacher_id):
    full_name = request.form.get('full_name', '').strip()
    phone = request.form.get('phone', '').strip()
    department_id = request.form.get('department_id') or None
    employee_id = request.form.get('employee_id', '').strip()
    designation = request.form.get('designation', '').strip()
    status = request.form.get('status', 'active')

    try:
        q = """
            UPDATE users
            SET full_name = %s, phone = %s, department_id = %s, employee_id = %s, designation = %s, status = %s
            WHERE user_id = %s AND role = 'user'
        """
        execute_query(q, (full_name, phone, department_id, employee_id, designation, status, teacher_id), commit=True)
        log_activity(session.get('user_id'), 'Update Teacher', 'Users', teacher_id, f"Updated faculty profile ID {teacher_id}", request.remote_addr)
        flash("Faculty information updated successfully.", "success")
    except Exception as e:
        flash(f"Error updating faculty: {e}", "danger")

    return redirect(url_for('admin.teachers'))

@admin_bp.route('/teachers/toggle/<int:teacher_id>', methods=['POST'])
@admin_required
def teacher_toggle(teacher_id):
    try:
        u = execute_query("SELECT full_name, status FROM users WHERE user_id = %s AND role = 'user'", (teacher_id,), fetch='one')
        if u:
            new_status = 'inactive' if u['status'] == 'active' else 'active'
            execute_query("UPDATE users SET status = %s WHERE user_id = %s", (new_status, teacher_id), commit=True)
            log_activity(session.get('user_id'), 'Toggle Teacher Status', 'Users', teacher_id, f"Set {u['full_name']} to {new_status}", request.remote_addr)
            flash(f"Faculty account for {u['full_name']} set to {new_status.capitalize()}.", "info")
    except Exception as e:
        flash(f"Error toggling faculty status: {e}", "danger")

    return redirect(url_for('admin.teachers'))

@admin_bp.route('/teachers/workload/<int:teacher_id>')
@admin_required
def teacher_workload_json(teacher_id):
    """Provides complete workload & historical academic actions JSON."""
    try:
        teacher = execute_query("""
            SELECT u.*, d.department_name
            FROM users u
            LEFT JOIN departments d ON u.department_id = d.department_id
            WHERE u.user_id = %s AND u.role = 'user'
        """, (teacher_id,), fetch='one')

        if not teacher:
            return jsonify({'success': False, 'error': 'Faculty member not found'}), 404

        allocations = execute_query("""
            SELECT ta.*, sub.subject_code, sub.subject_name, sub.credits, cs.section_name, cs.course_code, cs.semester
            FROM teacher_assignments ta
            INNER JOIN subjects sub ON ta.subject_id = sub.subject_id
            LEFT JOIN classes_sections cs ON ta.section_id = cs.section_id
            WHERE ta.teacher_id = %s AND ta.status = 'Active'
        """, (teacher_id,))

        recent_logs = execute_query("""
            SELECT * FROM activity_logs 
            WHERE user_id = %s 
            ORDER BY created_at DESC LIMIT 15
        """, (teacher_id,))

        summary = {
            'total_attendance_sessions': (execute_query("SELECT COUNT(*) AS cnt FROM attendance WHERE teacher_id = %s", (teacher_id,), fetch='one') or {}).get('cnt', 0),
            'total_marks_entered': (execute_query("SELECT COUNT(*) AS cnt FROM marks WHERE teacher_id = %s", (teacher_id,), fetch='one') or {}).get('cnt', 0),
            'total_assignments_created': (execute_query("SELECT COUNT(*) AS cnt FROM assignments WHERE teacher_id = %s", (teacher_id,), fetch='one') or {}).get('cnt', 0)
        }

        return jsonify({
            'success': True,
            'teacher': teacher,
            'allocations': allocations or [],
            'summary': summary,
            'recent_logs': recent_logs or []
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# =============================================================================
# 9. CENTRALIZED ACADEMIC MONITORING: ATTENDANCE
# =============================================================================
@admin_bp.route('/monitoring/attendance')
@admin_required
def monitoring_attendance():
    course_filter = request.args.get('course', '').strip()
    sem_filter = request.args.get('semester', '').strip()
    sec_filter = request.args.get('section_id', '').strip()
    sub_filter = request.args.get('subject_id', '').strip()
    teacher_filter = request.args.get('teacher_id', '').strip()
    date_filter = request.args.get('date', '').strip()
    status_filter = request.args.get('status', '').strip()
    page = int(request.args.get('page', 1))
    per_page = 30

    conditions = []
    params = []

    if course_filter:
        conditions.append("s.course = %s")
        params.append(course_filter)
    if sem_filter:
        conditions.append("s.semester = %s")
        params.append(int(sem_filter))
    if sec_filter:
        conditions.append("a.section_id = %s")
        params.append(int(sec_filter))
    if sub_filter:
        conditions.append("a.subject_id = %s")
        params.append(int(sub_filter))
    if teacher_filter:
        conditions.append("a.teacher_id = %s")
        params.append(int(teacher_filter))
    if date_filter:
        conditions.append("a.attendance_date = %s")
        params.append(date_filter)
    if status_filter:
        conditions.append("a.status = %s")
        params.append(status_filter)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    count_res = execute_query(f"""
        SELECT COUNT(*) AS total
        FROM attendance a
        INNER JOIN students s ON a.student_id = s.student_id
        INNER JOIN subjects sub ON a.subject_id = sub.subject_id
        {where_clause}
    """, params, fetch='one')
    total_records = count_res['total'] if count_res else 0
    total_pages = max(1, math.ceil(total_records / per_page))
    page = max(1, min(page, total_pages))
    offset = (page - 1) * per_page

    query = f"""
        SELECT a.*, s.roll_number, s.full_name AS student_name, s.course, s.semester,
               sub.subject_code, sub.subject_name,
               cs.section_name,
               COALESCE(u.full_name, 'Faculty Member') AS teacher_name
        FROM attendance a
        INNER JOIN students s ON a.student_id = s.student_id
        INNER JOIN subjects sub ON a.subject_id = sub.subject_id
        LEFT JOIN classes_sections cs ON a.section_id = cs.section_id
        LEFT JOIN users u ON a.teacher_id = u.user_id
        {where_clause}
        ORDER BY a.attendance_date DESC, a.attendance_id DESC
        LIMIT %s OFFSET %s
    """
    query_params = list(params) + [per_page, offset]
    attendance_records = execute_query(query, query_params)

    # Statistics Breakdown
    stat_query = f"""
        SELECT 
            COUNT(*) AS total_count,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
            SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count,
            SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN a.status = 'Excused' THEN 1 ELSE 0 END) AS excused_count,
            COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00) AS attendance_rate
        FROM attendance a
        INNER JOIN students s ON a.student_id = s.student_id
        {where_clause}
    """
    stats = execute_query(stat_query, params, fetch='one')

    # Students with Low Attendance (<75%)
    low_att_students = execute_query("""
        SELECT s.student_id, s.roll_number, s.full_name, s.course, s.semester, cs.section_name,
               att.total_classes, att.attended_classes, att.attendance_pct
        FROM students s
        INNER JOIN (
            SELECT student_id,
                   COUNT(*) AS total_classes,
                   SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended_classes,
                   ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS attendance_pct
            FROM attendance
            GROUP BY student_id
            HAVING attendance_pct < 75.00
        ) att ON s.student_id = att.student_id
        LEFT JOIN classes_sections cs ON s.section_id = cs.section_id
        ORDER BY att.attendance_pct ASC LIMIT 10
    """)

    # Dropdowns
    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")
    sections_list = execute_query("SELECT section_id, section_name, course_code, semester FROM classes_sections WHERE status = 'Active' ORDER BY section_name")
    subjects_list = execute_query("SELECT subject_id, subject_code, subject_name FROM subjects WHERE status = 'Active' ORDER BY subject_code")
    teachers_list = execute_query("SELECT user_id, full_name FROM users WHERE role = 'user' AND status = 'active' ORDER BY full_name")

    return render_template(
        'admin/monitoring_attendance.html',
        records=attendance_records or [],
        stats=stats or {},
        low_att_students=low_att_students or [],
        courses=courses_list or [],
        sections=sections_list or [],
        subjects=subjects_list or [],
        teachers=teachers_list or [],
        course_filter=course_filter,
        sem_filter=sem_filter,
        sec_filter=sec_filter,
        sub_filter=sub_filter,
        teacher_filter=teacher_filter,
        date_filter=date_filter,
        status_filter=status_filter,
        page=page,
        total_pages=total_pages,
        total_records=total_records
    )

# =============================================================================
# 10. CENTRALIZED ACADEMIC MONITORING: MARKS & ASSESSMENTS
# =============================================================================
@admin_bp.route('/monitoring/marks')
@admin_required
def monitoring_marks():
    course_filter = request.args.get('course', '').strip()
    sem_filter = request.args.get('semester', '').strip()
    sec_filter = request.args.get('section_id', '').strip()
    sub_filter = request.args.get('subject_id', '').strip()
    exam_filter = request.args.get('exam_type', '').strip()
    teacher_filter = request.args.get('teacher_id', '').strip()
    status_filter = request.args.get('status', '').strip()
    page = int(request.args.get('page', 1))
    per_page = 30

    conditions = []
    params = []

    if course_filter:
        conditions.append("s.course = %s")
        params.append(course_filter)
    if sem_filter:
        conditions.append("s.semester = %s")
        params.append(int(sem_filter))
    if sec_filter:
        conditions.append("m.section_id = %s")
        params.append(int(sec_filter))
    if sub_filter:
        conditions.append("m.subject_id = %s")
        params.append(int(sub_filter))
    if exam_filter:
        conditions.append("m.exam_type = %s")
        params.append(exam_filter)
    if teacher_filter:
        conditions.append("m.teacher_id = %s")
        params.append(int(teacher_filter))
    if status_filter:
        conditions.append("m.status = %s")
        params.append(status_filter)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    count_res = execute_query(f"""
        SELECT COUNT(*) AS total
        FROM marks m
        INNER JOIN students s ON m.student_id = s.student_id
        INNER JOIN subjects sub ON m.subject_id = sub.subject_id
        {where_clause}
    """, params, fetch='one')
    total_records = count_res['total'] if count_res else 0
    total_pages = max(1, math.ceil(total_records / per_page))
    page = max(1, min(page, total_pages))
    offset = (page - 1) * per_page

    query = f"""
        SELECT m.*, s.roll_number, s.full_name AS student_name, s.course, s.semester,
               sub.subject_code, sub.subject_name, sub.max_marks AS spec_max_marks, sub.passing_marks AS spec_passing_marks,
               cs.section_name,
               COALESCE(u.full_name, 'Faculty Member') AS teacher_name,
               sess.session_name
        FROM marks m
        INNER JOIN students s ON m.student_id = s.student_id
        INNER JOIN subjects sub ON m.subject_id = sub.subject_id
        LEFT JOIN classes_sections cs ON m.section_id = cs.section_id
        LEFT JOIN users u ON m.teacher_id = u.user_id
        LEFT JOIN academic_sessions sess ON m.session_id = sess.session_id
        {where_clause}
        ORDER BY m.mark_id DESC
        LIMIT %s OFFSET %s
    """
    query_params = list(params) + [per_page, offset]
    marks_records = execute_query(query, query_params)

    # Statistical Overview
    stat_query = f"""
        SELECT 
            COUNT(*) AS total_count,
            COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
            COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00) AS pass_percentage,
            SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) AS passed_count,
            SUM(CASE WHEN m.status = 'Fail' THEN 1 ELSE 0 END) AS failed_count,
            COALESCE(MAX(m.obtained_marks), 0.00) AS highest_mark,
            COALESCE(MIN(m.obtained_marks), 0.00) AS lowest_mark
        FROM marks m
        INNER JOIN students s ON m.student_id = s.student_id
        {where_clause}
    """
    stats = execute_query(stat_query, params, fetch='one')

    # Subject-wise average scores
    subject_averages = execute_query("""
        SELECT sub.subject_code, sub.subject_name,
               COUNT(m.mark_id) AS total_assessments,
               COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_score,
               COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_rate
        FROM subjects sub
        LEFT JOIN marks m ON sub.subject_id = m.subject_id
        GROUP BY sub.subject_id, sub.subject_code, sub.subject_name
        ORDER BY sub.subject_code
    """)

    # Dropdowns
    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")
    sections_list = execute_query("SELECT section_id, section_name, course_code, semester FROM classes_sections WHERE status = 'Active' ORDER BY section_name")
    subjects_list = execute_query("SELECT subject_id, subject_code, subject_name FROM subjects WHERE status = 'Active' ORDER BY subject_code")
    teachers_list = execute_query("SELECT user_id, full_name FROM users WHERE role = 'user' AND status = 'active' ORDER BY full_name")

    return render_template(
        'admin/monitoring_marks.html',
        records=marks_records or [],
        stats=stats or {},
        subject_averages=subject_averages or [],
        courses=courses_list or [],
        sections=sections_list or [],
        subjects=subjects_list or [],
        teachers=teachers_list or [],
        course_filter=course_filter,
        sem_filter=sem_filter,
        sec_filter=sec_filter,
        sub_filter=sub_filter,
        exam_filter=exam_filter,
        teacher_filter=teacher_filter,
        status_filter=status_filter,
        page=page,
        total_pages=total_pages,
        total_records=total_records
    )

# =============================================================================
# 11. CENTRALIZED ACADEMIC MONITORING: ASSIGNMENTS
# =============================================================================
@admin_bp.route('/monitoring/assignments')
@admin_required
def monitoring_assignments():
    course_filter = request.args.get('course', '').strip()
    sem_filter = request.args.get('semester', '').strip()
    sec_filter = request.args.get('section_id', '').strip()
    sub_filter = request.args.get('subject_id', '').strip()
    teacher_filter = request.args.get('teacher_id', '').strip()
    status_filter = request.args.get('status', '').strip()

    conditions = []
    params = []

    if course_filter:
        conditions.append("sub.course = %s")
        params.append(course_filter)
    if sem_filter:
        conditions.append("sub.semester = %s")
        params.append(int(sem_filter))
    if sec_filter:
        conditions.append("asgn.section_id = %s")
        params.append(int(sec_filter))
    if sub_filter:
        conditions.append("asgn.subject_id = %s")
        params.append(int(sub_filter))
    if teacher_filter:
        conditions.append("asgn.teacher_id = %s")
        params.append(int(teacher_filter))
    if status_filter:
        conditions.append("asgn.status = %s")
        params.append(status_filter)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    query = f"""
        SELECT asgn.*, sub.subject_code, sub.subject_name, sub.course, sub.semester,
               cs.section_name,
               u.full_name AS teacher_name, u.email AS teacher_email,
               (SELECT COUNT(*) FROM assignment_submissions s_sub WHERE s_sub.assignment_id = asgn.assignment_id) AS total_submissions,
               (SELECT COUNT(*) FROM assignment_submissions s_sub WHERE s_sub.assignment_id = asgn.assignment_id AND s_sub.status = 'Graded') AS graded_count,
               (SELECT COUNT(*) FROM students s WHERE s.course = sub.course AND s.semester = sub.semester) AS expected_students_count
        FROM assignments asgn
        INNER JOIN subjects sub ON asgn.subject_id = sub.subject_id
        INNER JOIN users u ON asgn.teacher_id = u.user_id
        LEFT JOIN classes_sections cs ON asgn.section_id = cs.section_id
        {where_clause}
        ORDER BY asgn.due_date DESC
    """
    assignment_list = execute_query(query, params)

    # Calculate pending count per assignment
    for a in (assignment_list or []):
        exp = a.get('expected_students_count', 0)
        sub_cnt = a.get('total_submissions', 0)
        a['pending_count'] = max(0, exp - sub_cnt)

    # Dropdowns
    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")
    sections_list = execute_query("SELECT section_id, section_name, course_code, semester FROM classes_sections WHERE status = 'Active' ORDER BY section_name")
    subjects_list = execute_query("SELECT subject_id, subject_code, subject_name FROM subjects WHERE status = 'Active' ORDER BY subject_code")
    teachers_list = execute_query("SELECT user_id, full_name FROM users WHERE role = 'user' AND status = 'active' ORDER BY full_name")

    return render_template(
        'admin/monitoring_assignments.html',
        assignments=assignment_list or [],
        courses=courses_list or [],
        sections=sections_list or [],
        subjects=subjects_list or [],
        teachers=teachers_list or [],
        course_filter=course_filter,
        sem_filter=sem_filter,
        sec_filter=sec_filter,
        sub_filter=sub_filter,
        teacher_filter=teacher_filter,
        status_filter=status_filter
    )

@admin_bp.route('/monitoring/assignments/<int:assignment_id>/submissions')
@admin_required
def assignment_submissions_json(assignment_id):
    """Provides submission details JSON for an assignment."""
    try:
        asgn = execute_query("""
            SELECT asgn.*, sub.subject_code, sub.subject_name, u.full_name AS teacher_name
            FROM assignments asgn
            INNER JOIN subjects sub ON asgn.subject_id = sub.subject_id
            INNER JOIN users u ON asgn.teacher_id = u.user_id
            WHERE asgn.assignment_id = %s
        """, (assignment_id,), fetch='one')

        if not asgn:
            return jsonify({'success': False, 'error': 'Assignment not found'}), 404

        submissions = execute_query("""
            SELECT sub.*, s.roll_number, s.full_name AS student_name, s.course, s.semester, cs.section_name
            FROM assignment_submissions sub
            INNER JOIN students s ON sub.student_id = s.student_id
            LEFT JOIN classes_sections cs ON s.section_id = cs.section_id
            WHERE sub.assignment_id = %s
            ORDER BY sub.submission_date DESC
        """, (assignment_id,))

        return jsonify({
            'success': True,
            'assignment': asgn,
            'submissions': submissions or []
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# =============================================================================
# 12. TEACHER ACTIVITY MONITORING SYSTEM & AUDIT LOGS
# =============================================================================
@admin_bp.route('/monitoring/teacher-activity')
@admin_bp.route('/audit-logs')
@admin_required
def teacher_activity():
    teacher_filter = request.args.get('teacher_id', '').strip()
    action_filter = request.args.get('action', '').strip()
    course_filter = request.args.get('course', '').strip()
    sec_filter = request.args.get('section', '').strip()
    date_from = request.args.get('date_from', '').strip()
    date_to = request.args.get('date_to', '').strip()
    page = int(request.args.get('page', 1))
    per_page = 30

    conditions = []
    params = []

    if teacher_filter:
        conditions.append("act.user_id = %s")
        params.append(int(teacher_filter))
    if action_filter:
        conditions.append("act.action = %s")
        params.append(action_filter)
    if course_filter:
        conditions.append("act.course = %s")
        params.append(course_filter)
    if sec_filter:
        conditions.append("act.section_name LIKE %s")
        params.append(f"%{sec_filter}%")
    if date_from:
        conditions.append("DATE(act.created_at) >= %s")
        params.append(date_from)
    if date_to:
        conditions.append("DATE(act.created_at) <= %s")
        params.append(date_to)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    count_res = execute_query(f"SELECT COUNT(*) AS total FROM activity_logs act {where_clause}", params, fetch='one')
    total_records = count_res['total'] if count_res else 0
    total_pages = max(1, math.ceil(total_records / per_page))
    page = max(1, min(page, total_pages))
    offset = (page - 1) * per_page

    query = f"""
        SELECT act.*, u.full_name AS teacher_name, u.email AS teacher_email, u.role, u.designation
        FROM activity_logs act
        LEFT JOIN users u ON act.user_id = u.user_id
        {where_clause}
        ORDER BY act.created_at DESC
        LIMIT %s OFFSET %s
    """
    query_params = list(params) + [per_page, offset]
    activities = execute_query(query, query_params)

    # Activity Action Types for Dropdown
    actions_list = execute_query("SELECT DISTINCT action FROM activity_logs ORDER BY action")
    teachers_list = execute_query("SELECT user_id, full_name, email FROM users WHERE role = 'user' ORDER BY full_name")
    courses_list = execute_query("SELECT course_code FROM courses WHERE status = 'Active' ORDER BY course_code")

    return render_template(
        'admin/teacher_activity.html',
        activities=activities or [],
        teachers=teachers_list or [],
        actions=actions_list or [],
        courses=courses_list or [],
        teacher_filter=teacher_filter,
        action_filter=action_filter,
        course_filter=course_filter,
        sec_filter=sec_filter,
        date_from=date_from,
        date_to=date_to,
        page=page,
        total_pages=total_pages,
        total_records=total_records
    )

# =============================================================================
# 13. ADMIN NOTIFICATION CENTER
# =============================================================================
@admin_bp.route('/notifications')
@admin_required
def notifications():
    cat_filter = request.args.get('category', '').strip()
    status_filter = request.args.get('status', '').strip()

    conditions = []
    params = []

    if cat_filter:
        conditions.append("category = %s")
        params.append(cat_filter)
    if status_filter == 'unread':
        conditions.append("is_read = FALSE")
    elif status_filter == 'read':
        conditions.append("is_read = TRUE")

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    notif_list = execute_query(f"SELECT * FROM admin_notifications {where_clause} ORDER BY created_at DESC", params)

    return render_template(
        'admin/notifications.html',
        notifications=notif_list or [],
        cat_filter=cat_filter,
        status_filter=status_filter
    )

@admin_bp.route('/notifications/mark-read/<int:notif_id>', methods=['POST'])
@admin_required
def notification_mark_read(notif_id):
    try:
        execute_query("UPDATE admin_notifications SET is_read = TRUE WHERE notification_id = %s", (notif_id,), commit=True)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@admin_bp.route('/notifications/mark-all-read', methods=['POST'])
@admin_required
def notification_mark_all_read():
    try:
        execute_query("UPDATE admin_notifications SET is_read = TRUE", commit=True)
        flash("All notifications marked as read.", "success")
    except Exception as e:
        flash(f"Error marking notifications: {e}", "danger")

    return redirect(url_for('admin.notifications'))

# =============================================================================
# 14. UNIVERSITY ANALYTICS
# =============================================================================
@admin_bp.route('/analytics')
@admin_required
def analytics():
    # Fetch filter options
    sessions_list = execute_query("SELECT session_id, session_name, is_current FROM academic_sessions ORDER BY start_date DESC")
    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")

    # 1. Course Performance Comparison
    course_stats = execute_query("""
        SELECT s.course,
               COUNT(DISTINCT s.student_id) AS enrolled_count,
               COUNT(m.mark_id) AS total_assessments,
               COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
               COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_pct
        FROM students s
        LEFT JOIN marks m ON s.student_id = m.student_id
        GROUP BY s.course
        ORDER BY s.course
    """)

    # 2. Semester Performance Comparison
    sem_stats = execute_query("""
        SELECT s.semester,
               COUNT(DISTINCT s.student_id) AS enrolled_count,
               COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
               COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_pct
        FROM students s
        LEFT JOIN marks m ON s.student_id = m.student_id
        GROUP BY s.semester
        ORDER BY s.semester
    """)

    # 3. Section-wise Average Marks & Attendance
    sec_stats = execute_query("""
        SELECT cs.section_name, cs.course_code, cs.semester,
               COUNT(DISTINCT s.student_id) AS enrolled_count,
               COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
               COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 2), 0.00) AS avg_att_pct
        FROM classes_sections cs
        LEFT JOIN students s ON cs.section_id = s.section_id
        LEFT JOIN marks m ON s.student_id = m.student_id
        LEFT JOIN attendance a ON s.student_id = a.student_id
        GROUP BY cs.section_id, cs.section_name, cs.course_code, cs.semester
        ORDER BY cs.course_code, cs.semester, cs.section_name
    """)

    # 4. Teacher-wise Activity Volume
    teacher_activity_stats = execute_query("""
        SELECT u.full_name, u.email, u.designation, d.department_code,
               (SELECT COUNT(*) FROM attendance a WHERE a.teacher_id = u.user_id) AS attendance_count,
               (SELECT COUNT(*) FROM marks m WHERE m.teacher_id = u.user_id) AS marks_count,
               (SELECT COUNT(*) FROM assignments asgn WHERE asgn.teacher_id = u.user_id) AS assignments_count,
               (SELECT COUNT(*) FROM activity_logs l WHERE l.user_id = u.user_id) AS total_logged_events
        FROM users u
        LEFT JOIN departments d ON u.department_id = d.department_id
        WHERE u.role = 'user' AND u.status = 'active'
        ORDER BY total_logged_events DESC
    """)

    # 5. At-Risk Students list
    at_risk_list = execute_query("""
        SELECT * FROM vw_at_risk_students ORDER BY overall_percentage ASC, attendance_percentage ASC
    """)

    return render_template(
        'admin/analytics.html',
        sessions=sessions_list or [],
        courses=courses_list or [],
        course_stats=course_stats or [],
        sem_stats=sem_stats or [],
        sec_stats=sec_stats or [],
        teacher_activity_stats=teacher_activity_stats or [],
        at_risk_list=at_risk_list or []
    )

# =============================================================================
# 15. REPORTS & EXPORTS (CSV & REPORTLAB PDF)
# =============================================================================
@admin_bp.route('/reports')
@admin_required
def reports():
    courses_list = execute_query("SELECT course_code, course_name FROM courses WHERE status = 'Active' ORDER BY course_code")
    sessions_list = execute_query("SELECT session_id, session_name FROM academic_sessions ORDER BY start_date DESC")
    sections_list = execute_query("SELECT section_id, section_name FROM classes_sections WHERE status = 'Active' ORDER BY section_name")

    return render_template(
        'admin/reports.html',
        courses=courses_list or [],
        sessions=sessions_list or [],
        sections=sections_list or []
    )

@admin_bp.route('/reports/export/csv')
@admin_required
def export_csv():
    report_type = request.args.get('type', 'students')
    si = io.StringIO()
    cw = csv.writer(si)

    filename = f"university_{report_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    if report_type == 'students':
        cw.writerow(['Student ID', 'Roll Number', 'Full Name', 'Email', 'Phone', 'Gender', 'Course', 'Semester', 'Section', 'Enrollment Date', 'Status'])
        rows = execute_query("""
            SELECT s.student_id, s.roll_number, s.full_name, s.email, s.phone, s.gender, s.course, s.semester,
                   COALESCE(cs.section_name, 'Unassigned') AS section_name, s.enrollment_date, s.status
            FROM students s
            LEFT JOIN classes_sections cs ON s.section_id = cs.section_id
            ORDER BY s.student_id ASC
        """)
        for r in rows:
            cw.writerow([r['student_id'], r['roll_number'], r['full_name'], r['email'], r['phone'], r['gender'], r['course'], r['semester'], r['section_name'], r['enrollment_date'], r['status']])

    elif report_type == 'attendance':
        cw.writerow(['Attendance ID', 'Date', 'Roll Number', 'Student Name', 'Course', 'Semester', 'Section', 'Subject Code', 'Subject Name', 'Status', 'Faculty Recorded', 'Remarks'])
        rows = execute_query("""
            SELECT a.attendance_id, a.attendance_date, s.roll_number, s.full_name AS student_name, s.course, s.semester,
                   COALESCE(cs.section_name, '-') AS section_name, sub.subject_code, sub.subject_name, a.status,
                   COALESCE(u.full_name, 'Faculty') AS teacher_name, a.remarks
            FROM attendance a
            INNER JOIN students s ON a.student_id = s.student_id
            INNER JOIN subjects sub ON a.subject_id = sub.subject_id
            LEFT JOIN classes_sections cs ON a.section_id = cs.section_id
            LEFT JOIN users u ON a.teacher_id = u.user_id
            ORDER BY a.attendance_date DESC, a.attendance_id DESC
        """)
        for r in rows:
            cw.writerow([r['attendance_id'], r['attendance_date'], r['roll_number'], r['student_name'], r['course'], r['semester'], r['section_name'], r['subject_code'], r['subject_name'], r['status'], r['teacher_name'], r['remarks']])

    elif report_type == 'marks':
        cw.writerow(['Mark ID', 'Roll Number', 'Student Name', 'Course', 'Semester', 'Section', 'Subject Code', 'Subject Name', 'Exam Type', 'Obtained Marks', 'Percentage', 'Grade', 'Status', 'Faculty Submitted', 'Exam Date'])
        rows = execute_query("""
            SELECT m.mark_id, s.roll_number, s.full_name AS student_name, s.course, s.semester,
                   COALESCE(cs.section_name, '-') AS section_name, sub.subject_code, sub.subject_name,
                   m.exam_type, m.obtained_marks, m.percentage, m.grade, m.status,
                   COALESCE(u.full_name, 'Faculty') AS teacher_name, m.exam_date
            FROM marks m
            INNER JOIN students s ON m.student_id = s.student_id
            INNER JOIN subjects sub ON m.subject_id = sub.subject_id
            LEFT JOIN classes_sections cs ON m.section_id = cs.section_id
            LEFT JOIN users u ON m.teacher_id = u.user_id
            ORDER BY m.mark_id DESC
        """)
        for r in rows:
            cw.writerow([r['mark_id'], r['roll_number'], r['student_name'], r['course'], r['semester'], r['section_name'], r['subject_code'], r['subject_name'], r['exam_type'], r['obtained_marks'], r['percentage'], r['grade'], r['status'], r['teacher_name'], r['exam_date']])

    elif report_type == 'teachers':
        cw.writerow(['User ID', 'Employee ID', 'Full Name', 'Email', 'Phone', 'Department', 'Designation', 'Status', 'Last Login'])
        rows = execute_query("""
            SELECT u.user_id, COALESCE(u.employee_id, '-') AS employee_id, u.full_name, u.email, u.phone,
                   COALESCE(d.department_name, '-') AS department_name, COALESCE(u.designation, '-') AS designation,
                   u.status, u.last_login
            FROM users u
            LEFT JOIN departments d ON u.department_id = d.department_id
            WHERE u.role = 'user'
            ORDER BY u.full_name ASC
        """)
        for r in rows:
            cw.writerow([r['user_id'], r['employee_id'], r['full_name'], r['email'], r['phone'], r['department_name'], r['designation'], r['status'], r['last_login']])

    elif report_type == 'teacher_activity':
        cw.writerow(['Log ID', 'Timestamp', 'Faculty Name', 'Action', 'Entity Type', 'Course', 'Semester', 'Section', 'Subject', 'Details', 'IP Address'])
        rows = execute_query("""
            SELECT act.log_id, act.created_at, COALESCE(u.full_name, 'System') AS teacher_name, act.action, act.entity_type,
                   COALESCE(act.course, '-') AS course, COALESCE(act.semester, '-') AS semester,
                   COALESCE(act.section_name, '-') AS section_name, COALESCE(act.subject_name, '-') AS subject_name,
                   act.details, act.ip_address
            FROM activity_logs act
            LEFT JOIN users u ON act.user_id = u.user_id
            ORDER BY act.created_at DESC
        """)
        for r in rows:
            cw.writerow([r['log_id'], r['created_at'], r['teacher_name'], r['action'], r['entity_type'], r['course'], r['semester'], r['section_name'], r['subject_name'], r['details'], r['ip_address']])

    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = f"attachment; filename={filename}"
    output.headers["Content-type"] = "text/csv; charset=utf-8"
    return output

@admin_bp.route('/reports/export/pdf')
@admin_required
def export_pdf():
    """Generates an official institutional PDF report using ReportLab."""
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=36,
            leftMargin=36,
            topMargin=36,
            bottomMargin=36
        )

        elements = []
        styles = getSampleStyleSheet()

        # Custom typography styles
        title_style = ParagraphStyle(
            'UniversityTitle',
            parent=styles['Heading1'],
            fontName='Helvetica-Bold',
            fontSize=18,
            textColor=colors.HexColor('#1e3a8a'),
            alignment=1,
            spaceAfter=4
        )
        subtitle_style = ParagraphStyle(
            'UniversitySub',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=11,
            textColor=colors.HexColor('#475569'),
            alignment=1,
            spaceAfter=12
        )
        h2_style = ParagraphStyle(
            'SectionH2',
            parent=styles['Heading2'],
            fontName='Helvetica-Bold',
            fontSize=12,
            textColor=colors.HexColor('#0f172a'),
            spaceBefore=10,
            spaceAfter=6
        )
        cell_style = ParagraphStyle(
            'TableCell',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=8,
            leading=10
        )
        header_cell_style = ParagraphStyle(
            'TableHeaderCell',
            parent=styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=8,
            leading=10,
            textColor=colors.white
        )

        # Header
        elements.append(Paragraph("STUDENT PERFORMANCE ANALYTICS SYSTEM", title_style))
        elements.append(Paragraph("OFFICIAL UNIVERSITY ACADEMIC MONITORING REPORT", subtitle_style))
        elements.append(Paragraph(f"Generated on: {datetime.now().strftime('%B %d, %Y at %I:%M %p')} | Authorized Administrator: {session.get('full_name', 'System Admin')}", subtitle_style))
        elements.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#2563eb'), spaceBefore=2, spaceAfter=14))

        avg_perf = (execute_query('SELECT COALESCE(ROUND(AVG(obtained_marks), 2), 0) AS a FROM marks', fetch='one') or {}).get('a', 0)
        att_rate = (execute_query("SELECT COALESCE(ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END)/COUNT(*))*100, 2), 0) AS a FROM attendance", fetch='one') or {}).get('a', 0)
        tot_students = (execute_query("SELECT COUNT(*) AS c FROM students", fetch='one') or {}).get('c', 0)
        tot_faculty = (execute_query("SELECT COUNT(*) AS c FROM users WHERE role='user'", fetch='one') or {}).get('c', 0)
        tot_courses = (execute_query("SELECT COUNT(*) AS c FROM courses WHERE status='Active'", fetch='one') or {}).get('c', 0)
        tot_sections = (execute_query("SELECT COUNT(*) AS c FROM classes_sections WHERE status='Active'", fetch='one') or {}).get('c', 0)

        # KPI Summary Table
        kpi_data = [
            [
                Paragraph("<b>Total Enrolled Students</b>", cell_style),
                Paragraph(str(tot_students), cell_style),
                Paragraph("<b>Total Active Faculty</b>", cell_style),
                Paragraph(str(tot_faculty), cell_style)
            ],
            [
                Paragraph("<b>Total Academic Courses</b>", cell_style),
                Paragraph(str(tot_courses), cell_style),
                Paragraph("<b>Total Classes / Sections</b>", cell_style),
                Paragraph(str(tot_sections), cell_style)
            ],
            [
                Paragraph("<b>Average Performance</b>", cell_style),
                Paragraph(f"{avg_perf}%", cell_style),
                Paragraph("<b>Overall Attendance Rate</b>", cell_style),
                Paragraph(f"{att_rate}%", cell_style)
            ]
        ]
        t_kpi = Table(kpi_data, colWidths=[140, 130, 140, 130])
        t_kpi.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        elements.append(t_kpi)
        elements.append(Spacer(1, 14))

        # Section 1: Course Summary
        elements.append(Paragraph("1. Course-wise Academic Performance Breakdown", h2_style))
        course_rows = execute_query("""
            SELECT c.course_code, c.course_name,
                   (SELECT COUNT(*) FROM students s WHERE s.course = c.course_code) AS enrolled,
                   COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_score,
                   COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_pct
            FROM courses c
            LEFT JOIN students s ON s.course = c.course_code
            LEFT JOIN marks m ON s.student_id = m.student_id
            WHERE c.status = 'Active'
            GROUP BY c.course_id, c.course_code, c.course_name
            ORDER BY c.course_code
        """)
        c_table_data = [[
            Paragraph("Course Code", header_cell_style),
            Paragraph("Program Title", header_cell_style),
            Paragraph("Enrolled", header_cell_style),
            Paragraph("Avg Score", header_cell_style),
            Paragraph("Pass %", header_cell_style)
        ]]
        for cr in (course_rows or []):
            c_table_data.append([
                Paragraph(cr['course_code'], cell_style),
                Paragraph(cr['course_name'], cell_style),
                Paragraph(str(cr['enrolled']), cell_style),
                Paragraph(f"{cr['avg_score']}", cell_style),
                Paragraph(f"{cr['pass_pct']}%", cell_style)
            ])
        t_courses = Table(c_table_data, colWidths=[80, 240, 70, 75, 75])
        t_courses.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e40af')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')]),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(t_courses)
        elements.append(Spacer(1, 14))

        # Section 2: Recent Academic Monitoring Logs
        elements.append(Paragraph("2. Recent Faculty Academic Submissions (Audit Extract)", h2_style))
        act_rows = execute_query("""
            SELECT act.created_at, COALESCE(u.full_name, 'Faculty') AS teacher_name,
                   act.action, COALESCE(act.course, '-') AS course, COALESCE(act.section_name, '-') AS section,
                   act.details
            FROM activity_logs act
            LEFT JOIN users u ON act.user_id = u.user_id
            ORDER BY act.created_at DESC LIMIT 10
        """)
        act_table_data = [[
            Paragraph("Timestamp", header_cell_style),
            Paragraph("Faculty", header_cell_style),
            Paragraph("Action", header_cell_style),
            Paragraph("Class/Sec", header_cell_style),
            Paragraph("Submission Details", header_cell_style)
        ]]
        for ar in (act_rows or []):
            ts = str(ar['created_at'])[:16]
            act_table_data.append([
                Paragraph(ts, cell_style),
                Paragraph(ar['teacher_name'], cell_style),
                Paragraph(ar['action'], cell_style),
                Paragraph(f"{ar['course']} {ar['section']}", cell_style),
                Paragraph(ar['details'][:50] + ('...' if len(ar['details']) > 50 else ''), cell_style)
            ])
        t_act = Table(act_table_data, colWidths=[95, 100, 95, 80, 170])
        t_act.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0f766e')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')]),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#cbd5e1')),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(t_act)

        # Build PDF Document
        doc.build(elements)
        buffer.seek(0)

        response = make_response(buffer.getvalue())
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = f"inline; filename=university_academic_report_{datetime.now().strftime('%Y%m%d')}.pdf"
        return response
    except Exception as e:
        flash(f"Error generating PDF report: {e}", "danger")
        return redirect(url_for('admin.reports'))

# =============================================================================
# 16. SETTINGS & SYSTEM STATUS
# =============================================================================
@admin_bp.route('/settings', methods=['GET', 'POST'])
@admin_required
def settings():
    db_ok, db_msg = check_db_status()
    db_counts = {}
    if db_ok:
        try:
            for tbl in ['users', 'students', 'courses', 'subjects', 'departments', 'classes_sections', 'attendance', 'marks', 'assignments', 'activity_logs']:
                r = execute_query(f"SELECT COUNT(*) AS c FROM {tbl}", fetch='one')
                db_counts[tbl] = r['c'] if r else 0
        except Exception:
            pass

    if request.method == 'POST':
        flash("University administration settings updated successfully.", "success")
        return redirect(url_for('admin.settings'))

    return render_template(
        'admin/settings.html',
        db_ok=db_ok,
        db_msg=db_msg,
        db_counts=db_counts
    )
