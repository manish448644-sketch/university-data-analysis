from flask import Blueprint, render_template, request, jsonify
from routes import login_required
from db import execute_query

analytics_bp = Blueprint('analytics', __name__, url_prefix='/analytics')

@analytics_bp.route('')
@login_required
def index():
    # Load session options with explicit boolean normalization
    sessions_raw = execute_query("""
        SELECT session_id, session_name, CAST(is_current AS UNSIGNED) AS is_current 
        FROM academic_sessions 
        ORDER BY start_date DESC
    """)
    sessions = []
    for s in (sessions_raw or []):
        is_cur = bool(s.get('is_current') in [1, b'\x01', '1', True])
        sessions.append({
            'session_id': s['session_id'],
            'session_name': s['session_name'],
            'is_current': is_cur
        })

    courses = execute_query("SELECT DISTINCT course FROM students ORDER BY course")
    
    return render_template('analytics.html', sessions=sessions, courses=courses)

@analytics_bp.route('/api/data')
@login_required
def analytics_data():
    session_id = request.args.get('session_id')
    course = request.args.get('course')
    semester = request.args.get('semester')

    # Construct WHERE filters
    m_conditions = []
    m_params = []
    
    if session_id and session_id != 'all':
        m_conditions.append("m.session_id = %s")
        m_params.append(int(session_id))
    if course and course != 'all':
        m_conditions.append("s.course = %s")
        m_params.append(course)
    if semester and semester != 'all':
        m_conditions.append("s.semester = %s")
        m_params.append(int(semester))

    where_marks = " WHERE " + " AND ".join(m_conditions) if m_conditions else ""

    try:
        # 1. Highest-scoring students (Top 10)
        highest_query = f"""
            SELECT 
                s.student_id,
                s.roll_number,
                s.full_name,
                s.course,
                s.semester,
                COUNT(m.mark_id) AS total_exams,
                ROUND(AVG(m.percentage), 2) AS overall_percentage,
                MAX(m.percentage) AS peak_score
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            {where_marks}
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            ORDER BY overall_percentage DESC
            LIMIT 10
        """
        highest_scoring = execute_query(highest_query, m_params)

        # 2. Lowest-scoring students (Bottom 10)
        lowest_query = f"""
            SELECT 
                s.student_id,
                s.roll_number,
                s.full_name,
                s.course,
                s.semester,
                COUNT(m.mark_id) AS total_exams,
                ROUND(AVG(m.percentage), 2) AS overall_percentage,
                MIN(m.percentage) AS lowest_score
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            {where_marks}
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            ORDER BY overall_percentage ASC
            LIMIT 10
        """
        lowest_scoring = execute_query(lowest_query, m_params)

        # 3. Subject-wise average marks & pass rate
        subject_query = f"""
            SELECT 
                sub.subject_code,
                sub.subject_name,
                sub.course,
                sub.semester,
                COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
                COALESCE(MIN(m.obtained_marks), 0.00) AS min_marks,
                COALESCE(MAX(m.obtained_marks), 0.00) AS max_marks,
                COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_rate
            FROM subjects sub
            INNER JOIN marks m ON sub.subject_id = m.subject_id
            INNER JOIN students s ON m.student_id = s.student_id
            {where_marks}
            GROUP BY sub.subject_id, sub.subject_code, sub.subject_name, sub.course, sub.semester
            ORDER BY avg_marks DESC
        """
        subject_performance = execute_query(subject_query, m_params)

        # 4. Course-wise performance
        course_query = f"""
            SELECT 
                s.course,
                COUNT(DISTINCT s.student_id) AS student_count,
                COALESCE(ROUND(AVG(m.percentage), 2), 0.00) AS avg_course_percentage,
                COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS course_pass_rate
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            {where_marks}
            GROUP BY s.course
            ORDER BY avg_course_percentage DESC
        """
        course_performance = execute_query(course_query, m_params)

        # 5. Semester-wise performance
        semester_query = f"""
            SELECT 
                s.semester,
                COUNT(DISTINCT s.student_id) AS student_count,
                COALESCE(ROUND(AVG(m.percentage), 2), 0.00) AS avg_sem_percentage,
                COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS sem_pass_rate
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            {where_marks}
            GROUP BY s.semester
            ORDER BY s.semester ASC
        """
        semester_performance = execute_query(semester_query, m_params)

        # 6. Overall Pass / Failure percentage
        pass_fail_query = f"""
            SELECT 
                SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) AS passed_count,
                SUM(CASE WHEN m.status = 'Fail' THEN 1 ELSE 0 END) AS failed_count,
                COUNT(m.mark_id) AS total_assessments,
                COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_pct,
                COALESCE(ROUND((SUM(CASE WHEN m.status = 'Fail' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS fail_pct
            FROM marks m
            INNER JOIN students s ON m.student_id = s.student_id
            {where_marks}
        """
        pass_fail_res = execute_query(pass_fail_query, m_params, fetch='one')

        # 7. Grade distribution (Safely computed without subquery alias issues)
        total_marks_res = execute_query(
            f"SELECT COUNT(*) AS total FROM marks m INNER JOIN students s ON m.student_id = s.student_id {where_marks}",
            m_params,
            fetch='one'
        )
        total_marks_count = total_marks_res['total'] if total_marks_res else 0

        grade_query = f"""
            SELECT 
                m.grade,
                COUNT(m.mark_id) AS count
            FROM marks m
            INNER JOIN students s ON m.student_id = s.student_id
            {where_marks}
            GROUP BY m.grade
            ORDER BY FIELD(m.grade, 'A+', 'A', 'B', 'C', 'D', 'F')
        """
        grade_rows = execute_query(grade_query, m_params)
        grade_dist = [
            {
                'grade': r['grade'],
                'count': r['count'],
                'pct': round((r['count'] / total_marks_count) * 100, 1) if total_marks_count > 0 else 0.0
            }
            for r in grade_rows
        ]

        # 8. Attendance vs Academic Performance correlation
        att_corr_query = f"""
            SELECT 
                s.student_id,
                s.roll_number,
                s.full_name,
                ROUND(AVG(m.percentage), 2) AS academic_percentage,
                ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 2) AS attendance_percentage
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            LEFT JOIN attendance a ON s.student_id = a.student_id
            {where_marks}
            GROUP BY s.student_id, s.roll_number, s.full_name
            HAVING attendance_percentage IS NOT NULL
            ORDER BY attendance_percentage DESC
            LIMIT 50
        """
        att_corr_data = execute_query(att_corr_query, m_params)

        # 9. Students requiring academic improvement (At Risk)
        improvement_query = f"""
            SELECT 
                s.student_id,
                s.roll_number,
                s.full_name,
                s.course,
                s.semester,
                COALESCE(ROUND(AVG(m.percentage), 2), 0.00) AS academic_score,
                COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 2), 0.00) AS attendance_rate,
                CASE 
                    WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100 < 75.00 AND AVG(m.percentage) < 50.00 
                        THEN 'Critical (Attendance & Marks)'
                    WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100 < 75.00 
                        THEN 'Low Attendance Warning (<75%)'
                    ELSE 'Low Academic Score Warning (<50%)'
                END AS reason_flag
            FROM students s
            LEFT JOIN marks m ON s.student_id = m.student_id
            LEFT JOIN attendance a ON s.student_id = a.student_id
            {where_marks}
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            HAVING attendance_rate < 75.00 OR academic_score < 50.00
            ORDER BY academic_score ASC, attendance_rate ASC
            LIMIT 30
        """
        improvement_students = execute_query(improvement_query, m_params)

        return jsonify({
            'success': True,
            'highest_scoring': highest_scoring or [],
            'lowest_scoring': lowest_scoring or [],
            'subject_performance': subject_performance or [],
            'course_performance': course_performance or [],
            'semester_performance': semester_performance or [],
            'pass_fail': pass_fail_res or {'passed_count': 0, 'failed_count': 0, 'pass_pct': 0.00, 'fail_pct': 0.00},
            'grade_distribution': grade_dist or [],
            'attendance_correlation': att_corr_data or [],
            'improvement_needed': improvement_students or []
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
