from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from routes import login_required
from db import execute_query, check_db_status

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
@dashboard_bp.route('/dashboard')
@login_required
def index():
    if request.path == '/' and session.get('role') == 'admin':
        return redirect(url_for('admin.dashboard'))
    # Fetch filter options
    db_ok, db_msg = check_db_status()
    sessions = []
    courses = []
    subjects = []
    
    if db_ok:
        try:
            sessions_raw = execute_query("""
                SELECT session_id, session_name, CAST(is_current AS UNSIGNED) AS is_current 
                FROM academic_sessions 
                ORDER BY start_date DESC
            """)
            sessions = []
            for s in (sessions_raw or []):
                sessions.append({
                    'session_id': s['session_id'],
                    'session_name': s['session_name'],
                    'is_current': bool(s.get('is_current') in [1, b'\x01', '1', True])
                })
            courses = execute_query("SELECT DISTINCT course FROM students ORDER BY course")
            subjects = execute_query("SELECT subject_id, subject_code, subject_name FROM subjects ORDER BY subject_code")
        except Exception as e:
            pass
            
    return render_template(
        'dashboard.html',
        sessions=sessions,
        courses=courses,
        subjects=subjects,
        db_ok=db_ok,
        db_msg=db_msg
    )

@dashboard_bp.route('/api/dashboard/data')
@login_required
def dashboard_data():
    session_id = request.args.get('session_id')
    course = request.args.get('course')
    semester = request.args.get('semester')
    exam_type = request.args.get('exam_type')

    # Base WHERE clauses
    marks_conditions = []
    marks_params = []
    
    students_conditions = ["status = 'Active'"]
    students_params = []

    if session_id and session_id != 'all':
        marks_conditions.append("m.session_id = %s")
        marks_params.append(int(session_id))
    if course and course != 'all':
        marks_conditions.append("s.course = %s")
        marks_params.append(course)
        students_conditions.append("course = %s")
        students_params.append(course)
    if semester and semester != 'all':
        marks_conditions.append("s.semester = %s")
        marks_params.append(int(semester))
        students_conditions.append("semester = %s")
        students_params.append(int(semester))
    if exam_type and exam_type != 'all':
        marks_conditions.append("m.exam_type = %s")
        marks_params.append(exam_type)

    where_marks_clause = " WHERE " + " AND ".join(marks_conditions) if marks_conditions else ""
    where_students_clause = " WHERE " + " AND ".join(students_conditions) if students_conditions else ""

    try:
        # 1. Total Students
        total_students_res = execute_query(
            f"SELECT COUNT(*) AS total FROM students {where_students_clause}",
            students_params,
            fetch='one'
        )
        total_students = total_students_res['total'] if total_students_res else 0

        # 2. Total Subjects
        total_subjects_res = execute_query("SELECT COUNT(*) AS total FROM subjects", fetch='one')
        total_subjects = total_subjects_res['total'] if total_subjects_res else 0

        # 3. Average Marks & Pass Percentage
        avg_pass_query = f"""
            SELECT 
                COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
                COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_percentage,
                COUNT(m.mark_id) AS total_assessments
            FROM marks m
            INNER JOIN students s ON m.student_id = s.student_id
            {where_marks_clause}
        """
        avg_pass_res = execute_query(avg_pass_query, marks_params, fetch='one')
        avg_marks = float(avg_pass_res['avg_marks']) if avg_pass_res else 0.00
        pass_percentage = float(avg_pass_res['pass_percentage']) if avg_pass_res else 0.00

        # 4. Average Attendance
        att_conditions = []
        att_params = []
        if course and course != 'all':
            att_conditions.append("s.course = %s")
            att_params.append(course)
        if semester and semester != 'all':
            att_conditions.append("s.semester = %s")
            att_params.append(int(semester))

        where_att = " WHERE " + " AND ".join(att_conditions) if att_conditions else ""
        att_query = f"""
            SELECT 
                COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 2), 0.00) AS avg_attendance
            FROM attendance a
            INNER JOIN students s ON a.student_id = s.student_id
            {where_att}
        """
        att_res = execute_query(att_query, att_params, fetch='one')
        avg_attendance = float(att_res['avg_attendance']) if att_res else 0.00

        # 5. Students at Risk count (<75% attendance or <50% avg marks)
        risk_query = f"""
            SELECT COUNT(DISTINCT s.student_id) AS at_risk_count
            FROM students s
            LEFT JOIN (
                SELECT student_id, AVG(percentage) as avg_pct
                FROM marks
                GROUP BY student_id
            ) m_avg ON s.student_id = m_avg.student_id
            LEFT JOIN (
                SELECT student_id,
                       (SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS att_pct
                FROM attendance
                GROUP BY student_id
            ) a_avg ON s.student_id = a_avg.student_id
            WHERE s.status = 'Active' 
              AND (COALESCE(a_avg.att_pct, 100.0) < 75.00 OR COALESCE(m_avg.avg_pct, 100.0) < 50.00)
              {" AND s.course = %s" if course and course != 'all' else ""}
              {" AND s.semester = %s" if semester and semester != 'all' else ""}
        """
        risk_params = []
        if course and course != 'all': risk_params.append(course)
        if semester and semester != 'all': risk_params.append(int(semester))
        risk_res = execute_query(risk_query, risk_params, fetch='one')
        students_at_risk = risk_res['at_risk_count'] if risk_res else 0

        # CHART 1: Student Performance Distribution
        # Excellent (>=90%), Good (75-89.99%), Average (50-74.99%), Below Average (<50%)
        dist_query = f"""
            SELECT 
                SUM(CASE WHEN student_avg >= 90 THEN 1 ELSE 0 END) AS excellent,
                SUM(CASE WHEN student_avg >= 75 AND student_avg < 90 THEN 1 ELSE 0 END) AS good,
                SUM(CASE WHEN student_avg >= 50 AND student_avg < 75 THEN 1 ELSE 0 END) AS average,
                SUM(CASE WHEN student_avg < 50 THEN 1 ELSE 0 END) AS below_avg
            FROM (
                SELECT s.student_id, AVG(m.percentage) AS student_avg
                FROM students s
                INNER JOIN marks m ON s.student_id = m.student_id
                {where_marks_clause}
                GROUP BY s.student_id
            ) student_performances
        """
        dist_res = execute_query(dist_query, marks_params, fetch='one')
        distribution = {
            'labels': ['Excellent (≥90%)', 'Good (75-89%)', 'Average (50-74%)', 'Below Average (<50%)'],
            'data': [
                int(dist_res['excellent'] or 0),
                int(dist_res['good'] or 0),
                int(dist_res['average'] or 0),
                int(dist_res['below_avg'] or 0)
            ],
            'colors': ['#10b981', '#3b82f6', '#f59e0b', '#ef4444']
        }

        # CHART 2: Subject-wise Average Marks
        subj_query = f"""
            SELECT 
                sub.subject_code,
                sub.subject_name,
                COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks
            FROM subjects sub
            LEFT JOIN marks m ON sub.subject_id = m.subject_id
            LEFT JOIN students s ON m.student_id = s.student_id
            {where_marks_clause}
            GROUP BY sub.subject_id, sub.subject_code, sub.subject_name
            ORDER BY avg_marks DESC
        """
        subj_rows = execute_query(subj_query, marks_params)
        subject_chart = {
            'labels': [r['subject_code'] for r in subj_rows],
            'names': [r['subject_name'] for r in subj_rows],
            'data': [float(r['avg_marks']) for r in subj_rows]
        }

        # CHART 3: Monthly / Assessment Performance Trends
        trend_query = f"""
            SELECT 
                COALESCE(DATE_FORMAT(m.exam_date, '%b %Y'), m.exam_type) AS timeline,
                ROUND(AVG(m.percentage), 2) AS avg_pct
            FROM marks m
            INNER JOIN students s ON m.student_id = s.student_id
            {where_marks_clause}
            GROUP BY timeline
            ORDER BY MIN(m.exam_date) ASC
        """
        trend_rows = execute_query(trend_query, marks_params)
        trend_chart = {
            'labels': [r['timeline'] for r in trend_rows],
            'data': [float(r['avg_pct']) for r in trend_rows]
        }

        # CHART 4: Attendance Analysis (>=75% vs <75%)
        att_dist_query = f"""
            SELECT 
                SUM(CASE WHEN att_pct >= 75.0 THEN 1 ELSE 0 END) AS regular_count,
                SUM(CASE WHEN att_pct < 75.0 THEN 1 ELSE 0 END) AS at_risk_count
            FROM (
                SELECT s.student_id,
                       (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(a.attendance_id)) * 100 AS att_pct
                FROM students s
                INNER JOIN attendance a ON s.student_id = a.student_id
                {where_att}
                GROUP BY s.student_id
            ) student_att
        """
        att_dist_res = execute_query(att_dist_query, att_params, fetch='one')
        attendance_chart = {
            'labels': ['Regular (≥75%)', 'At Risk (<75%)'],
            'data': [
                int(att_dist_res['regular_count'] or 0) if att_dist_res else 0,
                int(att_dist_res['at_risk_count'] or 0) if att_dist_res else 0
            ],
            'colors': ['#10b981', '#ef4444']
        }

        # CHART 5: Top 10 Performing Students
        top10_query = f"""
            SELECT 
                s.roll_number,
                s.full_name,
                ROUND(AVG(m.percentage), 2) AS overall_pct
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            {where_marks_clause}
            GROUP BY s.student_id, s.roll_number, s.full_name
            ORDER BY overall_pct DESC
            LIMIT 10
        """
        top10_rows = execute_query(top10_query, marks_params)
        top10_chart = {
            'labels': [f"{r['roll_number']} - {r['full_name']}" for r in top10_rows],
            'data': [float(r['overall_pct']) for r in top10_rows]
        }

        return jsonify({
            'success': True,
            'kpis': {
                'total_students': total_students,
                'total_subjects': total_subjects,
                'average_marks': avg_marks,
                'pass_percentage': pass_percentage,
                'average_attendance': avg_attendance,
                'students_at_risk': students_at_risk
            },
            'charts': {
                'distribution': distribution,
                'subject_averages': subject_chart,
                'performance_trends': trend_chart,
                'attendance_analysis': attendance_chart,
                'top_students': top10_chart
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
