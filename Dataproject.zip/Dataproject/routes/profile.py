import math
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from routes import login_required, admin_required
from db import execute_query, log_activity

profile_bp = Blueprint('profile', __name__)

@profile_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def view_profile():
    user_id = session.get('user_id')
    user = execute_query("SELECT * FROM users WHERE user_id = %s", (user_id,), fetch='one')

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        phone = request.form.get('phone', '').strip()

        if not full_name:
            flash('Full name is required.', 'danger')
            return redirect(url_for('profile.view_profile'))

        try:
            execute_query("UPDATE users SET full_name = %s, phone = %s WHERE user_id = %s", (full_name, phone, user_id), commit=True)
            session['full_name'] = full_name
            log_activity(user_id, 'Update Profile', 'Users', user_id, f"User {user['email']} updated profile details", request.remote_addr)
            flash('Profile details updated successfully.', 'success')
            return redirect(url_for('profile.view_profile'))
        except Exception as e:
            flash(f"Error updating profile: {e}", 'danger')

    # Get recent user activities
    recent_logs = execute_query("""
        SELECT * FROM activity_logs 
        WHERE user_id = %s 
        ORDER BY created_at DESC 
        LIMIT 10
    """, (user_id,))

    return render_template('profile.html', user=user, recent_logs=recent_logs)

@profile_bp.route('/profile/change-password', methods=['POST'])
@login_required
def change_password():
    user_id = session.get('user_id')
    current_password = request.form.get('current_password', '')
    new_password = request.form.get('new_password', '')
    confirm_password = request.form.get('confirm_password', '')

    if not current_password or not new_password:
        flash('Please fill in all password fields.', 'danger')
        return redirect(url_for('profile.view_profile'))

    if new_password != confirm_password:
        flash('New passwords do not match.', 'danger')
        return redirect(url_for('profile.view_profile'))

    if len(new_password) < 6:
        flash('New password must be at least 6 characters long.', 'danger')
        return redirect(url_for('profile.view_profile'))

    try:
        user = execute_query("SELECT password_hash, email FROM users WHERE user_id = %s", (user_id,), fetch='one')
        if not user or not check_password_hash(user['password_hash'], current_password):
            flash('Current password is incorrect.', 'danger')
            return redirect(url_for('profile.view_profile'))

        pw_hash = generate_password_hash(new_password)
        execute_query("UPDATE users SET password_hash = %s WHERE user_id = %s", (pw_hash, user_id), commit=True)
        log_activity(user_id, 'Change Password', 'Users', user_id, f"User {user['email']} changed password", request.remote_addr)
        flash('Password successfully updated!', 'success')
    except Exception as e:
        flash(f"Error updating password: {e}", 'danger')

    return redirect(url_for('profile.view_profile'))

@profile_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    user_id = session.get('user_id')
    user = execute_query("SELECT * FROM users WHERE user_id = %s", (user_id,), fetch='one')

    if request.method == 'POST':
        flash('Preferences saved successfully.', 'success')
        return redirect(url_for('profile.settings'))

    return render_template('settings.html', user=user)

@profile_bp.route('/activity-logs')
@admin_required
def activity_logs():
    page = int(request.args.get('page', 1))
    per_page = 20
    action_filter = request.args.get('action', '').strip()

    conditions = []
    params = []
    if action_filter:
        conditions.append("a.action LIKE %s")
        params.append(f"%{action_filter}%")

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    count_res = execute_query(f"SELECT COUNT(*) AS total FROM activity_logs a {where_clause}", params, fetch='one')
    total = count_res['total'] if count_res else 0
    total_pages = max(1, math.ceil(total / per_page))
    page = max(1, min(page, total_pages))
    offset = (page - 1) * per_page

    query = f"""
        SELECT a.*, u.full_name AS user_name, u.email AS user_email
        FROM activity_logs a
        LEFT JOIN users u ON a.user_id = u.user_id
        {where_clause}
        ORDER BY a.created_at DESC
        LIMIT %s OFFSET %s
    """
    query_params = list(params) + [per_page, offset]
    logs = execute_query(query, query_params)

    return render_template(
        'activity_logs.html',
        logs=logs,
        page=page,
        total_pages=total_pages,
        total_records=total,
        action_filter=action_filter
    )
