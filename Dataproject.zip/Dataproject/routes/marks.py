import math
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from routes import login_required
from db import execute_query, log_activity

marks_bp = Blueprint('marks', __name__, url_prefix='/marks')

def calculate_grade_and_status(obtained_marks, max_marks, passing_marks):
    pct = round((obtained_marks / max_marks) * 100, 2)
    if pct >= 90.0:
        grade = 'A+'
    elif pct >= 80.0:
        grade = 'A'
    elif pct >= 70.0:
        grade = 'B'
    elif pct >= 60.0:
        grade = 'C'
    elif pct >= 50.0:
        grade = 'D'
    else:
        grade = 'F'
        
    status = 'Pass' if (obtained_marks >= passing_marks and pct >= 50.0) else 'Fail'
    return pct, grade, status

@marks_bp.route('')
@login_required
def index():
    student_filter = request.args.get('student_id', '').strip()
    subject_filter = request.args.get('subject_id', '').strip()
    session_filter = request.args.get('session_id', '').strip()
    exam_filter = request.args.get('exam_type', '').strip()
    page = int(request.args.get('page', 1))
    per_page = 20

    conditions = []
    params = []

    if student_filter:
        conditions.append("m.student_id = %s")
        params.append(int(student_filter))
    if subject_filter:
        conditions.append("m.subject_id = %s")
        params.append(int(subject_filter))
    if session_filter:
        conditions.append("m.session_id = %s")
        params.append(int(session_filter))
    if exam_filter:
        conditions.append("m.exam_type = %s")
        params.append(exam_filter)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    count_res = execute_query(f"SELECT COUNT(*) AS total FROM marks m {where_clause}", params, fetch='one')
    total_records = count_res['total'] if count_res else 0
    total_pages = max(1, math.ceil(total_records / per_page))
    page = max(1, min(page, total_pages))
    offset = (page - 1) * per_page

    data_query = f"""
        SELECT 
            m.*,
            s.roll_number,
            s.full_name AS student_name,
            s.course,
            sub.subject_code,
            sub.subject_name,
            sub.max_marks,
            sub.passing_marks,
            sess.session_name
        FROM marks m
        INNER JOIN students s ON m.student_id = s.student_id
        INNER JOIN subjects sub ON m.subject_id = sub.subject_id
        INNER JOIN academic_sessions sess ON m.session_id = sess.session_id
        {where_clause}
        ORDER BY m.mark_id DESC
        LIMIT %s OFFSET %s
    """
    query_params = list(params) + [per_page, offset]
    marks_list = execute_query(data_query, query_params)

    # Fetch drop down data
    students = execute_query("SELECT student_id, roll_number, full_name, course FROM students WHERE status = 'Active' ORDER BY roll_number")
    subjects = execute_query("SELECT subject_id, subject_code, subject_name, max_marks, passing_marks FROM subjects ORDER BY subject_code")
    sessions_raw = execute_query("SELECT session_id, session_name, CAST(is_current AS UNSIGNED) AS is_current FROM academic_sessions ORDER BY start_date DESC")
    sessions = []
    for s in (sessions_raw or []):
        sessions.append({
            'session_id': s['session_id'],
            'session_name': s['session_name'],
            'is_current': bool(s.get('is_current') in [1, b'\x01', '1', True])
        })

    return render_template(
        'marks.html',
        marks=marks_list,
        students=students,
        subjects=subjects,
        sessions=sessions,
        student_filter=student_filter,
        subject_filter=subject_filter,
        session_filter=session_filter,
        exam_filter=exam_filter,
        page=page,
        total_pages=total_pages,
        total_records=total_records
    )

@marks_bp.route('/add', methods=['POST'])
@login_required
def add():
    student_id = request.form.get('student_id')
    subject_id = request.form.get('subject_id')
    session_id = request.form.get('session_id')
    exam_type = request.form.get('exam_type')
    obtained_marks_str = request.form.get('obtained_marks')
    remarks = request.form.get('remarks', '').strip()
    exam_date = request.form.get('exam_date')

    if not (student_id and subject_id and session_id and exam_type and obtained_marks_str):
        flash('All required fields must be supplied.', 'danger')
        return redirect(url_for('marks.index'))

    try:
        obtained_marks = float(obtained_marks_str)
        # Fetch subject max and passing marks
        subj = execute_query("SELECT max_marks, passing_marks FROM subjects WHERE subject_id = %s", (subject_id,), fetch='one')
        if not subj:
            flash('Invalid subject selected.', 'danger')
            return redirect(url_for('marks.index'))

        max_marks = float(subj['max_marks'])
        passing_marks = float(subj['passing_marks'])

        if obtained_marks < 0 or obtained_marks > max_marks:
            flash(f"Obtained marks must be between 0 and {max_marks}.", 'danger')
            return redirect(url_for('marks.index'))

        # Check duplicate
        existing = execute_query("""
            SELECT mark_id FROM marks 
            WHERE student_id = %s AND subject_id = %s AND exam_type = %s AND session_id = %s
        """, (student_id, subject_id, exam_type, session_id), fetch='one')

        if existing:
            flash("A marks record for this Student, Subject, Exam Type, and Session already exists.", 'warning')
            return redirect(url_for('marks.index'))

        percentage, grade, status = calculate_grade_and_status(obtained_marks, max_marks, passing_marks)

        insert_query = """
            INSERT INTO marks (student_id, subject_id, session_id, exam_type, obtained_marks, percentage, grade, status, remarks, exam_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        res = execute_query(
            insert_query,
            (student_id, subject_id, session_id, exam_type, obtained_marks, percentage, grade, status, remarks, exam_date or None),
            commit=True
        )
        log_activity(session.get('user_id'), 'Add Marks', 'Marks', res['last_insert_id'], f"Recorded marks {obtained_marks}/{max_marks} (Grade {grade})", request.remote_addr)
        flash(f"Marks entry successfully saved: {obtained_marks}/{max_marks} ({grade}) - {status}.", 'success')
    except Exception as e:
        flash(f"Error saving marks: {e}", 'danger')

    return redirect(url_for('marks.index'))

@marks_bp.route('/edit/<int:mark_id>', methods=['POST'])
@login_required
def edit(mark_id):
    obtained_marks_str = request.form.get('obtained_marks')
    remarks = request.form.get('remarks', '').strip()
    exam_date = request.form.get('exam_date')

    try:
        existing = execute_query("""
            SELECT m.*, sub.max_marks, sub.passing_marks 
            FROM marks m 
            INNER JOIN subjects sub ON m.subject_id = sub.subject_id
            WHERE m.mark_id = %s
        """, (mark_id,), fetch='one')

        if not existing:
            flash('Marks record not found.', 'danger')
            return redirect(url_for('marks.index'))

        obtained_marks = float(obtained_marks_str)
        max_marks = float(existing['max_marks'])
        passing_marks = float(existing['passing_marks'])

        if obtained_marks < 0 or obtained_marks > max_marks:
            flash(f"Obtained marks must be between 0 and {max_marks}.", 'danger')
            return redirect(url_for('marks.index'))

        percentage, grade, status = calculate_grade_and_status(obtained_marks, max_marks, passing_marks)

        update_query = """
            UPDATE marks
            SET obtained_marks = %s, percentage = %s, grade = %s, status = %s, remarks = %s, exam_date = %s
            WHERE mark_id = %s
        """
        execute_query(
            update_query,
            (obtained_marks, percentage, grade, status, remarks, exam_date or None, mark_id),
            commit=True
        )
        log_activity(session.get('user_id'), 'Edit Marks', 'Marks', mark_id, f"Updated marks to {obtained_marks}/{max_marks} ({grade})", request.remote_addr)
        flash('Marks updated successfully.', 'success')
    except Exception as e:
        flash(f"Error updating marks: {e}", 'danger')

    return redirect(url_for('marks.index'))

@marks_bp.route('/delete/<int:mark_id>', methods=['POST'])
@login_required
def delete(mark_id):
    try:
        execute_query("DELETE FROM marks WHERE mark_id = %s", (mark_id,), commit=True)
        log_activity(session.get('user_id'), 'Delete Marks', 'Marks', mark_id, f"Deleted mark ID {mark_id}", request.remote_addr)
        flash('Marks entry deleted successfully.', 'info')
    except Exception as e:
        flash(f"Error deleting marks: {e}", 'danger')

    return redirect(url_for('marks.index'))
