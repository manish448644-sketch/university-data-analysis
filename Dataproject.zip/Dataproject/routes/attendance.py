from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from datetime import date
from routes import login_required
from db import execute_query, log_activity

attendance_bp = Blueprint('attendance', __name__, url_prefix='/attendance')

@attendance_bp.route('')
@login_required
def index():
    date_filter = request.args.get('date', date.today().strftime('%Y-%m-%d'))
    subject_filter = request.args.get('subject_id', '')
    course_filter = request.args.get('course', '')
    view_mode = request.args.get('view', 'history') # 'history', 'mark', or 'summary'

    # Dropdown lists
    subjects = execute_query("SELECT subject_id, subject_code, subject_name, course, semester FROM subjects ORDER BY subject_code")
    courses = execute_query("SELECT DISTINCT course FROM students ORDER BY course")

    # If in 'mark' mode, fetch student roster for the chosen subject or course to mark attendance
    roster = []
    if view_mode == 'mark' and subject_filter:
        subj = execute_query("SELECT course, semester FROM subjects WHERE subject_id = %s", (subject_filter,), fetch='one')
        if subj:
            roster = execute_query("""
                SELECT s.student_id, s.roll_number, s.full_name, s.course, s.semester,
                       a.status AS existing_status, a.remarks AS existing_remarks
                FROM students s
                LEFT JOIN attendance a ON s.student_id = a.student_id 
                     AND a.subject_id = %s AND a.attendance_date = %s
                WHERE s.status = 'Active' AND s.semester = %s
                ORDER BY s.roll_number
            """, (subject_filter, date_filter, subj['semester']))
            
            # If no semester match or few students, fetch by course
            if not roster:
                roster = execute_query("""
                    SELECT s.student_id, s.roll_number, s.full_name, s.course, s.semester,
                           a.status AS existing_status, a.remarks AS existing_remarks
                    FROM students s
                    LEFT JOIN attendance a ON s.student_id = a.student_id 
                         AND a.subject_id = %s AND a.attendance_date = %s
                    WHERE s.status = 'Active'
                    ORDER BY s.roll_number
                    LIMIT 40
                """, (subject_filter, date_filter))

    # If in 'summary' mode: compute overall attendance percentage per student
    student_summaries = []
    if view_mode == 'summary':
        conditions = ["s.status = 'Active'"]
        params = []
        if course_filter:
            conditions.append("s.course = %s")
            params.append(course_filter)
        where_s = " WHERE " + " AND ".join(conditions)

        summary_query = f"""
            SELECT 
                s.student_id,
                s.roll_number,
                s.full_name,
                s.course,
                s.semester,
                COUNT(a.attendance_id) AS total_classes,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count,
                SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
                COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 1), 0.0) AS attendance_pct
            FROM students s
            LEFT JOIN attendance a ON s.student_id = a.student_id
            {where_s}
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            ORDER BY attendance_pct ASC, s.roll_number ASC
        """
        student_summaries = execute_query(summary_query, params)

    # History view (default)
    history_records = []
    stats = {'present': 0, 'absent': 0, 'late': 0, 'total': 0}
    if view_mode == 'history':
        hist_conditions = []
        hist_params = []
        if date_filter:
            hist_conditions.append("a.attendance_date = %s")
            hist_params.append(date_filter)
        if subject_filter:
            hist_conditions.append("a.subject_id = %s")
            hist_params.append(int(subject_filter))

        where_hist = " WHERE " + " AND ".join(hist_conditions) if hist_conditions else ""
        hist_query = f"""
            SELECT 
                a.*,
                s.roll_number,
                s.full_name AS student_name,
                s.course,
                sub.subject_code,
                sub.subject_name
            FROM attendance a
            INNER JOIN students s ON a.student_id = s.student_id
            INNER JOIN subjects sub ON a.subject_id = sub.subject_id
            {where_hist}
            ORDER BY a.attendance_date DESC, sub.subject_code, s.roll_number
            LIMIT 100
        """
        history_records = execute_query(hist_query, hist_params)

        for rec in history_records:
            stats['total'] += 1
            st = rec['status'].lower()
            if st in stats:
                stats[st] += 1

    return render_template(
        'attendance.html',
        view_mode=view_mode,
        date_filter=date_filter,
        subject_filter=subject_filter,
        course_filter=course_filter,
        subjects=subjects,
        courses=courses,
        roster=roster,
        history=history_records,
        summaries=student_summaries,
        stats=stats
    )

@attendance_bp.route('/save-roster', methods=['POST'])
@login_required
def save_roster():
    subject_id = request.form.get('subject_id')
    att_date = request.form.get('attendance_date')

    if not (subject_id and att_date):
        flash('Subject and date are required.', 'danger')
        return redirect(url_for('attendance.index', view='mark'))

    try:
        # Loop over submitted student statuses
        student_ids = request.form.getlist('student_ids')
        recorded_count = 0

        for sid in student_ids:
            status = request.form.get(f'status_{sid}', 'Present')
            remarks = request.form.get(f'remarks_{sid}', 'Class Session')

            # Upsert using MySQL ON DUPLICATE KEY UPDATE
            query = """
                INSERT INTO attendance (student_id, subject_id, attendance_date, status, remarks)
                VALUES (%s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE status = VALUES(status), remarks = VALUES(remarks)
            """
            execute_query(query, (sid, subject_id, att_date, status, remarks), commit=True)
            recorded_count += 1

        log_activity(session.get('user_id'), 'Mark Attendance', 'Attendance', subject_id, f"Marked attendance for {recorded_count} students on {att_date}", request.remote_addr)
        flash(f"Successfully recorded attendance for {recorded_count} students on {att_date}.", 'success')
    except Exception as e:
        flash(f"Error recording attendance: {e}", 'danger')

    return redirect(url_for('attendance.index', view='history', date=att_date, subject_id=subject_id))

@attendance_bp.route('/edit/<int:attendance_id>', methods=['POST'])
@login_required
def edit(attendance_id):
    status = request.form.get('status', 'Present')
    remarks = request.form.get('remarks', '').strip()

    try:
        execute_query(
            "UPDATE attendance SET status = %s, remarks = %s WHERE attendance_id = %s",
            (status, remarks, attendance_id),
            commit=True
        )
        flash('Attendance entry updated.', 'success')
    except Exception as e:
        flash(f"Error updating attendance: {e}", 'danger')

    return redirect(request.referrer or url_for('attendance.index'))
