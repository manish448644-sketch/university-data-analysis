import io
import csv
from datetime import datetime
from flask import Blueprint, render_template, request, make_response, send_file, flash, redirect, url_for
from routes import login_required
from db import execute_query
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

reports_bp = Blueprint('reports', __name__, url_prefix='/reports')

@reports_bp.route('')
@login_required
def index():
    # Load filter collections
    students = execute_query("SELECT student_id, roll_number, full_name, course FROM students WHERE status = 'Active' ORDER BY roll_number")
    subjects = execute_query("SELECT subject_id, subject_code, subject_name FROM subjects ORDER BY subject_code")
    sessions = execute_query("SELECT session_id, session_name FROM academic_sessions ORDER BY start_date DESC")
    courses = execute_query("SELECT DISTINCT course FROM students ORDER BY course")

    report_type = request.args.get('report_type', 'overall')
    student_id = request.args.get('student_id', '')
    subject_id = request.args.get('subject_id', '')
    session_id = request.args.get('session_id', '')
    course = request.args.get('course', '')
    semester = request.args.get('semester', '')

    data = None
    title = "Academic Performance Report"

    try:
        # If student report selected but no student specified yet, default to first student
        if report_type == 'student':
            if not student_id and students:
                student_id = str(students[0]['student_id'])

            if student_id:
                student_info = execute_query("SELECT * FROM students WHERE student_id = %s", (student_id,), fetch='one')
                marks = execute_query("""
                    SELECT m.*, sub.subject_code, sub.subject_name, sub.max_marks, sub.passing_marks, sub.credits
                    FROM marks m
                    INNER JOIN subjects sub ON m.subject_id = sub.subject_id
                    WHERE m.student_id = %s
                    ORDER BY sub.subject_code, m.exam_type
                """, (student_id,))
                att = execute_query("""
                    SELECT 
                        COUNT(*) AS total_classes,
                        SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended,
                        COALESCE(ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100, 2), 0.00) AS percentage
                    FROM attendance
                    WHERE student_id = %s
                """, (student_id,), fetch='one')

                data = {
                    'student': student_info,
                    'marks': marks,
                    'attendance': att or {'total_classes': 0, 'attended': 0, 'percentage': 0.00}
                }
                title = f"Student Marksheet - {student_info['full_name']} ({student_info['roll_number']})" if student_info else "Student Marksheet"

        elif report_type == 'subject':
            cond = []
            params = []
            if subject_id:
                cond.append("sub.subject_id = %s")
                params.append(subject_id)
            if course:
                cond.append("sub.course = %s")
                params.append(course)
            where_s = " WHERE " + " AND ".join(cond) if cond else ""

            data = execute_query(f"""
                SELECT 
                    sub.subject_code,
                    sub.subject_name,
                    sub.course,
                    sub.semester,
                    COUNT(m.mark_id) AS total_candidates,
                    COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
                    COALESCE(MIN(m.obtained_marks), 0.00) AS lowest_marks,
                    COALESCE(MAX(m.obtained_marks), 0.00) AS highest_marks,
                    SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) AS pass_count,
                    SUM(CASE WHEN m.status = 'Fail' THEN 1 ELSE 0 END) AS fail_count,
                    COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_rate
                FROM subjects sub
                LEFT JOIN marks m ON sub.subject_id = m.subject_id
                {where_s}
                GROUP BY sub.subject_id, sub.subject_code, sub.subject_name, sub.course, sub.semester
                ORDER BY sub.course, sub.semester, sub.subject_code
            """, params)
            title = "Subject-Wise Academic Performance Analysis"

        elif report_type == 'semester':
            cond = []
            params = []
            if course:
                cond.append("s.course = %s")
                params.append(course)
            where_sem = " WHERE " + " AND ".join(cond) if cond else ""

            data = execute_query(f"""
                SELECT 
                    s.course,
                    s.semester,
                    COUNT(DISTINCT s.student_id) AS student_count,
                    COUNT(m.mark_id) AS total_assessments,
                    COALESCE(ROUND(AVG(m.percentage), 2), 0.00) AS avg_score,
                    COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_percentage
                FROM students s
                INNER JOIN marks m ON s.student_id = m.student_id
                {where_sem}
                GROUP BY s.course, s.semester
                ORDER BY s.course, s.semester
            """, params)
            title = "Semester-Wise Academic Summary"

        elif report_type == 'attendance':
            cond = []
            params = []
            if course:
                cond.append("s.course = %s")
                params.append(course)
            if semester:
                cond.append("s.semester = %s")
                params.append(int(semester))
            where_att = " WHERE " + " AND ".join(cond) if cond else ""

            data = execute_query(f"""
                SELECT 
                    s.roll_number,
                    s.full_name,
                    s.course,
                    s.semester,
                    COUNT(a.attendance_id) AS total_classes,
                    SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_count,
                    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_count,
                    SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late_count,
                    COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 2), 0.00) AS attendance_pct,
                    CASE 
                        WHEN (SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100 < 75.00 THEN 'At Risk (<75%)'
                        ELSE 'Satisfactory'
                    END AS standing
                FROM students s
                LEFT JOIN attendance a ON s.student_id = a.student_id
                {where_att}
                GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
                ORDER BY attendance_pct ASC
                LIMIT 100
            """, params)
            title = "Comprehensive Student Attendance Audit"

        elif report_type == 'top_performing':
            cond = []
            params = []
            if course:
                cond.append("s.course = %s")
                params.append(course)
            if semester:
                cond.append("s.semester = %s")
                params.append(int(semester))
            where_top = " WHERE " + " AND ".join(cond) if cond else ""

            data = execute_query(f"""
                SELECT 
                    s.roll_number,
                    s.full_name,
                    s.course,
                    s.semester,
                    COUNT(m.mark_id) AS exams_taken,
                    ROUND(AVG(m.percentage), 2) AS overall_percentage,
                    MAX(m.percentage) AS highest_score,
                    CASE 
                        WHEN AVG(m.percentage) >= 90 THEN 'A+ (Distinction)'
                        WHEN AVG(m.percentage) >= 80 THEN 'A (First Class with Merit)'
                        ELSE 'B (First Class)'
                    END AS honor_division
                FROM students s
                INNER JOIN marks m ON s.student_id = m.student_id
                {where_top}
                GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
                HAVING overall_percentage >= 75.00
                ORDER BY overall_percentage DESC
                LIMIT 25
            """, params)
            title = "Academic Honor Roll - Top Performing Students"

        else:
            report_type = 'overall'
            cond = []
            params = []
            if course:
                cond.append("s.course = %s")
                params.append(course)
            where_o = " WHERE " + " AND ".join(cond) if cond else ""

            kpis = execute_query(f"""
                SELECT 
                    COUNT(DISTINCT s.student_id) AS total_students,
                    COUNT(m.mark_id) AS total_exams,
                    COALESCE(ROUND(AVG(m.obtained_marks), 2), 0.00) AS avg_marks,
                    COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_percentage
                FROM students s
                LEFT JOIN marks m ON s.student_id = m.student_id
                {where_o}
            """, params, fetch='one')

            courses_summary = execute_query(f"""
                SELECT 
                    s.course,
                    COUNT(DISTINCT s.student_id) AS total_enrolled,
                    COALESCE(ROUND(AVG(m.percentage), 2), 0.00) AS avg_percentage,
                    COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 2), 0.00) AS pass_rate
                FROM students s
                LEFT JOIN marks m ON s.student_id = m.student_id
                {where_o}
                GROUP BY s.course
                ORDER BY s.course
            """, params)

            data = {
                'kpis': kpis or {'total_students': 0, 'total_exams': 0, 'avg_marks': 0.00, 'pass_percentage': 0.00},
                'courses': courses_summary
            }
            title = "Overall Institutional Academic Performance Report"

    except Exception as e:
        flash(f"Error compiling report: {e}", 'danger')

    return render_template(
        'reports.html',
        report_type=report_type,
        student_id=student_id,
        subject_id=subject_id,
        session_id=session_id,
        course=course,
        semester=semester,
        students=students,
        subjects=subjects,
        sessions=sessions,
        courses=courses,
        data=data,
        report_title=title,
        now=datetime.now().strftime('%Y-%m-%d %H:%M')
    )

@reports_bp.route('/export/csv')
@login_required
def export_csv():
    report_type = request.args.get('report_type', 'overall')
    course = request.args.get('course', '')
    semester = request.args.get('semester', '')
    student_id = request.args.get('student_id', '')

    si = io.StringIO()
    cw = csv.writer(si)
    filename = f"report_{report_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    if report_type == 'student':
        if not student_id:
            first = execute_query("SELECT student_id FROM students WHERE status = 'Active' ORDER BY roll_number LIMIT 1", fetch='one')
            student_id = str(first['student_id']) if first else '1'

        cw.writerow(['Student ID', 'Roll Number', 'Full Name', 'Course', 'Semester', 'Subject Code', 'Subject Name', 'Credits', 'Exam Type', 'Obtained', 'Max', 'Percentage', 'Grade', 'Status'])
        rows = execute_query("""
            SELECT s.student_id, s.roll_number, s.full_name, s.course, s.semester,
                   sub.subject_code, sub.subject_name, sub.credits, m.exam_type, m.obtained_marks, sub.max_marks, m.percentage, m.grade, m.status
            FROM marks m
            INNER JOIN students s ON m.student_id = s.student_id
            INNER JOIN subjects sub ON m.subject_id = sub.subject_id
            WHERE m.student_id = %s
            ORDER BY sub.subject_code, m.exam_type
        """, (student_id,))
        for r in rows:
            cw.writerow([
                r.get('student_id', student_id),
                r.get('roll_number', ''),
                r.get('full_name', ''),
                r.get('course', ''),
                r.get('semester', ''),
                r.get('subject_code', ''),
                r.get('subject_name', ''),
                r.get('credits', ''),
                r.get('exam_type', ''),
                r.get('obtained_marks', ''),
                r.get('max_marks', ''),
                r.get('percentage', ''),
                r.get('grade', ''),
                r.get('status', '')
            ])

    elif report_type == 'attendance':
        cw.writerow(['Roll Number', 'Full Name', 'Course', 'Semester', 'Total Classes', 'Present', 'Absent', 'Late', 'Attendance %', 'Status'])
        rows = execute_query("""
            SELECT s.roll_number, s.full_name, s.course, s.semester,
                   COUNT(a.attendance_id) AS total,
                   SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS pres,
                   SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS abse,
                   SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS late,
                   ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(a.attendance_id)) * 100, 2) AS pct
            FROM students s
            LEFT JOIN attendance a ON s.student_id = a.student_id
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            ORDER BY pct ASC
        """)
        for r in rows:
            cw.writerow([r['roll_number'], r['full_name'], r['course'], r['semester'], r['total'], r['pres'], r['abse'], r['late'], r['pct'], 'At Risk' if float(r['pct'] or 0) < 75 else 'Good Standing'])

    elif report_type == 'top_performing':
        cw.writerow(['Rank', 'Roll Number', 'Full Name', 'Course', 'Semester', 'Assessments Taken', 'Average Marks %', 'Highest Marks %'])
        rows = execute_query("""
            SELECT s.roll_number, s.full_name, s.course, s.semester,
                   COUNT(m.mark_id) AS exams,
                   ROUND(AVG(m.percentage), 2) AS avg_pct,
                   MAX(m.percentage) AS max_pct
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            ORDER BY avg_pct DESC
            LIMIT 50
        """)
        for idx, r in enumerate(rows, start=1):
            cw.writerow([
                idx,
                r.get('roll_number', ''),
                r.get('full_name', ''),
                r.get('course', ''),
                r.get('semester', ''),
                r.get('exams', r.get('exams_taken', 0)),
                r.get('avg_pct', r.get('overall_percentage', 0)),
                r.get('max_pct', r.get('highest_score', 0))
            ])

    elif report_type == 'subject':
        cw.writerow(['Subject Code', 'Subject Name', 'Course', 'Semester', 'Candidates Assessed', 'Avg Marks', 'Min Marks', 'Max Marks', 'Pass Rate %'])
        rows = execute_query("""
            SELECT sub.subject_code, sub.subject_name, sub.course, sub.semester,
                   COUNT(m.mark_id) AS total_cand,
                   ROUND(AVG(m.obtained_marks), 2) AS avg_m,
                   MIN(m.obtained_marks) AS min_m,
                   MAX(m.obtained_marks) AS max_m,
                   ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / COUNT(m.mark_id)) * 100, 2) AS pass_r
            FROM subjects sub
            LEFT JOIN marks m ON sub.subject_id = m.subject_id
            GROUP BY sub.subject_id, sub.subject_code, sub.subject_name, sub.course, sub.semester
            ORDER BY sub.subject_code
        """)
        for r in rows:
            cw.writerow([
                r.get('subject_code', ''),
                r.get('subject_name', ''),
                r.get('course', ''),
                r.get('semester', ''),
                r.get('total_cand', r.get('total_candidates', 0)),
                r.get('avg_m', r.get('avg_marks', 0)),
                r.get('min_m', r.get('lowest_marks', 0)),
                r.get('max_m', r.get('highest_marks', 0)),
                r.get('pass_r', r.get('pass_rate', 0))
            ])

    elif report_type == 'semester':
        cw.writerow(['Course Program', 'Semester', 'Enrolled Students', 'Total Assessments', 'Average Score %', 'Pass Rate %'])
        rows = execute_query("""
            SELECT s.course, s.semester,
                   COUNT(DISTINCT s.student_id) AS enrolled,
                   COUNT(m.mark_id) AS assessments,
                   ROUND(AVG(m.percentage), 2) AS avg_pct,
                   ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / COUNT(m.mark_id)) * 100, 2) AS pass_pct
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            GROUP BY s.course, s.semester
            ORDER BY s.course, s.semester
        """)
        for r in rows:
            cw.writerow([
                r.get('course', ''),
                r.get('semester', ''),
                r.get('enrolled', r.get('student_count', 0)),
                r.get('assessments', r.get('total_assessments', 0)),
                r.get('avg_pct', r.get('avg_score', 0)),
                r.get('pass_pct', r.get('pass_percentage', 0))
            ])

    else:
        # Overall institutional course performance
        cw.writerow(['Course Program', 'Enrolled Students', 'Average Percentage', 'Passing Rate %'])
        rows = execute_query("""
            SELECT s.course,
                   COUNT(DISTINCT s.student_id) AS enrolled,
                   ROUND(AVG(m.percentage), 2) AS avg_pct,
                   ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / COUNT(m.mark_id)) * 100, 2) AS pass_pct
            FROM students s
            LEFT JOIN marks m ON s.student_id = m.student_id
            GROUP BY s.course
            ORDER BY s.course
        """)
        for r in rows:
            cw.writerow([
                r.get('course', ''),
                r.get('enrolled', r.get('total_enrolled', 0)),
                r.get('avg_pct', r.get('avg_percentage', 0)),
                r.get('pass_pct', r.get('pass_rate', 0))
            ])

    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = f"attachment; filename={filename}"
    output.headers["Content-type"] = "text/csv; charset=utf-8"
    return output

@reports_bp.route('/export/pdf')
@login_required
def export_pdf():
    report_type = request.args.get('report_type', 'overall')
    student_id = request.args.get('student_id', '')
    course = request.args.get('course', '')
    semester = request.args.get('semester', '')

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    styles = getSampleStyleSheet()

    header_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#1e40af'),
        alignment=1,
        spaceAfter=4
    )
    subtitle_style = ParagraphStyle(
        'DocSub',
        parent=styles['Normal'],
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor('#64748b'),
        alignment=1,
        spaceAfter=14
    )
    th_style = ParagraphStyle(
        'TH',
        parent=styles['Normal'],
        fontSize=8.5,
        leading=11,
        textColor=colors.white,
        fontName='Helvetica-Bold'
    )
    td_style = ParagraphStyle(
        'TD',
        parent=styles['Normal'],
        fontSize=8,
        leading=10.5,
        textColor=colors.HexColor('#1e293b')
    )

    elements = []
    elements.append(Paragraph("STUDENT PERFORMANCE ANALYTICS SYSTEM", header_style))
    elements.append(Paragraph(f"Official Institutional Report &bull; Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", subtitle_style))

    table_data = []

    if report_type == 'student':
        if not student_id:
            first = execute_query("SELECT student_id FROM students WHERE status = 'Active' ORDER BY roll_number LIMIT 1", fetch='one')
            student_id = str(first['student_id']) if first else '1'

        student = execute_query("SELECT * FROM students WHERE student_id = %s", (student_id,), fetch='one')
        if student:
            elements.append(Paragraph(f"<b>Student Marksheet: {student['full_name']}</b> | Roll: {student['roll_number']} | Course: {student['course']} (Sem {student['semester']})", styles['Heading3']))
            elements.append(Spacer(1, 8))

            table_data.append([
                Paragraph("Subject Code", th_style),
                Paragraph("Subject Name", th_style),
                Paragraph("Credits", th_style),
                Paragraph("Exam Type", th_style),
                Paragraph("Score", th_style),
                Paragraph("Max", th_style),
                Paragraph("Percentage", th_style),
                Paragraph("Grade", th_style),
                Paragraph("Status", th_style)
            ])
            marks = execute_query("""
                SELECT m.*, sub.subject_code, sub.subject_name, sub.credits, sub.max_marks
                FROM marks m
                INNER JOIN subjects sub ON m.subject_id = sub.subject_id
                WHERE m.student_id = %s
                ORDER BY sub.subject_code, m.exam_type
            """, (student_id,))
            for m in marks:
                table_data.append([
                    Paragraph(m['subject_code'], td_style),
                    Paragraph(m['subject_name'], td_style),
                    Paragraph(str(m['credits']), td_style),
                    Paragraph(m['exam_type'], td_style),
                    Paragraph(str(m['obtained_marks']), td_style),
                    Paragraph(str(m['max_marks']), td_style),
                    Paragraph(f"{m['percentage']}%", td_style),
                    Paragraph(m['grade'], td_style),
                    Paragraph(m['status'], td_style)
                ])

    elif report_type == 'attendance':
        elements.append(Paragraph("<b>Student Attendance Audit</b>", styles['Heading3']))
        elements.append(Spacer(1, 8))
        table_data.append([
            Paragraph("Roll Number", th_style),
            Paragraph("Full Name", th_style),
            Paragraph("Course", th_style),
            Paragraph("Sem", th_style),
            Paragraph("Total Classes", th_style),
            Paragraph("Present", th_style),
            Paragraph("Absent", th_style),
            Paragraph("Attendance %", th_style),
            Paragraph("Standing", th_style)
        ])
        att_rows = execute_query("""
            SELECT s.roll_number, s.full_name, s.course, s.semester,
                   COUNT(a.attendance_id) AS total,
                   SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS pres,
                   SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS abse,
                   ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(a.attendance_id)) * 100, 2) AS pct
            FROM students s
            LEFT JOIN attendance a ON s.student_id = a.student_id
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            ORDER BY pct ASC
            LIMIT 50
        """)
        for r in att_rows:
            table_data.append([
                Paragraph(r['roll_number'], td_style),
                Paragraph(r['full_name'], td_style),
                Paragraph(r['course'], td_style),
                Paragraph(str(r['semester']), td_style),
                Paragraph(str(r['total']), td_style),
                Paragraph(str(r['pres']), td_style),
                Paragraph(str(r['abse']), td_style),
                Paragraph(f"{r['pct']}%", td_style),
                Paragraph('At Risk' if float(r['pct'] or 0) < 75 else 'Satisfactory', td_style)
            ])

    elif report_type == 'semester':
        elements.append(Paragraph("<b>Semester-Wise Academic Summary</b>", styles['Heading3']))
        elements.append(Spacer(1, 8))
        table_data.append([
            Paragraph("Course Program", th_style),
            Paragraph("Semester", th_style),
            Paragraph("Enrolled Students", th_style),
            Paragraph("Total Assessments", th_style),
            Paragraph("Average Score %", th_style),
            Paragraph("Passing Rate %", th_style)
        ])
        sem_rows = execute_query("""
            SELECT s.course, s.semester,
                   COUNT(DISTINCT s.student_id) AS enrolled,
                   COUNT(m.mark_id) AS assessments,
                   ROUND(AVG(m.percentage), 2) AS avg_pct,
                   ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / COUNT(m.mark_id)) * 100, 2) AS pass_pct
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            GROUP BY s.course, s.semester
            ORDER BY s.course, s.semester
        """)
        for r in sem_rows:
            table_data.append([
                Paragraph(r['course'], td_style),
                Paragraph(f"Semester {r['semester']}", td_style),
                Paragraph(str(r['enrolled']), td_style),
                Paragraph(str(r['assessments']), td_style),
                Paragraph(f"{r['avg_pct']}%", td_style),
                Paragraph(f"{r['pass_pct']}%", td_style)
            ])

    elif report_type == 'top_performing':
        elements.append(Paragraph("<b>Top Performing Students (Honor Roll)</b>", styles['Heading3']))
        elements.append(Spacer(1, 8))
        table_data.append([
            Paragraph("Rank", th_style),
            Paragraph("Roll Number", th_style),
            Paragraph("Full Name", th_style),
            Paragraph("Course", th_style),
            Paragraph("Sem", th_style),
            Paragraph("Assessments", th_style),
            Paragraph("Average %", th_style),
            Paragraph("Peak Score %", th_style)
        ])
        top_rows = execute_query("""
            SELECT s.roll_number, s.full_name, s.course, s.semester,
                   COUNT(m.mark_id) AS exams,
                   ROUND(AVG(m.percentage), 2) AS avg_pct,
                   MAX(m.percentage) AS max_pct
            FROM students s
            INNER JOIN marks m ON s.student_id = m.student_id
            GROUP BY s.student_id, s.roll_number, s.full_name, s.course, s.semester
            ORDER BY avg_pct DESC
            LIMIT 30
        """)
        for idx, r in enumerate(top_rows, start=1):
            table_data.append([
                Paragraph(str(idx), td_style),
                Paragraph(str(r.get('roll_number', '')), td_style),
                Paragraph(str(r.get('full_name', '')), td_style),
                Paragraph(str(r.get('course', '')), td_style),
                Paragraph(str(r.get('semester', '')), td_style),
                Paragraph(str(r.get('exams', r.get('exams_taken', ''))), td_style),
                Paragraph(f"{r.get('avg_pct', r.get('overall_percentage', ''))}%", td_style),
                Paragraph(f"{r.get('max_pct', r.get('highest_score', ''))}%", td_style)
            ])

    elif report_type == 'subject':
        elements.append(Paragraph("<b>Subject Performance Analysis</b>", styles['Heading3']))
        elements.append(Spacer(1, 8))
        table_data.append([
            Paragraph("Code", th_style),
            Paragraph("Subject Title", th_style),
            Paragraph("Course", th_style),
            Paragraph("Sem", th_style),
            Paragraph("Candidates", th_style),
            Paragraph("Avg Score", th_style),
            Paragraph("Min Score", th_style),
            Paragraph("Max Score", th_style),
            Paragraph("Pass Rate %", th_style)
        ])
        subj_rows = execute_query("""
            SELECT sub.subject_code, sub.subject_name, sub.course, sub.semester,
                   COUNT(m.mark_id) AS total_cand,
                   ROUND(AVG(m.obtained_marks), 2) AS avg_m,
                   MIN(m.obtained_marks) AS min_m,
                   MAX(m.obtained_marks) AS max_m,
                   ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / COUNT(m.mark_id)) * 100, 2) AS pass_r
            FROM subjects sub
            LEFT JOIN marks m ON sub.subject_id = m.subject_id
            GROUP BY sub.subject_id, sub.subject_code, sub.subject_name, sub.course, sub.semester
            ORDER BY sub.subject_code
        """)
        for r in subj_rows:
            table_data.append([
                Paragraph(r['subject_code'], td_style),
                Paragraph(r['subject_name'], td_style),
                Paragraph(r['course'], td_style),
                Paragraph(str(r['semester']), td_style),
                Paragraph(str(r['total_cand']), td_style),
                Paragraph(str(r['avg_m']), td_style),
                Paragraph(str(r['min_m']), td_style),
                Paragraph(str(r['max_m']), td_style),
                Paragraph(f"{r['pass_r']}%", td_style)
            ])

    else:
        # Overall institutional performance
        elements.append(Paragraph("<b>Overall Institutional Academic Performance</b>", styles['Heading3']))
        elements.append(Spacer(1, 8))
        table_data.append([
            Paragraph("Course Program", th_style),
            Paragraph("Enrolled Students", th_style),
            Paragraph("Average Percentage", th_style),
            Paragraph("Passing Rate %", th_style)
        ])
        courses_rows = execute_query("""
            SELECT s.course,
                   COUNT(DISTINCT s.student_id) AS enrolled,
                   ROUND(AVG(m.percentage), 2) AS avg_pct,
                   ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / COUNT(m.mark_id)) * 100, 2) AS pass_pct
            FROM students s
            LEFT JOIN marks m ON s.student_id = m.student_id
            GROUP BY s.course
            ORDER BY s.course
        """)
        for r in courses_rows:
            table_data.append([
                Paragraph(r['course'], td_style),
                Paragraph(str(r['enrolled']), td_style),
                Paragraph(f"{r['avg_pct']}%", td_style),
                Paragraph(f"{r['pass_pct']}%", td_style)
            ])

    if table_data:
        t = Table(table_data, repeatRows=1)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2563eb')),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
            ('TOPPADDING', (0, 0), (-1, 0), 6),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
            ('TOPPADDING', (0, 1), (-1, -1), 4),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')])
        ]))
        elements.append(t)

    elements.append(Spacer(1, 16))
    elements.append(Paragraph("<i>Official report generated by Student Performance Analytics Platform. Authorized signatory not required.</i>", styles['Italic']))

    doc.build(elements)
    buffer.seek(0)

    filename = f"analytics_report_{report_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    return send_file(
        buffer,
        as_attachment=True,
        download_name=filename,
        mimetype='application/pdf'
    )
