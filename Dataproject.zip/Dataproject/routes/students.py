import math
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from routes import login_required, admin_required
from db import execute_query, log_activity

students_bp = Blueprint('students', __name__, url_prefix='/students')

@students_bp.route('')
@login_required
def index():
    # Filtering, searching, sorting, pagination
    search = request.args.get('search', '').strip()
    course_filter = request.args.get('course', '').strip()
    sem_filter = request.args.get('semester', '').strip()
    sort_by = request.args.get('sort_by', 'roll_number')
    sort_dir = request.args.get('sort_dir', 'ASC').upper()
    page = int(request.args.get('page', 1))
    per_page = 15

    # Validate sort parameters
    valid_sort_cols = {
        'student_id': 's.student_id',
        'roll_number': 's.roll_number',
        'full_name': 's.full_name',
        'course': 's.course',
        'semester': 's.semester',
        'enrollment_date': 's.enrollment_date',
        'status': 's.status'
    }
    sort_column = valid_sort_cols.get(sort_by, 's.roll_number')
    if sort_dir not in ['ASC', 'DESC']:
        sort_dir = 'ASC'

    conditions = []
    params = []

    if search:
        conditions.append("(s.full_name LIKE %s OR s.roll_number LIKE %s OR s.email LIKE %s)")
        term = f"%{search}%"
        params.extend([term, term, term])

    if course_filter:
        conditions.append("s.course = %s")
        params.append(course_filter)

    if sem_filter:
        conditions.append("s.semester = %s")
        params.append(int(sem_filter))

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    # Count total matching
    count_query = f"SELECT COUNT(*) AS total FROM students s {where_clause}"
    count_res = execute_query(count_query, params, fetch='one')
    total_records = count_res['total'] if count_res else 0
    total_pages = max(1, math.ceil(total_records / per_page))
    page = max(1, min(page, total_pages))
    offset = (page - 1) * per_page

    # Query records with overall avg marks & attendance rate
    data_query = f"""
        SELECT 
            s.student_id,
            s.roll_number,
            s.full_name,
            s.email,
            s.phone,
            s.gender,
            s.course,
            s.semester,
            s.enrollment_date,
            s.status,
            COALESCE(ROUND(AVG(m.percentage), 1), 0) AS avg_marks,
            COALESCE(ROUND((SUM(CASE WHEN a.status IN ('Present', 'Late') THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id), 0)) * 100, 1), 0) AS attendance_pct
        FROM students s
        LEFT JOIN marks m ON s.student_id = m.student_id
        LEFT JOIN attendance a ON s.student_id = a.student_id
        {where_clause}
        GROUP BY s.student_id, s.roll_number, s.full_name, s.email, s.phone, s.gender, s.course, s.semester, s.enrollment_date, s.status
        ORDER BY {sort_column} {sort_dir}
        LIMIT %s OFFSET %s
    """
    query_params = list(params) + [per_page, offset]
    students = execute_query(data_query, query_params)

    # Distinct courses for filter dropdown
    courses = execute_query("SELECT DISTINCT course FROM students ORDER BY course")

    return render_template(
        'students.html',
        students=students,
        courses=courses,
        search=search,
        course_filter=course_filter,
        sem_filter=sem_filter,
        sort_by=sort_by,
        sort_dir=sort_dir,
        page=page,
        total_pages=total_pages,
        total_records=total_records
    )

@students_bp.route('/add', methods=['POST'])
@login_required
def add():
    roll_number = request.form.get('roll_number', '').strip().upper()
    full_name = request.form.get('full_name', '').strip()
    email = request.form.get('email', '').strip().lower()
    phone = request.form.get('phone', '').strip()
    gender = request.form.get('gender', 'Male')
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester', '1')
    enrollment_date = request.form.get('enrollment_date', '')

    if not roll_number or not full_name or not email or not course:
        flash('Please fill in all mandatory fields.', 'danger')
        return redirect(url_for('students.index'))

    try:
        # Check uniqueness
        existing = execute_query(
            "SELECT student_id FROM students WHERE roll_number = %s OR email = %s",
            (roll_number, email),
            fetch='one'
        )
        if existing:
            flash(f"A student with Roll Number '{roll_number}' or Email '{email}' already exists.", 'warning')
            return redirect(url_for('students.index'))

        insert_query = """
            INSERT INTO students (roll_number, full_name, email, phone, gender, course, semester, enrollment_date, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'Active')
        """
        res = execute_query(
            insert_query,
            (roll_number, full_name, email, phone, gender, course, int(semester), enrollment_date),
            commit=True
        )
        new_id = res['last_insert_id']
        log_activity(session.get('user_id'), 'Add Student', 'Students', new_id, f"Added student {full_name} ({roll_number})", request.remote_addr)
        flash(f"Student '{full_name}' ({roll_number}) registered successfully!", 'success')
    except Exception as e:
        flash(f"Error adding student: {e}", 'danger')

    return redirect(url_for('students.index'))

@students_bp.route('/edit/<int:student_id>', methods=['POST'])
@login_required
def edit(student_id):
    full_name = request.form.get('full_name', '').strip()
    email = request.form.get('email', '').strip().lower()
    phone = request.form.get('phone', '').strip()
    gender = request.form.get('gender', 'Male')
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester', '1')
    enrollment_date = request.form.get('enrollment_date', '')
    status = request.form.get('status', 'Active')

    try:
        update_query = """
            UPDATE students
            SET full_name = %s, email = %s, phone = %s, gender = %s, course = %s,
                semester = %s, enrollment_date = %s, status = %s
            WHERE student_id = %s
        """
        execute_query(
            update_query,
            (full_name, email, phone, gender, course, int(semester), enrollment_date, status, student_id),
            commit=True
        )
        log_activity(session.get('user_id'), 'Edit Student', 'Students', student_id, f"Updated profile for student ID {student_id}", request.remote_addr)
        flash(f"Student details updated successfully.", 'success')
    except Exception as e:
        flash(f"Error updating student: {e}", 'danger')

    return redirect(url_for('students.index'))

@students_bp.route('/delete/<int:student_id>', methods=['POST'])
@admin_required
def delete(student_id):
    try:
        student = execute_query("SELECT full_name, roll_number FROM students WHERE student_id = %s", (student_id,), fetch='one')
        if not student:
            flash("Student record not found.", 'danger')
            return redirect(url_for('students.index'))

        execute_query("DELETE FROM students WHERE student_id = %s", (student_id,), commit=True)
        log_activity(session.get('user_id'), 'Delete Student', 'Students', student_id, f"Deleted student {student['full_name']} ({student['roll_number']})", request.remote_addr)
        flash(f"Student record for '{student['full_name']}' deleted.", 'info')
    except Exception as e:
        flash(f"Error deleting student: {e}", 'danger')

    return redirect(url_for('students.index'))

@students_bp.route('/view/<int:student_id>')
@login_required
def view_details(student_id):
    try:
        student = execute_query("SELECT * FROM students WHERE student_id = %s", (student_id,), fetch='one')
        if not student:
            return jsonify({'success': False, 'error': 'Student not found'}), 404

        marks = execute_query("""
            SELECT m.*, sub.subject_code, sub.subject_name, sub.max_marks, sub.passing_marks, sess.session_name
            FROM marks m
            INNER JOIN subjects sub ON m.subject_id = sub.subject_id
            INNER JOIN academic_sessions sess ON m.session_id = sess.session_id
            WHERE m.student_id = %s
            ORDER BY sub.subject_code, m.exam_type
        """, (student_id,))

        attendance = execute_query("""
            SELECT 
                COUNT(*) AS total_classes,
                SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) AS attended,
                ROUND((SUM(CASE WHEN status IN ('Present', 'Late') THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS percentage
            FROM attendance
            WHERE student_id = %s
        """, (student_id,), fetch='one')

        return jsonify({
            'success': True,
            'student': student,
            'marks': marks,
            'attendance': attendance
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
