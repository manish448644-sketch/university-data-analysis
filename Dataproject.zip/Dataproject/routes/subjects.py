from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from routes import login_required, admin_required
from db import execute_query, log_activity

subjects_bp = Blueprint('subjects', __name__, url_prefix='/subjects')

@subjects_bp.route('')
@login_required
def index():
    search = request.args.get('search', '').strip()
    course_filter = request.args.get('course', '').strip()

    conditions = []
    params = []

    if search:
        conditions.append("(subject_code LIKE %s OR subject_name LIKE %s)")
        term = f"%{search}%"
        params.extend([term, term])

    if course_filter:
        conditions.append("course = %s")
        params.append(course_filter)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""

    query = f"""
        SELECT 
            sub.*,
            COUNT(DISTINCT m.mark_id) AS total_assessments,
            COALESCE(ROUND(AVG(m.obtained_marks), 1), 0.0) AS avg_marks,
            COALESCE(ROUND((SUM(CASE WHEN m.status = 'Pass' THEN 1 ELSE 0 END) / NULLIF(COUNT(m.mark_id), 0)) * 100, 1), 0.0) AS pass_rate
        FROM subjects sub
        LEFT JOIN marks m ON sub.subject_id = m.subject_id
        {where_clause}
        GROUP BY sub.subject_id, sub.subject_code, sub.subject_name, sub.course, sub.semester, sub.max_marks, sub.passing_marks, sub.credits, sub.created_at
        ORDER BY sub.course, sub.semester, sub.subject_code
    """
    subjects = execute_query(query, params)
    courses = execute_query("SELECT DISTINCT course FROM subjects ORDER BY course")

    return render_template(
        'subjects.html',
        subjects=subjects,
        courses=courses,
        search=search,
        course_filter=course_filter
    )

@subjects_bp.route('/add', methods=['POST'])
@admin_required
def add():
    subject_code = request.form.get('subject_code', '').strip().upper()
    subject_name = request.form.get('subject_name', '').strip()
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester', '1')
    max_marks = request.form.get('max_marks', '100.00')
    passing_marks = request.form.get('passing_marks', '50.00')
    credits = request.form.get('credits', '4')

    if not subject_code or not subject_name or not course:
        flash('Subject code, name, and course are required.', 'danger')
        return redirect(url_for('subjects.index'))

    try:
        existing = execute_query("SELECT subject_id FROM subjects WHERE subject_code = %s", (subject_code,), fetch='one')
        if existing:
            flash(f"Subject code '{subject_code}' already exists.", 'warning')
            return redirect(url_for('subjects.index'))

        insert_query = """
            INSERT INTO subjects (subject_code, subject_name, course, semester, max_marks, passing_marks, credits)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        res = execute_query(
            insert_query,
            (subject_code, subject_name, course, int(semester), float(max_marks), float(passing_marks), int(credits)),
            commit=True
        )
        log_activity(session.get('user_id'), 'Add Subject', 'Subjects', res['last_insert_id'], f"Added subject {subject_code} - {subject_name}", request.remote_addr)
        flash(f"Subject '{subject_code}' added successfully!", 'success')
    except Exception as e:
        flash(f"Error adding subject: {e}", 'danger')

    return redirect(url_for('subjects.index'))

@subjects_bp.route('/edit/<int:subject_id>', methods=['POST'])
@admin_required
def edit(subject_id):
    subject_code = request.form.get('subject_code', '').strip().upper()
    subject_name = request.form.get('subject_name', '').strip()
    course = request.form.get('course', '').strip()
    semester = request.form.get('semester', '1')
    max_marks = request.form.get('max_marks', '100.00')
    passing_marks = request.form.get('passing_marks', '50.00')
    credits = request.form.get('credits', '4')

    try:
        update_query = """
            UPDATE subjects
            SET subject_code = %s, subject_name = %s, course = %s, semester = %s,
                max_marks = %s, passing_marks = %s, credits = %s
            WHERE subject_id = %s
        """
        execute_query(
            update_query,
            (subject_code, subject_name, course, int(semester), float(max_marks), float(passing_marks), int(credits), subject_id),
            commit=True
        )
        log_activity(session.get('user_id'), 'Edit Subject', 'Subjects', subject_id, f"Updated subject {subject_code}", request.remote_addr)
        flash("Subject updated successfully.", 'success')
    except Exception as e:
        flash(f"Error updating subject: {e}", 'danger')

    return redirect(url_for('subjects.index'))

@subjects_bp.route('/delete/<int:subject_id>', methods=['POST'])
@admin_required
def delete(subject_id):
    try:
        sub = execute_query("SELECT subject_code, subject_name FROM subjects WHERE subject_id = %s", (subject_id,), fetch='one')
        if not sub:
            flash("Subject not found.", 'danger')
            return redirect(url_for('subjects.index'))

        execute_query("DELETE FROM subjects WHERE subject_id = %s", (subject_id,), commit=True)
        log_activity(session.get('user_id'), 'Delete Subject', 'Subjects', subject_id, f"Deleted subject {sub['subject_code']}", request.remote_addr)
        flash(f"Subject '{sub['subject_code']}' deleted successfully.", 'info')
    except Exception as e:
        flash(f"Error deleting subject: {e}", 'danger')

    return redirect(url_for('subjects.index'))
