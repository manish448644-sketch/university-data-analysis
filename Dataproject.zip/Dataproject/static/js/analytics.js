/**
 * Performance Analytics Controller
 * Handles charts, correlation plots, and detailed breakdowns for the analytics module
 */

document.addEventListener('DOMContentLoaded', function () {
    let gradeChart = null;
    let courseChart = null;
    let semesterChart = null;
    let attCorrChart = null;

    const sessionFilter = document.getElementById('analyticsSession');
    const courseFilter = document.getElementById('analyticsCourse');
    const semFilter = document.getElementById('analyticsSemester');

    function loadAnalyticsData() {
        const params = new URLSearchParams();
        if (sessionFilter && sessionFilter.value) params.append('session_id', sessionFilter.value);
        if (courseFilter && courseFilter.value) params.append('course', courseFilter.value);
        if (semFilter && semFilter.value) params.append('semester', semFilter.value);

        fetch(`/analytics/api/data?${params.toString()}`)
            .then(res => res.json())
            .then(res => {
                if (!res.success) {
                    console.error("Analytics API failed:", res.error);
                    return;
                }

                // 1. Grade Distribution Chart
                const ctxGrade = document.getElementById('chartGradeDistribution');
                if (ctxGrade && res.grade_distribution) {
                    if (gradeChart) gradeChart.destroy();
                    const gLabels = res.grade_distribution.map(g => `Grade ${g.grade}`);
                    const gCounts = res.grade_distribution.map(g => g.count);
                    const gColors = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#fb923c', '#ef4444'];

                    gradeChart = new Chart(ctxGrade, {
                        type: 'pie',
                        data: {
                            labels: gLabels,
                            datasets: [{
                                data: gCounts,
                                backgroundColor: gColors,
                                borderWidth: 2,
                                borderColor: '#ffffff'
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: { position: 'bottom', labels: { boxWidth: 12, padding: 8 } }
                            }
                        }
                    });
                }

                // 2. Course-wise Performance Chart
                const ctxCourse = document.getElementById('chartCoursePerformance');
                if (ctxCourse && res.course_performance) {
                    if (courseChart) courseChart.destroy();
                    courseChart = new Chart(ctxCourse, {
                        type: 'bar',
                        data: {
                            labels: res.course_performance.map(c => c.course),
                            datasets: [
                                {
                                    label: 'Avg Marks %',
                                    data: res.course_performance.map(c => c.avg_course_percentage),
                                    backgroundColor: '#3b82f6',
                                    borderRadius: 6
                                },
                                {
                                    label: 'Pass Rate %',
                                    data: res.course_performance.map(c => c.course_pass_rate),
                                    backgroundColor: '#10b981',
                                    borderRadius: 6
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: { beginAtZero: true, max: 100, grid: { color: '#f1f5f9' } },
                                x: { grid: { display: false } }
                            }
                        }
                    });
                }

                // 3. Semester-wise Performance Chart
                const ctxSem = document.getElementById('chartSemesterPerformance');
                if (ctxSem && res.semester_performance) {
                    if (semesterChart) semesterChart.destroy();
                    semesterChart = new Chart(ctxSem, {
                        type: 'line',
                        data: {
                            labels: res.semester_performance.map(s => `Semester ${s.semester}`),
                            datasets: [{
                                label: 'Average Score %',
                                data: res.semester_performance.map(s => s.avg_sem_percentage),
                                borderColor: '#7c3aed',
                                backgroundColor: 'rgba(124, 58, 237, 0.15)',
                                fill: true,
                                tension: 0.3,
                                pointRadius: 5
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: { beginAtZero: false, min: 40, max: 100, grid: { color: '#f1f5f9' } },
                                x: { grid: { display: false } }
                            }
                        }
                    });
                }

                // 4. Attendance vs Marks Correlation Chart
                const ctxCorr = document.getElementById('chartAttendanceCorrelation');
                if (ctxCorr && res.attendance_correlation) {
                    if (attCorrChart) attCorrChart.destroy();
                    const scatterPoints = res.attendance_correlation.map(s => ({
                        x: parseFloat(s.attendance_percentage),
                        y: parseFloat(s.academic_percentage),
                        name: `${s.roll_number} - ${s.full_name}`
                    }));

                    attCorrChart = new Chart(ctxCorr, {
                        type: 'scatter',
                        data: {
                            datasets: [{
                                label: 'Students',
                                data: scatterPoints,
                                backgroundColor: 'rgba(37, 99, 235, 0.7)',
                                borderColor: '#1d4ed8',
                                pointRadius: 6,
                                pointHoverRadius: 8
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                x: {
                                    title: { display: true, text: 'Attendance Rate (%)' },
                                    min: 30,
                                    max: 100,
                                    grid: { color: '#f1f5f9' }
                                },
                                y: {
                                    title: { display: true, text: 'Academic Marks (%)' },
                                    min: 20,
                                    max: 100,
                                    grid: { color: '#f1f5f9' }
                                }
                            },
                            plugins: {
                                tooltip: {
                                    callbacks: {
                                        label: function (ctx) {
                                            const p = ctx.raw;
                                            return `${p.name}: Att: ${p.x}%, Marks: ${p.y}%`;
                                        }
                                    }
                                }
                            }
                        }
                    });
                }

                // Populate Improvement Needed Table
                const tbodyRisk = document.getElementById('tbodyImprovement');
                if (tbodyRisk) {
                    if (res.improvement_needed && res.improvement_needed.length > 0) {
                        tbodyRisk.innerHTML = res.improvement_needed.map((item, idx) => `
                            <tr>
                                <td><span class="fw-semibold">${item.roll_number}</span></td>
                                <td>${item.full_name}</td>
                                <td>${item.course} - Sem ${item.semester}</td>
                                <td><span class="badge ${item.academic_score >= 50 ? 'bg-success' : 'bg-danger'}">${item.academic_score}%</span></td>
                                <td><span class="badge ${item.attendance_rate >= 75 ? 'bg-success' : 'bg-danger'}">${item.attendance_rate}%</span></td>
                                <td><span class="badge bg-danger text-light">${item.reason_flag}</span></td>
                            </tr>
                        `).join('');
                    } else {
                        tbodyRisk.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-muted"><i class="bi bi-shield-check text-success me-2 fs-5 align-middle"></i>No students identified in at-risk or low-attendance category for this selection.</td></tr>';
                    }
                }

                // Populate Highest & Lowest Scoring Tables
                const tbodyHigh = document.getElementById('tbodyHighest');
                if (tbodyHigh) {
                    if (res.highest_scoring && res.highest_scoring.length > 0) {
                        tbodyHigh.innerHTML = res.highest_scoring.slice(0, 5).map((item, idx) => `
                            <tr>
                                <td><span class="badge bg-primary rounded-circle p-2">${idx + 1}</span></td>
                                <td><strong>${item.roll_number}</strong></td>
                                <td>${item.full_name}</td>
                                <td>${item.course}</td>
                                <td><span class="badge bg-success">${item.overall_percentage}%</span></td>
                            </tr>
                        `).join('');
                    } else {
                        tbodyHigh.innerHTML = '<tr><td colspan="5" class="text-center py-3 text-muted">No assessment records found for this filter.</td></tr>';
                    }
                }

                const tbodyLow = document.getElementById('tbodyLowest');
                if (tbodyLow) {
                    if (res.lowest_scoring && res.lowest_scoring.length > 0) {
                        tbodyLow.innerHTML = res.lowest_scoring.slice(0, 5).map((item, idx) => `
                            <tr>
                                <td><span class="badge bg-secondary rounded-circle p-2">${idx + 1}</span></td>
                                <td><strong>${item.roll_number}</strong></td>
                                <td>${item.full_name}</td>
                                <td>${item.course}</td>
                                <td><span class="badge bg-danger">${item.overall_percentage}%</span></td>
                            </tr>
                        `).join('');
                    } else {
                        tbodyLow.innerHTML = '<tr><td colspan="5" class="text-center py-3 text-muted">No assessment records found for this filter.</td></tr>';
                    }
                }
            })
            .catch(err => {
                console.error("Failed to load analytics:", err);
            });
    }

    [sessionFilter, courseFilter, semFilter].forEach(el => {
        if (el) el.addEventListener('change', loadAnalyticsData);
    });

    loadAnalyticsData();
});
