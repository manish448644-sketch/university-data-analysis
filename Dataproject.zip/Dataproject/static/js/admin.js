/**
 * University Administration & Academic Monitoring Portal
 * Admin ERP Core JavaScript Engine
 */

document.addEventListener('DOMContentLoaded', function () {
    initThemeManager();
    initSidebarToggle();
    initNotificationHandlers();
    initAdminDashboardCharts();
    initModalDynamicLoaders();
});

/* ==============================================================================
   1. THEME MANAGEMENT (LIGHT / DARK THEME)
   ============================================================================== */
function initThemeManager() {
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const themeIcon = document.getElementById('themeIcon');
    const htmlElement = document.documentElement;

    // Check saved theme or system preference
    const savedTheme = localStorage.getItem('university_erp_theme') || 'light';
    applyTheme(savedTheme);

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function () {
            const currentTheme = htmlElement.getAttribute('data-bs-theme') || 'light';
            const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
            applyTheme(nextTheme);
            localStorage.setItem('university_erp_theme', nextTheme);
            
            // Trigger chart redraw to update theme grid colors
            window.dispatchEvent(new Event('themeChanged'));
        });
    }

    function applyTheme(theme) {
        htmlElement.setAttribute('data-bs-theme', theme);
        if (themeIcon) {
            if (theme === 'dark') {
                themeIcon.className = 'bi bi-sun-fill text-warning';
            } else {
                themeIcon.className = 'bi bi-moon-stars-fill text-primary';
            }
        }
    }
}

/* ==============================================================================
   2. MOBILE SIDEBAR TOGGLE
   ============================================================================== */
function initSidebarToggle() {
    const sidebarToggleBtn = document.getElementById('adminSidebarToggle');
    const sidebar = document.getElementById('adminSidebar');

    if (sidebarToggleBtn && sidebar) {
        sidebarToggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('show');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function (e) {
            if (window.innerWidth < 992 && sidebar.classList.contains('show')) {
                if (!sidebar.contains(e.target) && !sidebarToggleBtn.contains(e.target)) {
                    sidebar.classList.remove('show');
                }
            }
        });
    }
}

/* ==============================================================================
   3. NOTIFICATIONS SYSTEM
   ============================================================================== */
function initNotificationHandlers() {
    document.querySelectorAll('.mark-notif-read-btn').forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            const notifId = this.getAttribute('data-notif-id');
            const notifItem = document.getElementById(`notif-item-${notifId}`);

            fetch(`/admin/notifications/mark-read/${notifId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (notifItem) {
                        notifItem.classList.remove('bg-primary-subtle');
                        notifItem.style.opacity = '0.7';
                        this.remove();
                    }
                    const badge = document.getElementById('topbarNotifBadge');
                    if (badge) {
                        let cur = parseInt(badge.textContent) || 0;
                        if (cur > 1) {
                            badge.textContent = cur - 1;
                        } else {
                            badge.remove();
                        }
                    }
                }
            })
            .catch(err => console.error('Error marking notification read:', err));
        });
    });
}

/* ==============================================================================
   4. ADMIN DASHBOARD & ANALYTICS CHARTS (CHART.JS)
   ============================================================================== */
let chartInstances = {};

function initAdminDashboardCharts() {
    const courseChartEl = document.getElementById('adminCourseChart');
    const gradeChartEl = document.getElementById('adminGradeChart');
    const subjectChartEl = document.getElementById('adminSubjectChart');
    const attChartEl = document.getElementById('adminAttChart');

    if (!courseChartEl && !gradeChartEl && !subjectChartEl && !attChartEl) {
        return; // Not on dashboard
    }

    fetch('/admin/api/dashboard-charts')
        .then(res => res.json())
        .then(data => {
            if (!data.success) return;

            renderCharts(data);
        })
        .catch(err => console.error('Dashboard charts error:', err));

    window.addEventListener('themeChanged', function () {
        // Redraw charts with new contrast colors
        Object.values(chartInstances).forEach(c => c.destroy());
        chartInstances = {};
        initAdminDashboardCharts();
    });
}

function renderCharts(data) {
    const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    const textColor = isDark ? '#cbd5e1' : '#475569';
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.06)';

    // 1. Course Performance Chart
    const courseCtx = document.getElementById('adminCourseChart');
    if (courseCtx && data.courses) {
        const labels = data.courses.map(c => c.course);
        const scores = data.courses.map(c => c.avg_score);
        const passRates = data.courses.map(c => c.pass_rate);

        chartInstances['courses'] = new Chart(courseCtx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Average Score (%)',
                        data: scores,
                        backgroundColor: '#2563eb',
                        borderRadius: 6
                    },
                    {
                        label: 'Pass Percentage (%)',
                        data: passRates,
                        backgroundColor: '#10b981',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: textColor } }
                },
                scales: {
                    x: { ticks: { color: textColor }, grid: { display: false } },
                    y: { ticks: { color: textColor }, grid: { color: gridColor }, min: 0, max: 100 }
                }
            }
        });
    }

    // 2. Grade Distribution Chart (Doughnut)
    const gradeCtx = document.getElementById('adminGradeChart');
    if (gradeCtx && data.grades) {
        const gradeLabels = data.grades.map(g => `Grade ${g.grade}`);
        const gradeCounts = data.grades.map(g => g.count);
        const gradeColors = ['#10b981', '#3b82f6', '#6366f1', '#f59e0b', '#f97316', '#ef4444'];

        chartInstances['grades'] = new Chart(gradeCtx, {
            type: 'doughnut',
            data: {
                labels: gradeLabels,
                datasets: [{
                    data: gradeCounts,
                    backgroundColor: gradeColors,
                    borderWidth: 2,
                    borderColor: isDark ? '#111827' : '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: textColor, boxWidth: 12 } }
                },
                cutout: '68%'
            }
        });
    }

    // 3. Subject-wise Average Scores (Horizontal Bar)
    const subCtx = document.getElementById('adminSubjectChart');
    if (subCtx && data.subjects) {
        chartInstances['subjects'] = new Chart(subCtx, {
            type: 'bar',
            data: {
                labels: data.subjects.map(s => s.subject_code),
                datasets: [{
                    label: 'Subject Average Marks',
                    data: data.subjects.map(s => s.avg_score),
                    backgroundColor: '#0284c7',
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: { ticks: { color: textColor }, grid: { color: gridColor }, min: 0, max: 100 },
                    y: { ticks: { color: textColor }, grid: { display: false } }
                }
            }
        });
    }

    // 4. Attendance Breakdown (Doughnut)
    const attCtx = document.getElementById('adminAttChart');
    if (attCtx && data.attendance) {
        chartInstances['attendance'] = new Chart(attCtx, {
            type: 'pie',
            data: {
                labels: data.attendance.map(a => a.status),
                datasets: [{
                    data: data.attendance.map(a => a.count),
                    backgroundColor: ['#10b981', '#ef4444', '#f59e0b', '#38bdf8'],
                    borderWidth: 2,
                    borderColor: isDark ? '#111827' : '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: textColor, boxWidth: 12 } }
                }
            }
        });
    }
}

/* ==============================================================================
   5. DYNAMIC MODAL LOADERS (AJAX PROFILES & WORKLOADS)
   ============================================================================== */
function initModalDynamicLoaders() {
    // 5.1 Student Profile Modal
    document.querySelectorAll('.view-student-profile-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const sid = this.getAttribute('data-student-id');
            const targetContainer = document.getElementById('studentProfileModalContent');
            if (!targetContainer) return;

            targetContainer.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><div class="mt-2 text-muted small">Loading academic transcript...</div></div>';

            fetch(`/admin/students/profile/${sid}`)
                .then(res => res.json())
                .then(d => {
                    if (!d.success) {
                        targetContainer.innerHTML = `<div class="alert alert-danger">${d.error || 'Failed to load profile.'}</div>`;
                        return;
                    }

                    const st = d.student;
                    const att = d.attendance;
                    let marksRows = '';
                    d.marks.forEach(m => {
                        const badgeClass = m.status === 'Pass' ? 'badge-active' : 'badge-inactive';
                        marksRows += `<tr>
                            <td><strong>${m.subject_code}</strong> - ${m.subject_name}</td>
                            <td>${m.exam_type}</td>
                            <td>${m.obtained_marks} / ${m.max_marks}</td>
                            <td>${m.percentage}%</td>
                            <td><span class="badge ${m.grade === 'F' ? 'bg-danger' : 'bg-primary'}">${m.grade}</span></td>
                            <td><span class="erp-badge ${badgeClass}">${m.status}</span></td>
                        </tr>`;
                    });

                    targetContainer.innerHTML = `
                        <div class="d-flex align-items-center justify-content-between p-3 rounded bg-body-tertiary mb-3 border">
                            <div>
                                <h5 class="fw-bold mb-1">${st.full_name}</h5>
                                <div class="text-muted small">Roll No: <strong>${st.roll_number}</strong> | Email: ${st.email}</div>
                                <div class="text-muted small">Course: <strong>${st.course}</strong> | Semester: ${st.semester} | Section: ${st.section_name || 'Unassigned'}</div>
                            </div>
                            <div class="text-end">
                                <span class="badge ${st.status === 'Active' ? 'bg-success' : 'bg-secondary'} mb-1">${st.status}</span>
                                <div class="small fw-semibold text-primary">Attendance: ${att.attendance_pct}%</div>
                            </div>
                        </div>

                        <h6 class="fw-bold mb-2">Examination & Assessment Records</h6>
                        <div class="table-responsive border rounded mb-3">
                            <table class="table table-sm erp-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th>Exam</th>
                                        <th>Marks</th>
                                        <th>%</th>
                                        <th>Grade</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${marksRows || '<tr><td colspan="6" class="text-center py-3 text-muted">No marks recorded yet.</td></tr>'}
                                </tbody>
                            </table>
                        </div>
                    `;
                })
                .catch(err => {
                    targetContainer.innerHTML = `<div class="alert alert-danger">Error: ${err.message}</div>`;
                });
        });
    });

    // 5.2 Teacher Workload Modal
    document.querySelectorAll('.view-teacher-workload-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const tid = this.getAttribute('data-teacher-id');
            const targetContainer = document.getElementById('teacherWorkloadModalContent');
            if (!targetContainer) return;

            targetContainer.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><div class="mt-2 text-muted small">Retrieving faculty workload details...</div></div>';

            fetch(`/admin/teachers/workload/${tid}`)
                .then(res => res.json())
                .then(d => {
                    if (!d.success) {
                        targetContainer.innerHTML = `<div class="alert alert-danger">${d.error || 'Failed to load workload.'}</div>`;
                        return;
                    }

                    const t = d.teacher;
                    const sum = d.summary;
                    let allocRows = '';
                    d.allocations.forEach(a => {
                        allocRows += `<tr>
                            <td><strong>${a.subject_code}</strong></td>
                            <td>${a.subject_name}</td>
                            <td>${a.course_code} - Sem ${a.semester}</td>
                            <td><span class="badge bg-primary">${a.section_name || 'All'}</span></td>
                            <td>${a.credits} Credits</td>
                        </tr>`;
                    });

                    targetContainer.innerHTML = `
                        <div class="d-flex align-items-center justify-content-between p-3 rounded bg-body-tertiary mb-3 border">
                            <div>
                                <h5 class="fw-bold mb-1">${t.full_name}</h5>
                                <div class="text-muted small">${t.designation || 'Faculty'} | ${t.department_name || 'General Dept'}</div>
                                <div class="text-muted small">Email: ${t.email} | Phone: ${t.phone || 'N/A'}</div>
                            </div>
                            <div class="text-end">
                                <span class="badge ${t.status === 'active' ? 'bg-success' : 'bg-danger'}">${t.status.toUpperCase()}</span>
                            </div>
                        </div>

                        <div class="row g-2 mb-3 text-center">
                            <div class="col-4">
                                <div class="p-2 border rounded bg-body">
                                    <div class="fs-5 fw-bold text-primary">${sum.total_attendance_sessions}</div>
                                    <div class="small text-muted">Attendance Batches</div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="p-2 border rounded bg-body">
                                    <div class="fs-5 fw-bold text-success">${sum.total_marks_entered}</div>
                                    <div class="small text-muted">Marks Entered</div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="p-2 border rounded bg-body">
                                    <div class="fs-5 fw-bold text-indigo">${sum.total_assignments_created}</div>
                                    <div class="small text-muted">Assignments Published</div>
                                </div>
                            </div>
                        </div>

                        <h6 class="fw-bold mb-2">Assigned Courses, Subjects & Sections</h6>
                        <div class="table-responsive border rounded mb-3">
                            <table class="table table-sm erp-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Subject</th>
                                        <th>Program</th>
                                        <th>Section</th>
                                        <th>Credits</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${allocRows || '<tr><td colspan="5" class="text-center py-3 text-muted">No active course allocations assigned yet.</td></tr>'}
                                </tbody>
                            </table>
                        </div>
                    `;
                })
                .catch(err => {
                    targetContainer.innerHTML = `<div class="alert alert-danger">Error: ${err.message}</div>`;
                });
        });
    });

    // 5.3 Assignment Submissions Modal
    document.querySelectorAll('.view-assignment-submissions-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const asgnId = this.getAttribute('data-assignment-id');
            const targetContainer = document.getElementById('assignmentSubmissionsModalContent');
            if (!targetContainer) return;

            targetContainer.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary" role="status"></div></div>';

            fetch(`/admin/monitoring/assignments/${asgnId}/submissions`)
                .then(res => res.json())
                .then(d => {
                    if (!d.success) {
                        targetContainer.innerHTML = `<div class="alert alert-danger">${d.error || 'Failed to load submissions.'}</div>`;
                        return;
                    }

                    const asgn = d.assignment;
                    let subRows = '';
                    d.submissions.forEach(s => {
                        subRows += `<tr>
                            <td><strong>${s.roll_number}</strong></td>
                            <td>${s.student_name}</td>
                            <td>${s.section_name || '-'}</td>
                            <td>${s.submission_date ? s.submission_date.substring(0, 16) : '-'}</td>
                            <td><strong>${s.obtained_marks !== null ? s.obtained_marks : '-'}</strong> / ${asgn.max_marks}</td>
                            <td><span class="badge ${s.status === 'Graded' ? 'bg-success' : 'bg-info'}">${s.status}</span></td>
                            <td>${s.remarks || '-'}</td>
                        </tr>`;
                    });

                    targetContainer.innerHTML = `
                        <div class="mb-3">
                            <h5 class="fw-bold mb-1">${asgn.title}</h5>
                            <div class="text-muted small">${asgn.subject_code} - ${asgn.subject_name} | Faculty: <strong>${asgn.teacher_name}</strong></div>
                            <div class="text-muted small">Due Date: ${asgn.due_date} | Max Marks: ${asgn.max_marks}</div>
                        </div>
                        <div class="table-responsive border rounded">
                            <table class="table table-sm erp-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Roll No</th>
                                        <th>Student</th>
                                        <th>Section</th>
                                        <th>Submitted On</th>
                                        <th>Score</th>
                                        <th>Status</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${subRows || '<tr><td colspan="7" class="text-center py-3 text-muted">No student submissions recorded for this assignment yet.</td></tr>'}
                                </tbody>
                            </table>
                        </div>
                    `;
                })
                .catch(err => {
                    targetContainer.innerHTML = `<div class="alert alert-danger">Error: ${err.message}</div>`;
                });
        });
    });
}
