/**
 * Reusable Chart.js Global Configurations and Theming
 */

if (typeof Chart !== 'undefined') {
    // Set default fonts and styling to match the clean light theme
    Chart.defaults.font.family = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    Chart.defaults.font.size = 12;
    Chart.defaults.color = '#64748b';
    Chart.defaults.plugins.tooltip.backgroundColor = '#0f172a';
    Chart.defaults.plugins.tooltip.titleColor = '#ffffff';
    Chart.defaults.plugins.tooltip.bodyColor = '#f8fafc';
    Chart.defaults.plugins.tooltip.padding = 10;
    Chart.defaults.plugins.tooltip.cornerRadius = 8;
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
}

window.AnalyticsPalette = {
    primary: '#2563eb',
    purple: '#7c3aed',
    emerald: '#10b981',
    amber: '#f59e0b',
    rose: '#ef4444',
    slate: '#64748b',
    lightBlue: '#dbeafe',
    lightPurple: '#ede9fe',
    lightEmerald: '#dcfce7'
};
