/**
 * Student Management View, Edit, and Modal Interactions
 */

document.addEventListener('DOMContentLoaded', function () {
    const studentModal = document.getElementById('viewStudentModal');
    const editModal = document.getElementById('editStudentModal');
    const deleteModal = document.getElementById('deleteStudentModal');

    // Handle View Student Details Modal
    if (studentModal) {
        studentModal.addEventListener('show.bs.modal', function (event) {
            const btn = event.relatedTarget;
            const studentId = btn.getAttribute('data-id');

            const contentLoading = document.getElementById('studentDetailLoading');
            const contentBody = document.getElementById('studentDetailContent');
            if (contentLoading) contentLoading.classList.remove('d-none');
            if (contentBody) contentBody.classList.add('d-none');

            fetch(`/students/view/${studentId}`)
                .then(res => res.json())
                .then(res => {
                    if (!res.success) {
                        alert("Could not load student information.");
                        return;
                    }

                    const s = res.student;
                    document.getElementById('modalStudentName').textContent = s.full_name;
                    document.getElementById('modalRollNumber').textContent = s.roll_number;
                    document.getElementById('modalEmail').textContent = s.email;
                    document.getElementById('modalPhone').textContent = s.phone || 'N/A';
                    document.getElementById('modalCourse').textContent = `${s.course} (Semester ${s.semester})`;
                    document.getElementById('modalGender').textContent = s.gender;
                    document.getElementById('modalEnrolled').textContent = s.enrollment_date;

                    // Attendance summary
                    const att = res.attendance || { total_classes: 0, attended: 0, percentage: 0 };
                    document.getElementById('modalAttClasses').textContent = `${att.attended || 0} / ${att.total_classes || 0}`;
                    const attBadge = document.getElementById('modalAttPct');
                    attBadge.textContent = `${att.percentage || 0}%`;
                    attBadge.className = `badge ${(att.percentage || 0) >= 75 ? 'bg-success' : 'bg-danger'}`;

                    // Marks table
                    const tbody = document.getElementById('modalMarksTbody');
                    if (res.marks && res.marks.length > 0) {
                        tbody.innerHTML = res.marks.map(m => `
                            <tr>
                                <td><span class="fw-semibold">${m.subject_code}</span> - ${m.subject_name}</td>
                                <td>${m.exam_type}</td>
                                <td>${m.obtained_marks} / ${m.max_marks}</td>
                                <td>${m.percentage}%</td>
                                <td><span class="badge ${m.status === 'Pass' ? 'bg-success' : 'bg-danger'}">${m.grade}</span></td>
                                <td>${m.status}</td>
                            </tr>
                        `).join('');
                    } else {
                        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-3">No examination marks recorded yet.</td></tr>`;
                    }

                    if (contentLoading) contentLoading.classList.add('d-none');
                    if (contentBody) contentBody.classList.remove('d-none');
                })
                .catch(err => {
                    console.error("Error loading student view:", err);
                });
        });
    }

    // Handle Edit Student Modal
    if (editModal) {
        editModal.addEventListener('show.bs.modal', function (event) {
            const btn = event.relatedTarget;
            const form = document.getElementById('editStudentForm');
            const sid = btn.getAttribute('data-id');
            form.action = `/students/edit/${sid}`;

            document.getElementById('editFullName').value = btn.getAttribute('data-name') || '';
            document.getElementById('editRollNumber').value = btn.getAttribute('data-roll') || '';
            document.getElementById('editEmail').value = btn.getAttribute('data-email') || '';
            document.getElementById('editPhone').value = btn.getAttribute('data-phone') || '';
            document.getElementById('editGender').value = btn.getAttribute('data-gender') || 'Male';
            document.getElementById('editCourse').value = btn.getAttribute('data-course') || '';
            document.getElementById('editSemester').value = btn.getAttribute('data-sem') || '1';
            document.getElementById('editEnrollmentDate').value = btn.getAttribute('data-date') || '';
            document.getElementById('editStatus').value = btn.getAttribute('data-status') || 'Active';
        });
    }

    // Handle Delete Student Modal
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            const btn = event.relatedTarget;
            const sid = btn.getAttribute('data-id');
            const sname = btn.getAttribute('data-name');
            const sroll = btn.getAttribute('data-roll');

            document.getElementById('deleteStudentName').textContent = `${sname} (${sroll})`;
            document.getElementById('deleteStudentForm').action = `/students/delete/${sid}`;
        });
    }
});
