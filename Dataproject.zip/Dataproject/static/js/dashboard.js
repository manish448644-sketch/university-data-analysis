/**
 * Dashboard Analytics and Chart.js Controller
 * Handles dynamic KPI updates and asynchronous chart refreshes
 */

document.addEventListener('DOMContentLoaded', function () {
    // Chart instances store
    let charts = {
        distribution: null,
        subjectAverages: null,
        performanceTrends: null,
        attendanceAnalysis: null,
        topStudents: null
    };

    // Filter selectors
    const sessionSelect = document.getElementById('filterSession');
    const courseSelect = document.getElementById('filterCourse');
    const semesterSelect = document.getElementById('filterSemester');
    const examTypeSelect = document.getElementById('filterExamType');
    const btnReset = document.getElementById('btnResetFilters');

    // KPI Elements
    const kpiTotalStudents = document.getElementById('kpiTotalStudents');
    const kpiTotalSubjects = document.getElementById('kpiTotalSubjects');
    const kpiAverageMarks = document.getElementById('kpiAverageMarks');
    const kpiPassPercentage = document.getElementById('kpiPassPercentage');
    const kpiAverageAttendance = document.getElementById('kpiAverageAttendance');
    const kpiStudentsAtRisk = document.getElementById('kpiStudentsAtRisk');

    function fetchDashboardData() {
        const params = new URLSearchParams();
        if (sessionSelect && sessionSelect.value) params.append('session_id', sessionSelect.value);
        if (courseSelect && courseSelect.value) params.append('course', courseSelect.value);
        if (semesterSelect && semesterSelect.value) params.append('semester', semesterSelect.value);
        if (examTypeSelect && examTypeSelect.value) params.append('exam_type', examTypeSelect.value);

        fetch(`/api/dashboard/data?${params.toString()}`)
            .then(response => {
                if (!response.ok) throw new Error('Network response error');
                return response.json();
            })
            .then(res => {
                if (!res.success) {
                    console.error("Dashboard API error:", res.error);
                    return;
                }

                // Update KPIs
                const k = res.kpis;
                if (kpiTotalStudents) kpiTotalStudents.textContent = k.total_students.toLocaleString();
                if (kpiTotalSubjects) kpiTotalSubjects.textContent = k.total_subjects.toLocaleString();
                if (kpiAverageMarks) kpiAverageMarks.textContent = `${k.average_marks}%`;
                if (kpiPassPercentage) kpiPassPercentage.textContent = `${k.pass_percentage}%`;
                if (kpiAverageAttendance) kpiAverageAttendance.textContent = `${k.average_attendance}%`;
                if (kpiStudentsAtRisk) kpiStudentsAtRisk.textContent = k.students_at_risk.toLocaleString();

                // Render/Update Charts
                updateCharts(res.charts);
            })
            .catch(err => {
                console.error("Failed to load dashboard data:", err);
            });
    }

    function updateCharts(data) {
        // 1. Distribution Chart (Doughnut)
        const ctxDist = document.getElementById('chartDistribution');
        if (ctxDist) {
            if (charts.distribution) charts.distribution.destroy();
            charts.distribution = new Chart(ctxDist, {
                type: 'doughnut',
                data: {
                    labels: data.distribution.labels,
                    datasets: [{
                        data: data.distribution.data,
                        backgroundColor: data.distribution.colors,
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom', labels: { boxWidth: 12, padding: 12 } }
                    },
                    cutout: '68%'
                }
            });
        }

        // 2. Subject Averages (Bar)
        const ctxSubj = document.getElementById('chartSubjectAverages');
        if (ctxSubj) {
            if (charts.subjectAverages) charts.subjectAverages.destroy();
            charts.subjectAverages = new Chart(ctxSubj, {
                type: 'bar',
                data: {
                    labels: data.subject_averages.labels,
                    datasets: [{
                        label: 'Average Score (%)',
                        data: data.subject_averages.data,
                        backgroundColor: '#3b82f6',
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { beginAtZero: true, max: 100, grid: { color: '#f1f5f9' } },
                        x: { grid: { display: false } }
                    },
                    plugins: { legend: { display: false } }
                }
            });
        }

        // 3. Performance Trends (Line)
        const ctxTrend = document.getElementById('chartPerformanceTrends');
        if (ctxTrend) {
            if (charts.performanceTrends) charts.performanceTrends.destroy();
            charts.performanceTrends = new Chart(ctxTrend, {
                type: 'line',
                data: {
                    labels: data.performance_trends.labels,
                    datasets: [{
                        label: 'Average Marks %',
                        data: data.performance_trends.data,
                        borderColor: '#7c3aed',
                        backgroundColor: 'rgba(124, 58, 237, 0.1)',
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: '#7c3aed',
                        pointRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { beginAtZero: false, min: 40, max: 100, grid: { color: '#f1f5f9' } },
                        x: { grid: { display: false } }
                    }
                }
            });
        }

        // 4. Attendance Analysis (Doughnut)
        const ctxAtt = document.getElementById('chartAttendanceAnalysis');
        if (ctxAtt) {
            if (charts.attendanceAnalysis) charts.attendanceAnalysis.destroy();
            charts.attendanceAnalysis = new Chart(ctxAtt, {
                type: 'doughnut',
                data: {
                    labels: data.attendance_analysis.labels,
                    datasets: [{
                        data: data.attendance_analysis.data,
                        backgroundColor: data.attendance_analysis.colors,
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom', labels: { boxWidth: 12, padding: 12 } }
                    },
                    cutout: '68%'
                }
            });
        }

        // 5. Top 10 Performing Students (Horizontal Bar)
        const ctxTop = document.getElementById('chartTopStudents');
        if (ctxTop) {
            if (charts.topStudents) charts.topStudents.destroy();
            charts.topStudents = new Chart(ctxTop, {
                type: 'bar',
                data: {
                    labels: data.top_students.labels,
                    datasets: [{
                        label: 'Overall Percentage',
                        data: data.top_students.data,
                        backgroundColor: '#10b981',
                        borderRadius: 6
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { beginAtZero: true, max: 100, grid: { color: '#f1f5f9' } },
                        y: { grid: { display: false } }
                    },
                    plugins: { legend: { display: false } }
                }
            });
        }
    }

    // Attach event listeners for real-time filtering
    [sessionSelect, courseSelect, semesterSelect, examTypeSelect].forEach(sel => {
        if (sel) {
            sel.addEventListener('change', fetchDashboardData);
        }
    });

    if (btnReset) {
        btnReset.addEventListener('click', function () {
            if (sessionSelect) sessionSelect.value = 'all';
            if (courseSelect) courseSelect.value = 'all';
            if (semesterSelect) semesterSelect.value = 'all';
            if (examTypeSelect) examTypeSelect.value = 'all';
            fetchDashboardData();
        });
    }

    // Initial load
    fetchDashboardData();
});
