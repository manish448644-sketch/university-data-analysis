# Student Performance Analytics System
## Full-Stack Web Application with MySQL 8 and Academic Data Analytics

A professional, responsive, and production-ready academic data analytics platform designed for higher education institutions. Built for managing student records, tracking lecture attendance, grading examination performance, and providing interactive business intelligence dashboards with multi-dimensional academic analytics.

---

## 🌟 Key Features & Architecture

- **Dual Portal Architecture**:
  1. **Teacher Portal** (`/dashboard`): Dedicated faculty interface for everyday lecture attendance logging, exam marks entry, student roster lookups, class analytics, and grade report generation. Built with a clean SaaS light aesthetic.
  2. **University Administration & Academic Monitoring Portal** (`/admin`): Central enterprise university ERP for administrators. Manages university academic structure (Departments, Courses, Subjects, Academic Sessions, Classes & Sections), People (Students & Faculty assignments), Centralized Academic Monitoring (attendance, marks, assignment submissions), Real-Time Teacher Activity Auditing, Notification Center, Executive Analytics, and PDF/CSV Export Hub. Features full Light and Dark theme toggling with persistent `localStorage`.
- **Direct MySQL 8 Connectivity**: Pure SQL with `mysql-connector-python`. **Zero ORM / Zero SQLAlchemy**. All queries use parameterized statements (`%s`) for absolute SQL injection security.
- **7-Stage Complete Database Suite**:
  1. `01_create_database.sql` - Schema setup with `utf8mb4` encoding.
  2. `02_create_tables.sql` - Complete DDL for `users`, `academic_sessions`, `students`, `subjects`, `marks`, `attendance`, `activity_logs`.
  3. `03_relationships_indexes.sql` - Foreign key cascades and performance B-Tree indexes.
  4. `04_insert_sample_data.sql` - Streamlined dataset (702 lines) with **500 registered students**, **8 core subjects**, **3 academic sessions**, **70 marks records**, and institutional attendance entries.
  5. `05_analytics_queries.sql` - Full MCA Data Analytics syllabus demonstration (Aggregates, Window-like groupings, Multi-table joins, Subqueries, Set operators, Data dictionary inspection).
  6. `06_views_procedures.sql` - Pre-compiled views (`vw_student_overall_summary`, `vw_subject_performance`, `vw_at_risk_students`), stored procedures (`sp_get_student_marksheet`, `sp_calculate_dashboard_kpis`), and automated audit triggers.
  7. `07_university_admin_migration.sql` - Complete University ERP schema migration: creates `departments`, `courses`, `classes_sections`, `teacher_assignments`, `assignments`, `assignment_submissions`, `admin_notifications` and enriches existing tables with section, session, department, and teacher tracking columns.
- **Interactive Executive Dashboard**: 6 dynamic KPI cards (Total Students, Total Subjects, Average Marks, Pass %, Average Attendance, Students at Risk) and 5 dynamic Chart.js visualizations that update asynchronously when filters change.
- **Academic Performance Analytics**:
  - Highest and lowest-scoring students ranking
  - Course-wise and semester-wise comparisons
  - Attendance vs. marks correlation scatter plot
  - At-risk student identification (<75% attendance or <50% score)
  - Grade distribution (A+, A, B, C, D, F)
- **Official Reporting & Document Generation**:
  - Individual student marksheet / report cards
  - Direct CSV data export
  - Native PDF document generation powered by **ReportLab**
  - Print-ready media styling (`window.print()`)
- **Authentication & Security**:
  - Werkzeug password hashing (scrypt / PBKDF2)
  - Role-based authorization (`admin` vs `user`)
  - Session management with "Remember me" option
  - Full audit trail in `activity_logs` table

---

## 📁 Project Folder Structure

```
Student_Performance_Analytics/
│
├── app.py                      # Flask application factory, routes registration & error handlers
├── config.py                   # Environment configuration loader (.env)
├── db.py                       # Pure MySQL connector manager & query executor
├── requirements.txt            # Python dependencies
├── .env.example                # Template for database credentials
├── .env                        # Active environment configuration
│
├── database/
│   ├── 01_create_database.sql       # Database creation and UTF-8 charset configuration
│   ├── 02_create_tables.sql         # Table schemas with datatypes & constraints
│   ├── 03_relationships_indexes.sql # Foreign keys & B-Tree indexes
│   ├── 04_insert_sample_data.sql    # 500 students, 8 subjects, marks, attendance, sessions
│   ├── 05_analytics_queries.sql     # MCA SQL syllabus demonstration queries
│   └── 06_views_procedures.sql     # Database Views, Stored Procedures & Triggers
│
├── routes/
│   ├── __init__.py             # Route authentication decorators (@login_required, @admin_required)
│   ├── auth.py                 # Sign in, Sign up, Password reset, Logout
│   ├── dashboard.py            # Dashboard metrics & asynchronous Chart.js JSON APIs
│   ├── students.py             # Student CRUD, modal views, search, pagination, sort
│   ├── subjects.py             # Subject management, passing thresholds, credits
│   ├── marks.py                # Assessment marks recording & auto grade computation
│   ├── attendance.py           # Daily class roster marking, history & absenteeism warnings
│   ├── analytics.py            # Multi-dimensional analytics, rankings, correlation models
│   ├── reports.py              # Marksheets, CSV export & ReportLab PDF engine
│   └── profile.py              # User profile, password updates, settings & activity logs
│
├── templates/
│   ├── base.html               # Master layout with fixed sidebar, topbar & alerts
│   ├── login.html              # Authentication sign-in & password recovery
│   ├── signup.html             # Faculty account registration
│   ├── dashboard.html          # Executive KPI cards & 5 interactive Chart.js charts
│   ├── students.html           # Student management table & CRUD modals
│   ├── subjects.html           # Subject management interface
│   ├── marks.html              # Assessment recording & auto grade calculator
│   ├── attendance.html         # Roster attendance marking & absenteeism audits
│   ├── analytics.html          # Performance correlation & at-risk student rosters
│   ├── reports.html            # Marksheet generator & printable reports
│   ├── profile.html            # User account settings & personal activity log
│   ├── settings.html           # Institutional academic thresholds & preferences
│   ├── activity_logs.html      # Complete immutable platform audit trail
│   └── error.html              # Graceful error pages with MySQL diagnostics
│
├── static/
│   ├── css/
│   │   └── style.css           # Modern SaaS light theme design system
│   └── js/
│       ├── dashboard.js        # Dashboard real-time filter controller & charts
│       ├── students.js         # Student details & modal AJAX handlers
│       ├── analytics.js        # Analytics charts & scatter plot controller
│       └── charts.js           # Chart.js global palette and configuration
│
└── README.md
```

---

## 🚀 Step-by-Step Installation & Setup Guide

### Step 1: Install Python Dependencies
Open your command terminal (PowerShell, CMD, or Bash) in this project folder and run:
```bash
pip install -r requirements.txt
```

---

### Step 2: Open MySQL Workbench
Launch **MySQL Workbench** (or your preferred MySQL 8 administration tool) and connect to your local MySQL 8 server instance.

---

### Step 3: Execute the Provided SQL Scripts in Order
Open and execute the SQL scripts located inside the `database/` directory in this exact numerical sequence:

1. `database/01_create_database.sql`
   - Creates the `student_analytics_db` database with `utf8mb4` encoding.
2. `database/02_create_tables.sql`
   - Creates the 7 database tables (`users`, `academic_sessions`, `students`, `subjects`, `marks`, `attendance`, `activity_logs`).
3. `database/03_relationships_indexes.sql`
   - Sets up Foreign Key constraints and B-Tree performance indexes.
4. `database/04_insert_sample_data.sql`
   - Populates the database with 500 realistic students, 8 subjects, 3 academic sessions, 70 assessment records, and 84 attendance entries.
5. `database/05_analytics_queries.sql` *(Optional for testing in Workbench)*
   - Contains all syllabus demonstration queries for academic review.
6. `database/06_views_procedures.sql`
   - Creates views (`vw_student_overall_summary`, `vw_subject_performance`, `vw_at_risk_students`), stored procedures, and audit triggers.

---

### Step 4: Configure MySQL Credentials in the `.env` File
Create or edit the `.env` file in the root project folder:
```ini
# MySQL Database Connection Settings
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=student_analytics_db

# Flask Application Settings
SECRET_KEY=supersecret-mca-analytics-token-key-2025
FLASK_ENV=development
FLASK_DEBUG=1
```
*(Replace `your_mysql_password_here` with your actual MySQL root password)*

---

### Step 5: Run the Flask Application
Start the Flask development server:
```bash
python app.py
```
You will see:
```text
 * Running on http://127.0.0.1:5000
 * Application successfully connected to MySQL Database!
```

---

### Step 6: Open the Application in Your Web Browser
Navigate to:
```
http://127.0.0.1:5000
```
You will be greeted by the professional sign-in interface.

---

### Step 7: Test Login & Explore Modules

#### Pre-configured Accounts:
- **System Administrator (University Admin Portal -> `/admin/dashboard`)**:
  - Email: `admin@analytics.com`
  - Password: `Admin@1234`
- **Faculty Users (Teacher Portal -> `/dashboard`)**:
  - `teacher@analytics.com` (Prof. Rajesh Sharma, HOD & Professor) - Password: `Teacher@1234`
  - `sunita.verma@analytics.com` (Dr. Sunita Verma, Associate Professor) - Password: `Teacher@1234`
  - `amit.patel@analytics.com` (Prof. Amit Patel, Assistant Professor) - Password: `Teacher@1234`
  - `vikram.rao@analytics.com` (Dr. Vikram Rao, Professor) - Password: `Teacher@1234`
  - `ananya.m@analytics.com` (Ms. Ananya Mukherjee, Lecturer) - Password: `Teacher@1234`

#### You can also register a new account on the Signup page:
- Click **"Sign Up"**, enter your details, and log in immediately.

---

## 📊 Evaluation & Grading Logic

Assessment percentage is computed dynamically:
$$\text{Percentage} = \left(\frac{\text{Obtained Marks}}{\text{Maximum Marks}}\right) \times 100$$

Standard Grade Matrix:
- **90% – 100%**: `A+` (Outstanding Distinction)
- **80% – 89.99%**: `A` (First Class with Merit)
- **70% – 79.99%**: `B` (First Class)
- **60% – 69.99%**: `C` (Higher Second Class)
- **50% – 59.99%**: `D` (Pass Class)
- **Below 50%**: `F` (Academic Failure)

Pass/Fail status is evaluated against the subject's configured passing threshold:
- Status is **Pass** if $\text{Obtained Marks} \ge \text{Passing Marks}$ and $\text{Percentage} \ge 50\%$.
- Otherwise, Status is **Fail**.

Attendance percentage:
$$\text{Attendance Rate} = \left(\frac{\text{Present Classes} + \text{Late Classes}}{\text{Total Classes}}\right) \times 100$$
Any student with an attendance rate **below 75%** is highlighted and flagged as **At Risk**.

---

## 🎓 MySQL Syllabus Mapping (Academic Demonstration)

| Syllabus Concept | Implementation Location | Description |
|---|---|---|
| **SELECT, WHERE, ORDER BY** | `database/05_analytics_queries.sql`, `routes/students.py` | Filtering student cohorts and sorting by roll number / marks |
| **Single-Row String & Math** | `UPPER()`, `LOWER()`, `CONCAT()`, `ROUND()`, `LENGTH()` | Formatting names, roll labels, and rounding percentages |
| **Conversion Functions** | `CAST()`, `CONVERT()`, `DATE_FORMAT()` | Date formatting in marks and attendance history |
| **Conditional Expressions** | `CASE WHEN ... THEN ... ELSE`, `IF()` | Grade allocation, promotion status, and risk classification |
| **Aggregate Functions** | `COUNT()`, `SUM()`, `AVG()`, `MIN()`, `MAX()` | Institutional KPI card calculations, averages, and pass percentages |
| **GROUP BY & HAVING** | `HAVING avg_score >= 60.00` | Filtering subjects and student performance cohorts |
| **Multi-Table JOINS** | `INNER JOIN`, `LEFT JOIN` | Joining `students`, `subjects`, `marks`, `attendance`, `academic_sessions` |
| **Subqueries & Correlated** | `SELECT ... WHERE obtained_marks > (SELECT AVG(...))` | Identifying above-average students and top subject scores |
| **SET Operators** | `UNION`, `UNION ALL`, `INTERSECT` | Consolidating academic stars and high attendance lists |
| **Views** | `vw_student_overall_summary`, `vw_at_risk_students` | Reusable pre-compiled analytic queries |
| **Stored Procedures** | `sp_get_student_marksheet`, `sp_calculate_dashboard_kpis` | Modularized business logic executed inside the database engine |
| **Triggers** | `trg_after_marks_insert`, `trg_after_student_insert` | Automated audit logging into `activity_logs` |
| **Information Schema** | `information_schema.TABLES`, `COLUMNS`, `KEY_COLUMN_USAGE` | Inspecting data dictionary metadata and table storage sizes |

---

## 🔒 Security Best Practices

1. **SQL Injection Defense**: Every single query utilizes parameterized tuples (`%s`) processed natively by `mysql.connector`. No raw string concatenation or interpolation is ever executed.
2. **Password Cryptography**: Passwords are encrypted with salt and hash algorithms via `werkzeug.security.generate_password_hash`. Plaintext passwords are never stored.
3. **Auditability**: Critical modifications (enrollments, marks entries, deletions, user logins) trigger automated logging into the `activity_logs` table.
4. **Relational Integrity**: Foreign keys with `ON DELETE CASCADE` prevent orphan records, while `ON DELETE RESTRICT` protects academic sessions from accidental removal.
