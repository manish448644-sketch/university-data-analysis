import mysql.connector
from mysql.connector import Error
from config import Config
import logging

logger = logging.getLogger(__name__)

def get_db_connection():
    """
    Establish and return a direct MySQL connection using mysql-connector-python.
    Raises Error if connection fails.
    """
    connection = mysql.connector.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD,
        database=Config.DB_NAME,
        charset='utf8mb4',
        use_unicode=True,
        autocommit=False
    )
    return connection

def check_db_status():
    """
    Check if the MySQL database is reachable and configured.
    Returns (True, "Connected") or (False, error_message).
    """
    try:
        conn = get_db_connection()
        if conn.is_connected():
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.close()
            conn.close()
            return True, "Database connection operational."
    except Error as e:
        return False, f"MySQL Connection Error: {str(e)}"
    except Exception as e:
        return False, f"Database Connection Exception: {str(e)}"
    return False, "Database not connected."

def execute_query(query, params=None, fetch='all', dictionary=True, commit=False):
    """
    Execute a parameterized SQL query safely against the MySQL database.
    
    :param query: SQL string (parameterized with %s)
    :param params: tuple, list, or dict of parameters
    :param fetch: 'all', 'one', or None
    :param dictionary: Return results as Python dicts if True, else tuples
    :param commit: Commit the transaction if True (for INSERT, UPDATE, DELETE)
    :return: List of dicts/tuples, single dict/tuple, or dict with metadata
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=dictionary)
        
        cursor.execute(query, params or ())
        
        result = None
        if commit:
            conn.commit()
            result = {
                'last_insert_id': cursor.lastrowid,
                'affected_rows': cursor.rowcount
            }
        elif fetch == 'all':
            result = cursor.fetchall()
        elif fetch == 'one':
            result = cursor.fetchone()
            
        return result
    except Error as e:
        if conn:
            conn.rollback()
        logger.error(f"Database error executing query: {query} with params {params}. Error: {e}")
        raise e
    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()

def log_activity(user_id, action, entity_type=None, entity_id=None, details=None, ip_address=None, course=None, semester=None, section_name=None, subject_name=None):
    """
    Record user, faculty and system actions in the activity_logs table with academic context.
    Append-only audit trail for university monitoring.
    """
    try:
        query = """
            INSERT INTO activity_logs (user_id, action, entity_type, entity_id, course, semester, section_name, subject_name, details, ip_address)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        execute_query(
            query,
            (user_id, action, entity_type, str(entity_id) if entity_id else None, course, semester, section_name, subject_name, details, ip_address),
            commit=True
        )
    except Exception as e:
        logger.warning(f"Could not record activity log: {e}")

def add_notification(title, message, category='System', link_url=None):
    """
    Publish an official notification to the University Admin Notification Center.
    """
    try:
        query = """
            INSERT INTO admin_notifications (title, message, category, link_url, is_read)
            VALUES (%s, %s, %s, %s, FALSE)
        """
        execute_query(query, (title, message, category, link_url), commit=True)
    except Exception as e:
        logger.warning(f"Could not publish admin notification: {e}")
